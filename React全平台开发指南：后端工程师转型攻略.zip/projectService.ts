/**
 * 项目服务 - 应用层
 * 
 * 类比Go后端的项目服务:
 * ```go
 * type ProjectService struct {
 *   projectRepo repository.ProjectRepository
 *   eventBus events.EventBus
 * }
 * 
 * func (s *ProjectService) CreateProject(ctx context.Context, cmd commands.CreateProjectCommand) (domain.Project, error) {
 *   // 实现创建项目的业务逻辑
 * }
 * ```
 */

import { Project, ProjectID, ProjectStatus, createProject, ProjectCreatedEvent, ProjectArchivedEvent, MemberAddedEvent } from '../domain/project';
import { UserID } from '../domain/user';
import { apiClient } from '../infrastructure/api/apiClient';
import { EventBus } from '../infrastructure/events/eventBus';
import { logger } from '../infrastructure/logger/logger';

// 命令模式 - 类比Go的Command对象
export interface CreateProjectCommand {
  name: string;
  description: string;
  ownerId: UserID;
  members?: UserID[];
}

export interface UpdateProjectCommand {
  id: ProjectID;
  name?: string;
  description?: string;
  status?: ProjectStatus;
}

export interface AddMemberCommand {
  projectId: ProjectID;
  userId: UserID;
  addedBy: UserID;
}

export interface ArchiveProjectCommand {
  projectId: ProjectID;
  archivedBy: UserID;
}

// 项目服务类 - 类比Go的ProjectService
export class ProjectService {
  private eventBus: EventBus;

  constructor(eventBus: EventBus) {
    this.eventBus = eventBus;
  }

  // 创建项目
  async createProject(command: CreateProjectCommand): Promise<Project> {
    try {
      logger.info('Creating project', { name: command.name, ownerId: command.ownerId });
      
      // 创建项目领域对象
      const project = createProject(
        command.name,
        command.description,
        command.ownerId,
        command.members
      );

      // 调用API保存项目
      const savedProject = await apiClient.post<Project>('/projects', project);

      // 发布项目创建事件
      const event: ProjectCreatedEvent = {
        projectId: savedProject.id,
        ownerId: savedProject.ownerId,
        createdAt: savedProject.createdAt
      };
      this.eventBus.publish('ProjectCreated', event);

      logger.info('Project created successfully', { projectId: savedProject.id });
      return savedProject;
    } catch (error) {
      logger.error('Failed to create project', error as Error, { name: command.name });
      throw error;
    }
  }

  // 获取项目
  async getProject(projectId: ProjectID): Promise<Project> {
    try {
      logger.info('Fetching project', { projectId });
      return await apiClient.get<Project>(`/projects/${projectId}`);
    } catch (error) {
      logger.error(`Failed to get project`, error as Error, { projectId });
      throw error;
    }
  }

  // 获取用户的项目列表
  async getUserProjects(userId: UserID): Promise<Project[]> {
    try {
      logger.info('Fetching user projects', { userId });
      return await apiClient.get<Project[]>(`/users/${userId}/projects`);
    } catch (error) {
      logger.error(`Failed to get user projects`, error as Error, { userId });
      throw error;
    }
  }

  // 更新项目
  async updateProject(command: UpdateProjectCommand): Promise<Project> {
    try {
      logger.info('Updating project', { projectId: command.id });
      
      // 获取当前项目
      const currentProject = await this.getProject(command.id);
      
      // 更新项目
      const updatedProject = await apiClient.put<Project>(`/projects/${command.id}`, {
        ...currentProject,
        ...command,
        updatedAt: new Date().toISOString()
      });

      logger.info('Project updated successfully', { projectId: updatedProject.id });
      return updatedProject;
    } catch (error) {
      logger.error(`Failed to update project`, error as Error, { projectId: command.id });
      throw error;
    }
  }

  // 添加成员
  async addMember(command: AddMemberCommand): Promise<Project> {
    try {
      logger.info('Adding member to project', { 
        projectId: command.projectId, 
        userId: command.userId,
        addedBy: command.addedBy
      });
      
      // 获取当前项目
      const project = await this.getProject(command.projectId);
      
      // 检查用户是否已经是成员
      if (project.members.includes(command.userId)) {
        logger.warn('User is already a member of the project', { 
          projectId: command.projectId, 
          userId: command.userId 
        });
        return project;
      }
      
      // 添加成员
      const updatedProject = await apiClient.put<Project>(`/projects/${command.projectId}/members`, {
        userId: command.userId
      });

      // 发布成员添加事件
      const event: MemberAddedEvent = {
        projectId: updatedProject.id,
        userId: command.userId,
        addedBy: command.addedBy,
        addedAt: updatedProject.updatedAt
      };
      this.eventBus.publish('MemberAdded', event);

      logger.info('Member added successfully', { 
        projectId: updatedProject.id, 
        userId: command.userId 
      });
      return updatedProject;
    } catch (error) {
      logger.error(`Failed to add member to project`, error as Error, { 
        projectId: command.projectId, 
        userId: command.userId 
      });
      throw error;
    }
  }

  // 归档项目
  async archiveProject(command: ArchiveProjectCommand): Promise<Project> {
    try {
      logger.info('Archiving project', { 
        projectId: command.projectId, 
        archivedBy: command.archivedBy 
      });
      
      // 获取当前项目
      const project = await this.getProject(command.projectId);
      
      // 检查项目是否已归档
      if (project.status === ProjectStatus.ARCHIVED) {
        logger.warn('Project is already archived', { projectId: command.projectId });
        return project;
      }
      
      // 归档项目
      const updatedProject = await apiClient.put<Project>(`/projects/${command.projectId}`, {
        ...project,
        status: ProjectStatus.ARCHIVED,
        updatedAt: new Date().toISOString()
      });

      // 发布项目归档事件
      const event: ProjectArchivedEvent = {
        projectId: updatedProject.id,
        archivedBy: command.archivedBy,
        archivedAt: updatedProject.updatedAt
      };
      this.eventBus.publish('ProjectArchived', event);

      logger.info('Project archived successfully', { projectId: updatedProject.id });
      return updatedProject;
    } catch (error) {
      logger.error(`Failed to archive project`, error as Error, { projectId: command.projectId });
      throw error;
    }
  }

  // 删除项目
  async deleteProject(projectId: ProjectID): Promise<void> {
    try {
      logger.info('Deleting project', { projectId });
      await apiClient.delete(`/projects/${projectId}`);
      logger.info('Project deleted successfully', { projectId });
    } catch (error) {
      logger.error(`Failed to delete project`, error as Error, { projectId });
      throw error;
    }
  }
}

// 创建项目服务实例
export const projectService = new ProjectService(new EventBus());
