/**
 * 后端API性能测试脚本 - Go服务响应时间测试
 * 
 * 本脚本用于测试Go后端API的性能指标，包括响应时间、吞吐量等
 * 测试结果将与React前端渲染性能进行对比
 */

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Rate, Trend } from 'k6/metrics';

// 自定义指标
const successRate = new Rate('success_rate');
const errorRate = new Rate('error_rate');
const requestDuration = new Trend('request_duration');
const requestsPerSecond = new Counter('requests_per_second');

// 测试配置
export const options = {
  stages: [
    { duration: '30s', target: 10 }, // 预热阶段
    { duration: '1m', target: 50 },  // 负载增长阶段
    { duration: '2m', target: 50 },  // 稳定负载阶段
    { duration: '30s', target: 0 },  // 缓慢降低阶段
  ],
  thresholds: {
    'http_req_duration': ['p(95)<500'], // 95%的请求应在500ms内完成
    'success_rate': ['rate>0.95'],      // 成功率应大于95%
  },
};

// API基础URL
const BASE_URL = 'http://localhost:8080/api/v1';

// 测试数据
const TEST_USER = {
  email: 'test@example.com',
  password: 'password123'
};

// 登录并获取令牌
function login() {
  const loginRes = http.post(`${BASE_URL}/auth/login`, JSON.stringify(TEST_USER), {
    headers: { 'Content-Type': 'application/json' },
  });
  
  check(loginRes, {
    'login successful': (r) => r.status === 200,
    'has token': (r) => JSON.parse(r.body).token !== undefined,
  });
  
  return JSON.parse(loginRes.body).token;
}

// 主测试函数
export default function() {
  // 登录获取令牌
  const token = login();
  const authHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  };
  
  // 测试1: 获取项目列表 (GET请求)
  const startGetProjects = new Date();
  const projectsRes = http.get(`${BASE_URL}/projects`, { headers: authHeaders });
  const getProjectsDuration = new Date() - startGetProjects;
  
  // 记录指标
  requestDuration.add(getProjectsDuration);
  requestsPerSecond.add(1);
  
  // 检查结果
  const getProjectsSuccess = check(projectsRes, {
    'get projects status is 200': (r) => r.status === 200,
    'get projects has data': (r) => JSON.parse(r.body).length !== undefined,
  });
  
  successRate.add(getProjectsSuccess);
  errorRate.add(!getProjectsSuccess);
  
  // 从响应中获取项目ID用于后续测试
  let projectId = '';
  if (getProjectsSuccess) {
    const projects = JSON.parse(projectsRes.body);
    if (projects.length > 0) {
      projectId = projects[0].id;
    } else {
      // 如果没有项目，创建一个新项目
      const newProject = {
        name: `Test Project ${Date.now()}`,
        description: 'Created during performance testing',
      };
      
      const createProjectRes = http.post(
        `${BASE_URL}/projects`, 
        JSON.stringify(newProject),
        { headers: authHeaders }
      );
      
      if (createProjectRes.status === 201) {
        projectId = JSON.parse(createProjectRes.body).id;
      }
    }
  }
  
  // 如果有项目ID，测试获取单个项目详情
  if (projectId) {
    // 测试2: 获取单个项目详情
    const startGetProject = new Date();
    const projectRes = http.get(`${BASE_URL}/projects/${projectId}`, { headers: authHeaders });
    const getProjectDuration = new Date() - startGetProject;
    
    // 记录指标
    requestDuration.add(getProjectDuration);
    requestsPerSecond.add(1);
    
    // 检查结果
    const getProjectSuccess = check(projectRes, {
      'get project status is 200': (r) => r.status === 200,
      'get project has correct id': (r) => JSON.parse(r.body).id === projectId,
    });
    
    successRate.add(getProjectSuccess);
    errorRate.add(!getProjectSuccess);
    
    // 测试3: 获取项目任务列表
    const startGetTasks = new Date();
    const tasksRes = http.get(`${BASE_URL}/projects/${projectId}/tasks`, { headers: authHeaders });
    const getTasksDuration = new Date() - startGetTasks;
    
    // 记录指标
    requestDuration.add(getTasksDuration);
    requestsPerSecond.add(1);
    
    // 检查结果
    const getTasksSuccess = check(tasksRes, {
      'get tasks status is 200': (r) => r.status === 200,
    });
    
    successRate.add(getTasksSuccess);
    errorRate.add(!getTasksSuccess);
    
    // 测试4: 创建新任务
    const newTask = {
      title: `Test Task ${Date.now()}`,
      description: 'Created during performance testing',
      projectId: projectId,
    };
    
    const startCreateTask = new Date();
    const createTaskRes = http.post(
      `${BASE_URL}/tasks`, 
      JSON.stringify(newTask),
      { headers: authHeaders }
    );
    const createTaskDuration = new Date() - startCreateTask;
    
    // 记录指标
    requestDuration.add(createTaskDuration);
    requestsPerSecond.add(1);
    
    // 检查结果
    const createTaskSuccess = check(createTaskRes, {
      'create task status is 201': (r) => r.status === 201,
      'create task returns id': (r) => JSON.parse(r.body).id !== undefined,
    });
    
    successRate.add(createTaskSuccess);
    errorRate.add(!createTaskSuccess);
    
    // 如果创建任务成功，测试更��和删除任务
    if (createTaskSuccess) {
      const taskId = JSON.parse(createTaskRes.body).id;
      
      // 测试5: 更新任务
      const updateTask = {
        title: `Updated Task ${Date.now()}`,
        status: 'IN_PROGRESS',
      };
      
      const startUpdateTask = new Date();
      const updateTaskRes = http.put(
        `${BASE_URL}/tasks/${taskId}`, 
        JSON.stringify(updateTask),
        { headers: authHeaders }
      );
      const updateTaskDuration = new Date() - startUpdateTask;
      
      // 记录指标
      requestDuration.add(updateTaskDuration);
      requestsPerSecond.add(1);
      
      // 检查结果
      const updateTaskSuccess = check(updateTaskRes, {
        'update task status is 200': (r) => r.status === 200,
        'update task has updated title': (r) => JSON.parse(r.body).title === updateTask.title,
      });
      
      successRate.add(updateTaskSuccess);
      errorRate.add(!updateTaskSuccess);
      
      // 测试6: 删除任务
      const startDeleteTask = new Date();
      const deleteTaskRes = http.del(`${BASE_URL}/tasks/${taskId}`, null, { headers: authHeaders });
      const deleteTaskDuration = new Date() - startDeleteTask;
      
      // 记录指标
      requestDuration.add(deleteTaskDuration);
      requestsPerSecond.add(1);
      
      // 检查结果
      const deleteTaskSuccess = check(deleteTaskRes, {
        'delete task status is 204': (r) => r.status === 204,
      });
      
      successRate.add(deleteTaskSuccess);
      errorRate.add(!deleteTaskSuccess);
    }
  }
  
  // 在请求之间添加随机延迟，模拟真实用户行为
  sleep(Math.random() * 3 + 1); // 1-4秒随机延迟
}
