# Web端代码沙箱示例

本示例展示了一个基于React的Web应用，专为具备Go/Python后端经验的开发者设计。示例实现了一个简单的任务管理系统，展示了如何将后端开发思维应用到React前端开发中。

## 技术栈

- **构建工具**: Vite + SWC (替代CRA，提供更快的编译速度)
- **UI框架**: React 18 (函数组件 + Hooks)
- **类型系统**: TypeScript (与Go/Python类型系统对照)
- **状态管理**: Redux Toolkit (类比Go的状态管理)
- **路由**: React Router v6 (类比Go的HTTP路由)
- **API交互**: Axios + React Query (类比Go的HTTP客户端)
- **样式**: TailwindCSS (实用优先的CSS框架)
- **测试**: Jest + React Testing Library

## 项目结构

项目结构采用领域驱动设计(DDD)的思想，将前端代码按领域概念组织，而非传统的按技术层次组织。

```
src/
├── domain/           # 领域模型 (类比Go的domain包)
│   ├── task.ts       # 任务领域模型
│   ├── user.ts       # 用户领域模型
│   └── project.ts    # 项目领域模型
├── application/      # 应用服务 (类比Go的application层)
│   ├── taskService.ts    # 任务相关业务逻辑
│   ├── authService.ts    # 认证相关业务逻辑
│   └── projectService.ts # 项目相关业务逻辑
├── infrastructure/   # 基础设施 (类比Go的infrastructure层)
│   ├── api/          # API客户端
│   ├── storage/      # 本地存储
│   └── logger/       # 日志服务
├── presentation/     # 表现层 (类比Go的handlers)
│   ├── components/   # UI组件
│   ├── pages/        # 页面组件
│   ├── hooks/        # 自定义Hooks
│   └── routes/       # 路由定义
└── shared/           # 共享工具和类型 (类比Go的pkg)
    ├── utils/        # 工具函数
    ├── constants/    # 常量定义
    └── types/        # 共享类型定义
```

## 后端对照关系

本示例特别关注以下后端到前端的概念映射：

1. **路由处理**: Go的HTTP Handler → React组件
2. **中间件**: Go的Middleware → React Router的路由守卫
3. **依赖注入**: Go的DI容器 → React Context
4. **数据模型**: Go的结构体 → TypeScript接口
5. **错误处理**: Go的错误返回 → React的错误边界
6. **并发处理**: Go的goroutine → React的useEffect清理

## 运行示例

```bash
# 安装依赖
npm install

# 开发模式运行
npm run dev

# 构建生产版本
npm run build

# 运行测试
npm test
```

## 示例功能

- 用户认证 (JWT)
- 任务管理 (CRUD操作)
- 项目组织
- 实时通知 (WebSocket)
- 性能优化示例

## 与后端交互

示例包含一个模拟的后端API，展示了如何：

1. 自动生成API类型定义 (基于OpenAPI/Swagger)
2. 处理认证和授权
3. 实现乐观UI更新
4. 管理API错误
5. 实现数据缓存和预取

## 性能对比

包含了Go后端服务与React前端渲染的性能对比指标，帮助开发者理解两者的性能特点和优化方向。
