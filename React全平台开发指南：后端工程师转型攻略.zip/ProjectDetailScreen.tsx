/**
 * 项目详情屏幕 - 表现层
 * 
 * 类比Go后端的项目详情处理器:
 * ```go
 * func ProjectDetailHandler(c *gin.Context) {
 *   projectID := c.Param("id")
 *   // 处理项目详情请求
 * }
 * ```
 */

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, Chip, FAB, Dialog, Portal, TextInput } from 'react-native-paper';
import { useAuth } from '../../hooks/useAuth';
import { useProject } from '../../hooks/useProject';
import { useTask } from '../../hooks/useTask';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { ProjectStackParamList } from '../../navigation/AppNavigator';
import { Ionicons } from '@expo/vector-icons';
import { Task, TaskStatus } from '../../../domain/task';

// 导航属性类型
type ProjectDetailScreenNavigationProp = StackNavigationProp<ProjectStackParamList, 'ProjectDetail'>;
type ProjectDetailScreenRouteProp = RouteProp<ProjectStackParamList, 'ProjectDetail'>;

// 组件属性类型
type Props = {
  navigation: ProjectDetailScreenNavigationProp;
  route: ProjectDetailScreenRouteProp;
};

// 项目详情屏幕组件 - 类比Go的项目详情处理器
export const ProjectDetailScreen: React.FC<Props> = ({ navigation, route }) => {
  const { projectId } = route.params;
  const { currentUser } = useAuth();
  const { fetchProject, currentProject, isLoading: projectLoading, error: projectError } = useProject();
  const { 
    tasks, 
    fetchTasks, 
    createTask, 
    updateTaskStatus, 
    assignTask, 
    deleteTask,
    isLoading: tasksLoading, 
    error: tasksError 
  } = useTask();

  // 创建任务对话框状态
  const [dialogVisible, setDialogVisible] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [dialogLoading, setDialogLoading] = useState(false);

  // 组件挂载时获取项目详情和任务列表 - 类比Go的初始化逻辑
  useEffect(() => {
    if (projectId) {
      fetchProject(projectId);
      fetchTasks(projectId);
    }
  }, [projectId, fetchProject, fetchTasks]);

  // 处理任务创建 - 类比Go的任务创建处理
  const handleCreateTask = async () => {
    if (!taskTitle.trim()) {
      Alert.alert('Error', 'Task title is required');
      return;
    }

    try {
      setDialogLoading(true);
      await createTask(taskTitle, taskDescription, projectId);
      setDialogVisible(false);
      setTaskTitle('');
      setTaskDescription('');
      
      // 刷新任务列表
      fetchTasks(projectId);
    } catch (error) {
      Alert.alert('Error', 'Failed to create task');
    } finally {
      setDialogLoading(false);
    }
  };

  // 处理任务状态更新 - 类比Go的任务更新处理
  const handleStatusChange = (taskId: string, newStatus: TaskStatus) => {
    Alert.alert(
      'Update Task Status',
      `Change task status to ${newStatus}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Update', 
          onPress: async () => {
            try {
              await updateTaskStatus(taskId, newStatus);
              // 刷新任务列表
              fetchTasks(projectId);
            } catch (error) {
              Alert.alert('Error', 'Failed to update task status');
            }
          }
        }
      ]
    );
  };

  // 处理任务分配 - 类比Go的任务分配处理
  const handleAssignTask = (taskId: string) => {
    if (!currentUser) return;
    
    Alert.alert(
      'Assign Task',
      'Assign this task to yourself?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Assign', 
          onPress: async () => {
            try {
              await assignTask(taskId, currentUser.id);
              // 刷新任务列表
              fetchTasks(projectId);
            } catch (error) {
              Alert.alert('Error', 'Failed to assign task');
            }
          }
        }
      ]
    );
  };

  // 处理任务删除 - 类比Go的任务删除处理
  const handleDeleteTask = (taskId: string) => {
    Alert.alert(
      'Delete Task',
      'Are you sure you want to delete this task? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteTask(taskId);
              // 刷新任务列表
              fetchTasks(projectId);
            } catch (error) {
              Alert.alert('Error', 'Failed to delete task');
            }
          }
        }
      ]
    );
  };

  // 处理任务选择 - 类比Go的任务详情跳转
  const handleTaskSelect = (taskId: string) => {
    navigation.navigate('TaskDetail', { taskId });
  };

  // 渲染任务项 - 类比Go的任务数据格式化
  const renderTaskItem = (task: Task) => (
    <Card key={task.id} style={styles.taskCard}>
      <TouchableOpacity
        onPress={() => handleTaskSelect(task.id)}
        activeOpacity={0.7}
      >
        <Card.Content>
          <View style={styles.taskHeader}>
            <Title style={styles.taskTitle}>{task.title}</Title>
            <Chip 
              mode="outlined" 
              style={getStatusChipStyle(task.status)}
            >
              {task.status}
            </Chip>
          </View>
          <Paragraph style={styles.taskDescription}>{task.description}</Paragraph>
        </Card.Content>
      </TouchableOpacity>
      
      <Card.Actions>
        <Button 
          onPress={() => handleTaskSelect(task.id)}
          color="#4a6da7"
        >
          View
        </Button>
        
        {task.status === TaskStatus.TODO && (
          <Button 
            onPress={() => handleStatusChange(task.id, TaskStatus.IN_PROGRESS)}
            color="#ff9800"
          >
            Start
          </Button>
        )}
        
        {task.status === TaskStatus.IN_PROGRESS && (
          <Button 
            onPress={() => handleStatusChange(task.id, TaskStatus.DONE)}
            color="#4caf50"
          >
            Complete
          </Button>
        )}
        
        {!task.assigneeId && (
          <Button 
            onPress={() => handleAssignTask(task.id)}
            color="#9c27b0"
          >
            Assign to me
          </Button>
        )}
        
        <Button 
          onPress={() => handleDeleteTask(task.id)}
          color="#f44336"
        >
          Delete
        </Button>
      </Card.Actions>
    </Card>
  );

  // 获取状态芯片样式
  const getStatusChipStyle = (status: TaskStatus) => {
    switch (status) {
      case TaskStatus.TODO:
        return styles.todoChip;
      case TaskStatus.IN_PROGRESS:
        return styles.inProgressChip;
      case TaskStatus.DONE:
        return styles.doneChip;
      default:
        return {};
    }
  };

  // 加载状态
  const isLoading = projectLoading || tasksLoading;
  
  // 错误状态
  const error = projectError || tasksError;

  // 设置导航标题
  useEffect(() => {
    if (currentProject) {
      navigation.setOptions({ title: currentProject.name });
    }
  }, [currentProject, navigation]);

  return (
    <View style={styles.container}>
      {isLoading && !currentProject ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a6da7" />
          <Text style={styles.loadingText}>Loading project details...</Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <Button 
            mode="contained" 
            onPress={() => {
              fetchProject(projectId);
              fetchTasks(projectId);
            }}
            style={styles.retryButton}
          >
            Retry
          </Button>
        </View>
      ) : currentProject ? (
        <ScrollView style={styles.content}>
          <Card style={styles.projectInfoCard}>
            <Card.Content>
              <View style={styles.projectHeader}>
                <Title style={styles.projectTitle}>{currentProject.name}</Title>
                <Chip 
                  mode="outlined" 
                  style={currentProject.status === 'ACTIVE' ? styles.activeChip : styles.archivedChip}
                >
                  {currentProject.status}
                </Chip>
              </View>
              <Paragraph style={styles.projectDescription}>{currentProject.description}</Paragraph>
              
              <View style={styles.projectMeta}>
                <Text style={styles.metaText}>
                  <Ionicons name="people-outline" size={16} /> {currentProject.members.length} members
                </Text>
                <Text style={styles.metaText}>
                  <Ionicons name="calendar-outline" size={16} /> Created: {new Date(currentProject.createdAt).toLocaleDateString()}
                </Text>
              </View>
            </Card.Content>
          </Card>

          <View style={styles.tasksHeader}>
            <Title>Tasks</Title>
            <Button 
              mode="contained" 
              onPress={() => setDialogVisible(true)}
              style={styles.addTaskButton}
            >
              Add Task
            </Button>
          </View>

          {tasksLoading ? (
            <View style={styles.tasksLoadingContainer}>
              <ActivityIndicator size="small" color="#4a6da7" />
              <Text style={styles.loadingText}>Loading tasks...</Text>
            </View>
          ) : tasks.length === 0 ? (
            <View style={styles.emptyTasksContainer}>
              <Ionicons name="checkbox-outline" size={48} color="#bdbdbd" />
              <Text style={styles.emptyText}>No tasks yet</Text>
              <Text style={styles.emptySubText}>Tap the Add Task button to create your first task</Text>
            </View>
          ) : (
            <View style={styles.tasksList}>
              {tasks.map(task => renderTaskItem(task))}
            </View>
          )}
        </ScrollView>
      ) : (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Project not found</Text>
        </View>
      )}

      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => setDialogVisible(true)}
      />

      <Portal>
        <Dialog visible={dialogVisible} onDismiss={() => setDialogVisible(false)}>
          <Dialog.Title>Create New Task</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label="Task Title"
              value={taskTitle}
              onChangeText={setTaskTitle}
              style={styles.input}
              disabled={dialogLoading}
            />
            <TextInput
              label="Description"
              value={taskDescription}
              onChangeText={setTaskDescription}
              style={styles.input}
              multiline
              numberOfLines={3}
              disabled={dialogLoading}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDialogVisible(false)} disabled={dialogLoading}>Cancel</Button>
            <Button onPress={handleCreateTask} loading={dialogLoading} disabled={dialogLoading}>Create</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};

// 样式
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  projectInfoCard: {
    marginBottom: 20,
    elevation: 2,
  },
  projectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  projectDescription: {
    color: '#757575',
  },
  projectMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  metaText: {
    fontSize: 12,
    color: '#9e9e9e',
  },
  activeChip: {
    backgroundColor: '#e8f5e9',
  },
  archivedChip: {
    backgroundColor: '#f5f5f5',
  },
  tasksHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  addTaskButton: {
    backgroundColor: '#4a6da7',
  },
  tasksList: {
    marginBottom: 80, // 为FAB留出空间
  },
  taskCard: {
    marginBottom: 12,
    elevation: 1,
  },
  taskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  taskTitle: {
    fontSize: 16,
  },
  taskDescription: {
    fontSize: 14,
    color: '#757575',
  },
  todoChip: {
    backgroundColor: '#e3f2fd',
  },
  inProgressChip: {
    backgroundColor: '#fff8e1',
  },
  doneChip: {
    backgroundColor: '#e8f5e9',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#4a6da7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tasksLoadingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: '#d32f2f',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4a6da7',
  },
  emptyTasksContainer: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#757575',
    marginTop: 16,
  },
  emptySubText: {
    fontSize: 14,
    color: '#9e9e9e',
    textAlign: 'center',
    marginTop: 8,
  },
  input: {
    marginBottom: 16,
    backgroundColor: '#fff',
  },
});
