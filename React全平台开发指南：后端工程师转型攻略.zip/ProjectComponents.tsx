/**
 * 项目组件 - 表现层
 * 
 * 类比Go后端的HTTP处理器:
 * ```go
 * func ProjectHandler(c *gin.Context) {
 *   // 处理项目请求
 * }
 * ```
 */

import React, { useState } from 'react';
import { Project, ProjectStatus } from '../../domain/project';
import { User, UserRole } from '../../domain/user';

interface ProjectCardProps {
  project: Project;
  currentUser: User;
  onArchive: (projectId: string) => void;
  onDelete: (projectId: string) => void;
  onClick: (projectId: string) => void;
}

// 项目卡片组件 - 类比Go的HTTP处理函数
export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  currentUser,
  onArchive,
  onDelete,
  onClick
}) => {
  // 格式化日期 - 类比Go的格式化函数
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  // 检查用户权限 - 类比Go的权限检查
  const canManageProject = currentUser.id === project.ownerId || 
                          currentUser.role === UserRole.ADMIN;

  // 处理归档 - 类比Go的处理函数
  const handleArchive = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to archive this project?')) {
      onArchive(project.id);
    }
  };

  // 处理删除 - 类比Go的处理函数
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      onDelete(project.id);
    }
  };

  return (
    <div 
      className={`border rounded-lg p-4 mb-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer ${
        project.status === ProjectStatus.ARCHIVED ? 'opacity-70' : ''
      }`}
      onClick={() => onClick(project.id)}
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold">{project.name}</h3>
          <p className="text-gray-600 mt-1">{project.description}</p>
          
          <div className="flex items-center mt-2 space-x-2">
            <span className={`px-2 py-1 rounded-full text-xs ${
              project.status === ProjectStatus.ACTIVE 
                ? 'bg-green-100 text-green-800' 
                : 'bg-gray-100 text-gray-800'
            }`}>
              {project.status}
            </span>
            <span className="text-sm text-gray-600">
              Created: {formatDate(project.createdAt)}
            </span>
          </div>
          
          <div className="mt-2 text-sm text-gray-600">
            Members: {project.members.length}
          </div>
        </div>
        
        {canManageProject && (
          <div className="flex space-x-2">
            {project.status === ProjectStatus.ACTIVE && (
              <button
                onClick={handleArchive}
                className="text-yellow-600 hover:text-yellow-800 text-sm"
              >
                Archive
              </button>
            )}
            <button
              onClick={handleDelete}
              className="text-red-600 hover:text-red-800 text-sm"
            >
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

interface ProjectListProps {
  projects: Project[];
  currentUser: User;
  onArchive: (projectId: string) => void;
  onDelete: (projectId: string) => void;
  onProjectSelect: (projectId: string) => void;
}

// 项目列表组件 - 类比Go的列表处理函数
export const ProjectList: React.FC<ProjectListProps> = ({
  projects,
  currentUser,
  onArchive,
  onDelete,
  onProjectSelect
}) => {
  // 按状态分组 - 类比Go的数据处理函数
  const activeProjects = projects.filter(p => p.status === ProjectStatus.ACTIVE);
  const archivedProjects = projects.filter(p => p.status === ProjectStatus.ARCHIVED);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Active Projects</h2>
      {activeProjects.length === 0 ? (
        <p className="text-gray-500 mb-8">No active projects</p>
      ) : (
        <div className="mb-8">
          {activeProjects.map(project => (
            <ProjectCard
              key={project.id}
              project={project}
              currentUser={currentUser}
              onArchive={onArchive}
              onDelete={onDelete}
              onClick={onProjectSelect}
            />
          ))}
        </div>
      )}

      {archivedProjects.length > 0 && (
        <>
          <h2 className="text-xl font-bold mb-4">Archived Projects</h2>
          <div>
            {archivedProjects.map(project => (
              <ProjectCard
                key={project.id}
                project={project}
                currentUser={currentUser}
                onArchive={onArchive}
                onDelete={onDelete}
                onClick={onProjectSelect}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

interface CreateProjectFormProps {
  onProjectCreate: (name: string, description: string) => void;
}

// 创建项目表单组件 - 类比Go的表单处理函数
export const CreateProjectForm: React.FC<CreateProjectFormProps> = ({
  onProjectCreate,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isFormVisible, setIsFormVisible] = useState(false);

  // 处理表单提交 - 类比Go的表单处理函数
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && description.trim()) {
      onProjectCreate(name, description);
      setName('');
      setDescription('');
      setIsFormVisible(false);
    }
  };

  return (
    <div className="mb-8">
      {!isFormVisible ? (
        <button
          onClick={() => setIsFormVisible(true)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Create New Project
        </button>
      ) : (
        <form onSubmit={handleSubmit} className="border rounded-lg p-4 shadow-sm">
          <h2 className="text-xl font-bold mb-4">Create New Project</h2>
          
          <div className="mb-4">
            <label htmlFor="name" className="block text-sm font-medium mb-1">
              Project Name
            </label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border rounded p-2"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="description" className="block text-sm font-medium mb-1">
              Description
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border rounded p-2 h-24"
              required
            />
          </div>
          
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsFormVisible(false)}
              className="border px-4 py-2 rounded hover:bg-gray-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
              Create Project
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
