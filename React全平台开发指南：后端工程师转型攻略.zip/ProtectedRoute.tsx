/**
 * 受保护路由组件 - 表现层
 * 
 * 类比Go后端的认证中间件:
 * ```go
 * func AuthMiddleware() gin.HandlerFunc {
 *   return func(c *gin.Context) {
 *     token := c.GetHeader("Authorization")
 *     if token == "" {
 *       c.AbortWithStatusJSON(401, gin.H{"error": "Unauthorized"})
 *       return
 *     }
 *     
 *     // 验证token...
 *     
 *     c.Next()
 *   }
 * }
 * ```
 */

import React, { useEffect } from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Navbar } from '../components/Navbar';

// 受保护路由组件 - 类比Go的认证中间件
export const ProtectedRoute: React.FC = () => {
  const { isAuthenticated, isLoading, checkAuth } = useAuth();
  const location = useLocation();

  // 组件挂载时检查认证状态 - 类比Go的token验证
  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  // 加载中状态
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="sr-only">Loading...</span>
          </div>
          <p className="mt-2">Verifying authentication...</p>
        </div>
      </div>
    );
  }

  // 未认证状态，重定向到登录页 - 类比Go的401响应
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 已认证状态，渲染子路由 - 类比Go的Next()调用
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
};
