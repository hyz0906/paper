/**
 * 任务领域模型
 * 
 * 类比Go后端的领域模型:
 * ```go
 * type TaskID string
 * 
 * type TaskStatus string
 * 
 * const (
 *   TaskStatusTodo TaskStatus = "TODO"
 *   TaskStatusInProgress TaskStatus = "IN_PROGRESS"
 *   TaskStatusDone TaskStatus = "DONE"
 * )
 * 
 * type Task struct {
 *   ID TaskID `json:"id"`
 *   Title string `json:"title"`
 *   Description string `json:"description"`
 *   Status TaskStatus `json:"status"`
 *   AssigneeID string `json:"assigneeId,omitempty"`
 *   ProjectID string `json:"projectId"`
 *   DueDate time.Time `json:"dueDate,omitempty"`
 *   CreatedAt time.Time `json:"createdAt"`
 *   UpdatedAt time.Time `json:"updatedAt"`
 * }
 * ```
 */

// 值对象 - 类比Go的类型别名
export type TaskID = string;

// 枚举 - 类比Go的常量
export enum TaskStatus {
  TODO = "TODO",
  IN_PROGRESS = "IN_PROGRESS",
  DONE = "DONE"
}

// 实体 - 类比Go的结构体
export interface Task {
  id: TaskID;
  title: string;
  description: string;
  status: TaskStatus;
  assigneeId?: string;
  projectId: string;
  dueDate?: string; // ISO 8601格式，类比Go的time.Time
  createdAt: string; // ISO 8601格式
  updatedAt: string; // ISO 8601格式
}

// 领域事件 - 类比Go的事件
export interface TaskCreatedEvent {
  taskId: TaskID;
  projectId: string;
  createdAt: string;
}

export interface TaskAssignedEvent {
  taskId: TaskID;
  assigneeId: string;
  assignedAt: string;
}

export interface TaskCompletedEvent {
  taskId: TaskID;
  completedAt: string;
}

// 领域服务 - 类比Go的领域服务
export function isTaskOverdue(task: Task): boolean {
  if (!task.dueDate) return false;
  return new Date(task.dueDate) < new Date();
}

export function canCompleteTask(task: Task): boolean {
  return task.status !== TaskStatus.DONE;
}

export function canAssignTask(task: Task, userId: string): boolean {
  return task.assigneeId !== userId;
}

// 值对象工厂 - 类比Go的构造函数
export function createTaskId(): TaskID {
  return `task-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

// 实体工厂 - 类比Go的NewTask函数
export function createTask(
  title: string,
  description: string,
  projectId: string,
  assigneeId?: string,
  dueDate?: string
): Task {
  const now = new Date().toISOString();
  return {
    id: createTaskId(),
    title,
    description,
    status: TaskStatus.TODO,
    projectId,
    assigneeId,
    dueDate,
    createdAt: now,
    updatedAt: now
  };
}
