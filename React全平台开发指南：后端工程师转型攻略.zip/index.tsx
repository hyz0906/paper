/**
 * 登录页面组件 - 表现层
 * 
 * 类比Go后端的登录处理器:
 * ```go
 * func LoginHandler(c *gin.Context) {
 *   // 处理登录请求
 * }
 * ```
 */

import { useState } from 'react';
import Taro from '@tarojs/taro';
import { View, Text, Button, Image } from '@tarojs/components';
import { AtForm, AtInput, AtButton, AtDivider, AtToast } from 'taro-ui';
import { useAuth } from '../../hooks/useAuth';
import { logger } from '../../../infrastructure/logger/logger';

// 登录页面组件 - 类比Go的登录处理器
export default function LoginPage() {
  // 状态管理 - 类比Go的请求状态
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastText, setToastText] = useState('');
  
  // 使用认证Hook - 类比Go的认证服务
  const { login, wechatLogin, error, isLoading } = useAuth();
  
  // 处理表单提交 - 类比Go的登录处理逻辑
  const handleSubmit = async () => {
    if (!email || !password) {
      setToastText('请输入邮箱和密码');
      setShowToast(true);
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      const success = await login(email, password);
      
      if (success) {
        // 登录成功，跳转到首页
        Taro.switchTab({ url: '/pages/index/index' });
      } else {
        setToastText('登录失败，请检查邮箱和密码');
        setShowToast(true);
      }
    } catch (err) {
      logger.error('Login error', err);
      setToastText('登录失败，请稍后重试');
      setShowToast(true);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // 处理微信登录 - 小程序特有
  const handleWechatLogin = async () => {
    try {
      setIsSubmitting(true);
      
      const success = await wechatLogin();
      
      if (success) {
        // 登录成功，跳转到首页
        Taro.switchTab({ url: '/pages/index/index' });
      } else {
        setToastText('微信登录失败，请稍后重试');
        setShowToast(true);
      }
    } catch (err) {
      logger.error('Wechat login error', err);
      setToastText('微信登录失败，请稍后重试');
      setShowToast(true);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // 跳转到注册页面
  const navigateToRegister = () => {
    Taro.navigateTo({ url: '/pages/register/index' });
  };
  
  return (
    <View className='login-page'>
      <View className='login-header'>
        <Image 
          className='logo' 
          src='/assets/images/logo.png' 
          mode='aspectFit' 
        />
        <Text className='title'>项目管理系统</Text>
        <Text className='subtitle'>登录您的账号</Text>
      </View>
      
      <AtForm>
        <AtInput
          name='email'
          title='邮箱'
          type='text'
          placeholder='请输入邮箱'
          value={email}
          onChange={(value) => setEmail(value as string)}
        />
        <AtInput
          name='password'
          title='密码'
          type='password'
          placeholder='请输入密码'
          value={password}
          onChange={(value) => setPassword(value as string)}
        />
        
        <View className='form-actions'>
          <AtButton 
            type='primary' 
            loading={isSubmitting} 
            disabled={isSubmitting || !email || !password}
            onClick={handleSubmit}
          >
            登录
          </AtButton>
          
          <View className='register-link'>
            <Text>还没有账号？</Text>
            <Text className='link' onClick={navigateToRegister}>立即注册</Text>
          </View>
        </View>
      </AtForm>
      
      <AtDivider content='或者' />
      
      <Button 
        className='wechat-login-btn'
        loading={isSubmitting}
        disabled={isSubmitting}
        onClick={handleWechatLogin}
      >
        微信一键登录
      </Button>
      
      <AtToast
        isOpened={showToast || !!error}
        text={error || toastText}
        status='error'
        duration={3000}
        onClose={() => setShowToast(false)}
      />
    </View>
  );
}
