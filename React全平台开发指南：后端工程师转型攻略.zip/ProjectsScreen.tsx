/**
 * 项目列表屏幕 - 表现层
 * 
 * 类比Go后端的项目列表处理器:
 * ```go
 * func ProjectListHandler(c *gin.Context) {
 *   // 处理项目列表请求
 * }
 * ```
 */

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, FAB, ActivityIndicator, Chip, Dialog, Portal, TextInput } from 'react-native-paper';
import { useAuth } from '../../hooks/useAuth';
import { useProject } from '../../hooks/useProject';
import { StackNavigationProp } from '@react-navigation/stack';
import { ProjectStackParamList } from '../../navigation/AppNavigator';
import { Ionicons } from '@expo/vector-icons';
import { Project, ProjectStatus } from '../../../domain/project';

// 导航属性类型
type ProjectsScreenNavigationProp = StackNavigationProp<ProjectStackParamList, 'ProjectsList'>;

// 组件属性类型
type Props = {
  navigation: ProjectsScreenNavigationProp;
};

// 项目列表屏幕组件 - 类比Go的项目列表处理器
export const ProjectsScreen: React.FC<Props> = ({ navigation }) => {
  const { currentUser } = useAuth();
  const { projects, fetchProjects, createProject, archiveProject, deleteProject, isLoading, error } = useProject();
  
  // 创建项目对话框状态
  const [dialogVisible, setDialogVisible] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [dialogLoading, setDialogLoading] = useState(false);

  // 组件挂载时获取项目列表 - 类比Go的初始化逻辑
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  // 处理项目选择 - 类比Go的项目详情跳转
  const handleProjectSelect = (projectId: string) => {
    navigation.navigate('ProjectDetail', { projectId });
  };

  // 处理项目创建 - 类比Go的项目创建处理
  const handleCreateProject = async () => {
    if (!projectName.trim()) {
      Alert.alert('Error', 'Project name is required');
      return;
    }

    try {
      setDialogLoading(true);
      const newProject = await createProject(projectName, projectDescription);
      setDialogVisible(false);
      setProjectName('');
      setProjectDescription('');
      
      // 导航到新创建的项目
      navigation.navigate('ProjectDetail', { projectId: newProject.id });
    } catch (error) {
      Alert.alert('Error', 'Failed to create project');
    } finally {
      setDialogLoading(false);
    }
  };

  // 处理项目归档 - 类比Go的项目归档处理
  const handleArchiveProject = (projectId: string) => {
    Alert.alert(
      'Archive Project',
      'Are you sure you want to archive this project?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Archive', 
          style: 'destructive',
          onPress: async () => {
            try {
              await archiveProject(projectId);
              Alert.alert('Success', 'Project archived successfully');
            } catch (error) {
              Alert.alert('Error', 'Failed to archive project');
            }
          }
        }
      ]
    );
  };

  // 处理项目删除 - 类比Go的项目删除处理
  const handleDeleteProject = (projectId: string) => {
    Alert.alert(
      'Delete Project',
      'Are you sure you want to delete this project? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteProject(projectId);
              Alert.alert('Success', 'Project deleted successfully');
            } catch (error) {
              Alert.alert('Error', 'Failed to delete project');
            }
          }
        }
      ]
    );
  };

  // 渲染项目项 - 类比Go的项目数据格式化
  const renderProjectItem = ({ item }: { item: Project }) => (
    <Card style={styles.projectCard}>
      <TouchableOpacity
        onPress={() => handleProjectSelect(item.id)}
        activeOpacity={0.7}
      >
        <Card.Content>
          <View style={styles.projectHeader}>
            <Title>{item.name}</Title>
            <Chip 
              mode="outlined" 
              style={item.status === ProjectStatus.ACTIVE ? styles.activeChip : styles.archivedChip}
            >
              {item.status}
            </Chip>
          </View>
          <Paragraph style={styles.description}>{item.description}</Paragraph>
          
          <View style={styles.projectMeta}>
            <Text style={styles.metaText}>
              <Ionicons name="people-outline" size={16} /> {item.members.length} members
            </Text>
            <Text style={styles.metaText}>
              <Ionicons name="calendar-outline" size={16} /> Created: {new Date(item.createdAt).toLocaleDateString()}
            </Text>
          </View>
        </Card.Content>
      </TouchableOpacity>
      
      <Card.Actions>
        <Button 
          onPress={() => handleProjectSelect(item.id)}
          color="#4a6da7"
        >
          View
        </Button>
        
        {item.status === ProjectStatus.ACTIVE && (
          <Button 
            onPress={() => handleArchiveProject(item.id)}
            color="#ff9800"
          >
            Archive
          </Button>
        )}
        
        <Button 
          onPress={() => handleDeleteProject(item.id)}
          color="#f44336"
        >
          Delete
        </Button>
      </Card.Actions>
    </Card>
  );

  return (
    <View style={styles.container}>
      {isLoading && projects.length === 0 ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a6da7" />
          <Text style={styles.loadingText}>Loading projects...</Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <Button 
            mode="contained" 
            onPress={fetchProjects}
            style={styles.retryButton}
          >
            Retry
          </Button>
        </View>
      ) : (
        <FlatList
          data={projects}
          renderItem={renderProjectItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="folder-open-outline" size={64} color="#bdbdbd" />
              <Text style={styles.emptyText}>No projects yet</Text>
              <Text style={styles.emptySubText}>Tap the + button to create your first project</Text>
            </View>
          }
        />
      )}

      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => setDialogVisible(true)}
      />

      <Portal>
        <Dialog visible={dialogVisible} onDismiss={() => setDialogVisible(false)}>
          <Dialog.Title>Create New Project</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label="Project Name"
              value={projectName}
              onChangeText={setProjectName}
              style={styles.input}
              disabled={dialogLoading}
            />
            <TextInput
              label="Description"
              value={projectDescription}
              onChangeText={setProjectDescription}
              style={styles.input}
              multiline
              numberOfLines={3}
              disabled={dialogLoading}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDialogVisible(false)} disabled={dialogLoading}>Cancel</Button>
            <Button onPress={handleCreateProject} loading={dialogLoading} disabled={dialogLoading}>Create</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};

// 样式
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  listContent: {
    padding: 16,
    paddingBottom: 80, // 为FAB留出空间
  },
  projectCard: {
    marginBottom: 16,
    elevation: 2,
  },
  projectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  description: {
    color: '#757575',
  },
  projectMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  metaText: {
    fontSize: 12,
    color: '#9e9e9e',
  },
  activeChip: {
    backgroundColor: '#e8f5e9',
  },
  archivedChip: {
    backgroundColor: '#f5f5f5',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#4a6da7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: '#d32f2f',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4a6da7',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    marginTop: 50,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#757575',
    marginTop: 16,
  },
  emptySubText: {
    fontSize: 14,
    color: '#9e9e9e',
    textAlign: 'center',
    marginTop: 8,
  },
  input: {
    marginBottom: 16,
    backgroundColor: '#fff',
  },
});
