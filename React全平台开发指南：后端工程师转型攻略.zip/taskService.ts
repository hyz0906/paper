/**
 * 任务服务 - 应用层
 * 
 * 类比Go后端的应用服务:
 * ```go
 * type TaskService struct {
 *   taskRepo repository.TaskRepository
 *   eventBus events.EventBus
 * }
 * 
 * func NewTaskService(taskRepo repository.TaskRepository, eventBus events.EventBus) *TaskService {
 *   return &TaskService{
 *     taskRepo: taskRepo,
 *     eventBus: eventBus,
 *   }
 * }
 * 
 * func (s *TaskService) CreateTask(ctx context.Context, cmd commands.CreateTaskCommand) (domain.Task, error) {
 *   // 实现创建任务的业务逻辑
 * }
 * ```
 */

import { Task, TaskID, TaskStatus, createTask, TaskCreatedEvent, TaskAssignedEvent, TaskCompletedEvent } from '../domain/task';
import { UserID } from '../domain/user';
import { ProjectID } from '../domain/project';
import { apiClient } from '../infrastructure/api/apiClient';
import { EventBus } from '../infrastructure/events/eventBus';

// 命令模式 - 类比Go的Command对象
export interface CreateTaskCommand {
  title: string;
  description: string;
  projectId: ProjectID;
  assigneeId?: UserID;
  dueDate?: string;
}

export interface UpdateTaskCommand {
  id: TaskID;
  title?: string;
  description?: string;
  status?: TaskStatus;
  assigneeId?: UserID;
  dueDate?: string;
}

export interface AssignTaskCommand {
  taskId: TaskID;
  assigneeId: UserID;
}

export interface CompleteTaskCommand {
  taskId: TaskID;
}

// 应用服务 - 类比Go的Service
export class TaskService {
  private eventBus: EventBus;

  constructor(eventBus: EventBus) {
    this.eventBus = eventBus;
  }

  // 创建任务
  async createTask(command: CreateTaskCommand): Promise<Task> {
    try {
      // 创建任务领域对象
      const task = createTask(
        command.title,
        command.description,
        command.projectId,
        command.assigneeId,
        command.dueDate
      );

      // 调用API保存任务
      const savedTask = await apiClient.post<Task>('/tasks', task);

      // 发布任务创建事件
      const event: TaskCreatedEvent = {
        taskId: savedTask.id,
        projectId: savedTask.projectId,
        createdAt: savedTask.createdAt
      };
      this.eventBus.publish('TaskCreated', event);

      return savedTask;
    } catch (error) {
      console.error('Failed to create task:', error);
      throw error;
    }
  }

  // 获取任务
  async getTask(taskId: TaskID): Promise<Task> {
    try {
      return await apiClient.get<Task>(`/tasks/${taskId}`);
    } catch (error) {
      console.error(`Failed to get task ${taskId}:`, error);
      throw error;
    }
  }

  // 获取项目任务列表
  async getProjectTasks(projectId: ProjectID): Promise<Task[]> {
    try {
      return await apiClient.get<Task[]>(`/projects/${projectId}/tasks`);
    } catch (error) {
      console.error(`Failed to get tasks for project ${projectId}:`, error);
      throw error;
    }
  }

  // 更新任务
  async updateTask(command: UpdateTaskCommand): Promise<Task> {
    try {
      // 获取当前任务
      const currentTask = await this.getTask(command.id);
      
      // 更新任务
      const updatedTask = await apiClient.put<Task>(`/tasks/${command.id}`, {
        ...currentTask,
        ...command,
        updatedAt: new Date().toISOString()
      });

      return updatedTask;
    } catch (error) {
      console.error(`Failed to update task ${command.id}:`, error);
      throw error;
    }
  }

  // 分配任务
  async assignTask(command: AssignTaskCommand): Promise<Task> {
    try {
      // 获取当前任务
      const task = await this.getTask(command.taskId);
      
      // 更新任务
      const updatedTask = await apiClient.put<Task>(`/tasks/${command.taskId}`, {
        ...task,
        assigneeId: command.assigneeId,
        updatedAt: new Date().toISOString()
      });

      // 发布任务分配事件
      const event: TaskAssignedEvent = {
        taskId: updatedTask.id,
        assigneeId: command.assigneeId,
        assignedAt: updatedTask.updatedAt
      };
      this.eventBus.publish('TaskAssigned', event);

      return updatedTask;
    } catch (error) {
      console.error(`Failed to assign task ${command.taskId}:`, error);
      throw error;
    }
  }

  // 完成任务
  async completeTask(command: CompleteTaskCommand): Promise<Task> {
    try {
      // 获取当前任务
      const task = await this.getTask(command.taskId);
      
      // 更新任务状态
      const updatedTask = await apiClient.put<Task>(`/tasks/${command.taskId}`, {
        ...task,
        status: TaskStatus.DONE,
        updatedAt: new Date().toISOString()
      });

      // 发布任务完成事件
      const event: TaskCompletedEvent = {
        taskId: updatedTask.id,
        completedAt: updatedTask.updatedAt
      };
      this.eventBus.publish('TaskCompleted', event);

      return updatedTask;
    } catch (error) {
      console.error(`Failed to complete task ${command.taskId}:`, error);
      throw error;
    }
  }

  // 删除任务
  async deleteTask(taskId: TaskID): Promise<void> {
    try {
      await apiClient.delete(`/tasks/${taskId}`);
    } catch (error) {
      console.error(`Failed to delete task ${taskId}:`, error);
      throw error;
    }
  }
}
