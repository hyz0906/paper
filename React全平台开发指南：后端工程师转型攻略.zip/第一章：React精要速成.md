# 第一章：React精要速成

对于习惯了Golang或Python后端开发的工程师来说，踏入React的前端世界，既是机遇也是挑战。前端开发，特别是现代前端框架如React，拥有其独特的编程范式、状态管理哲学和性能优化技巧。本章旨在通过与后端开发者熟悉的Go/Python概念进行类比，帮助您快速掌握React的核心精髓，平滑过渡到前端开发。

我们将聚焦于后端开发者最关心的几个核心问题：如何理解组件化思想？如何管理状态？如何进行性能调优？以及如何将后端开发的经验有效迁移到前端实践中。

## 1.1 React基础概念与后端对比

在深入React的具体API之前，我们首先需要建立对React核心概念的直观理解。这就像学习一门新的后端语言或框架时，首先要掌握其请求处理模型、数据传递方式和视图渲染机制一样。

### 1.1.1 组件化思想：函数组件与Gin Handler的类比

后端开发中，我们通常会将业务逻辑拆分成不同的处理单元。例如，在Go的Gin框架中，我们会为每个API端点定义一个Handler函数。这个Handler接收请求参数（`gin.Context`），执行业务逻辑，并返回响应。每个Handler相对独立，专注于处理特定的请求。

```go
// Gin Handler 示例
package main

import (
	"net/http"
	"github.com/gin-gonic/gin"
)

func GetUserProfile(c *gin.Context) {
	userID := c.Param("id")
	// ... 根据 userID 查询用户信息的业务逻辑 ...
	userProfile := map[string]string{
		"id":   userID,
		"name": "示例用户",
		"email": "user@example.com",
	}
	c.JSON(http.StatusOK, userProfile)
}

func main() {
	r := gin.Default()
	r.GET("/users/:id", GetUserProfile)
	r.Run() // 监听并在 0.0.0.0:8080 上启动服务
}
```

React的核心思想之一是**组件化（Componentization）**。与Gin Handler类似，React组件也是一个独立的、可复用的单元，但它的职责是**渲染UI**。现代React推荐使用**函数组件（Function Component）**。一个函数组件本质上就是一个JavaScript函数，它接收输入（称为**props**，类似于Gin Handler接收的请求参数），并返回描述UI结构的React元素（通常使用JSX语法编写）。

```jsx
// React 函数组件示例
import React from 'react';

// UserProfile 组件接收一个名为 user 的 prop
function UserProfile({ user }) {
  // user 对象包含了需要展示的用户信息
  // 组件返回描述用户信息的UI结构
  return (
    <div className="user-profile">
      <h2>{user.name}</h2>
      <p>ID: {user.id}</p>
      <p>Email: {user.email}</p>
    </div>
  );
}

// 在其他组件中使用 UserProfile 组件
function App() {
  const sampleUser = {
    id: '123',
    name: '示例用户',
    email: 'user@example.com',
  };

  return (
    <div>
      <h1>用户中心</h1>
      <UserProfile user={sampleUser} />
    </div>
  );
}

export default App;
```

**类比与差异：**

*   **相似性**：
    *   **封装性**：Gin Handler封装了后端API逻辑，React组件封装了UI渲染逻辑。两者都是独立的、可复用的单元。
    *   **输入**：Handler通过`gin.Context`获取输入（路径参数、查询参数、请求体等），组件通过`props`获取输入。
    *   **单一职责**：良好的Handler和组件都应遵循单一职责原则，专注于完成特定的任务。
*   **差异性**：
    *   **输出**：Handler输出HTTP响应（JSON、HTML等），组件输出描述UI的React元素（最终会被渲染成DOM）。
    *   **生命周期与状态**：React组件拥有更复杂的生命周期和内部状态管理机制（将在后续章节详细介绍），而Gin Handler通常是无状态的，每次请求都是独立的执行上下文。
    *   **组合方式**：后端Handler通常通过路由进行组织，而React组件通过嵌套和组合来构建复杂的UI界面。

从后端迁移到前端，理解组件化思想是第一步。你需要将过去组织API逻辑的方式，转变为组织UI模块的方式。将页面拆分成一个个小的、可复用的组件，就像将复杂的后端服务拆分成微服务或独立的模块一样。

### 1.1.2 Props与Context：对比Go函数参数与依赖注入

在Go中，函数之间传递数据最直接的方式是通过函数参数。如果多个函数需要共享某些配置或服务实例（如数据库连接），我们通常会使用结构体嵌入、全局变量（不推荐）或者更优雅的**依赖注入（Dependency Injection, DI）**模式，例如使用`context.Context`传递请求范围的值，或者使用`wire`等库来管理依赖关系。

```go
// Go 依赖注入示例 (使用 context)
package main

import (
	"context"
	"fmt"
)

type dbKey string

func processRequest(ctx context.Context) {
	dbConnection := ctx.Value(dbKey("db")).(string) // 从 context 获取依赖
	fmt.Println("Processing request with DB:", dbConnection)
	// ... 使用 dbConnection 进行操作 ...
}

func main() {
	db := "real_database_connection_string"
	ctx := context.WithValue(context.Background(), dbKey("db"), db)
	processRequest(ctx)
}
```

React中，父组件向子组件传递数据的主要方式是**Props (Properties)**。这非常类似于Go中的函数参数传递。父组件可以将任意JavaScript值（字符串、数字、对象、数组、函数等）作为props传递给子组件，子组件在其函数签名中接收这些props。

```jsx
// React Props 传递示例
import React from 'react';

// 子组件 Button，接收 onClick 和 text 两个 props
function Button({ onClick, text }) {
  return (
    <button onClick={onClick}>
      {text}
    </button>
  );
}

// 父组件 App
function App() {
  const handleClick = () => {
    console.log('按钮被点击了!');
  };

  return (
    <div>
      {/* 将 handleClick 函数和 "点击我" 字符串作为 props 传递给 Button 组件 */}
      <Button onClick={handleClick} text="点击我" />
      <Button onClick={() => console.log('另一个按钮')} text="另一个按钮" />
    </div>
  );
}

export default App;
```

然而，当组件层级很深时，通过props逐层传递数据会变得非常繁琐，这被称为“prop drilling”。为了解决这个问题，React提供了**Context API**。Context提供了一种在组件树中共享数据的方式，而无需显式地通过props逐层传递。

这与Go中使用`context.Context`传递请求范围的值或者依赖注入框架管理共享实例非常相似。你可以将Context看作是React内置的一种依赖注入机制。

```jsx
// React Context API 示例
import React, { createContext, useContext, useState } from 'react';

// 1. 创建 Context 对象
const ThemeContext = createContext('light'); // 默认值为 'light'

// 2. 创建 Provider 组件，用于提供 Context 值
function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  // 将 theme 值和 toggleTheme 函数通过 value prop 提供给后代组件
  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// 3. 在需要使用 Context 的组件中使用 useContext Hook
function ThemedButton() {
  const { theme, toggleTheme } = useContext(ThemeContext); // 获取 Context 值

  return (
    <button
      onClick={toggleTheme}
      style={{ background: theme === 'light' ? '#fff' : '#333', color: theme === 'light' ? '#000' : '#fff' }}
    >
      当前主题: {theme}, 点击切换
    </button>
  );
}

// 4. 在应用顶层使用 Provider 包裹组件树
function App() {
  return (
    <ThemeProvider>
      <div>
        <h1>Context API 示例</h1>
        <ThemedButton />
        {/* 其他组件也可以通过 useContext 获取主题 */}
      </div>
    </ThemeProvider>
  );
}

export default App;
```

**类比与差异：**

*   **Props vs 函数参数**：非常直接的类比，都是显式地将数据传递给下一层处理单元。
*   **Context vs 依赖注入/`context.Context`**：
    *   **相似性**：都解决了跨层级传递共享数据或依赖的问题，避免了逐层传递的繁琐。
    *   **差异性**：React Context主要用于在组件树中共享**状态**或**配置**，而Go的DI和`context.Context`通常用于共享**服务实例**、**配置**或**请求范围的值**。React Context的更新通常会触发相关组件的重新渲染，而Go的依赖注入本身不直接关联渲染。

理解Props和Context的适用场景对于构建可维护的React应用至关重要。Props适用于父子组件间的直接数据传递，而Context适用于跨越多层级的全局状态或主题共享。

### 1.1.3 JSX语法：对比Go模板与Python模板引擎

后端开发中，我们经常需要动态生成HTML。Go语言可以使用内置的`html/template`包，Python则有Jinja2、Django模板等多种选择。这些模板引擎允许我们将数据嵌入到静态的HTML结构中。

```go
// Go html/template 示例
package main

import (
	"html/template"
	"os"
)

type User struct {
	Name string
	Age  int
}

func main() {
	tmpl := `<h1>Hello, {{.Name}}!</h1><p>You are {{.Age}} years old.</p>`
	t, _ := template.New("user").Parse(tmpl)
	user := User{Name: "Alice", Age: 30}
	t.Execute(os.Stdout, user)
}
// 输出: <h1>Hello, Alice!</h1><p>You are 30 years old.</p>
```

```python
# Python Jinja2 示例
from jinja2 import Template

template = Template('<h1>Hello, {{ name }}!</h1><p>You are {{ age }} years old.</p>')
user = {'name': 'Bob', 'age': 25}
output = template.render(user)
print(output)
# 输出: <h1>Hello, Bob!</h1><p>You are 25 years old.</p>
```

React使用**JSX (JavaScript XML)**语法来描述UI结构。JSX看起来非常像HTML，但它本质上是JavaScript的语法扩展。JSX允许你在JavaScript代码中直接编写类似HTML的标记，并通过Babel等工具将其转换为普通的JavaScript函数调用（`React.createElement`）。

```jsx
// React JSX 示例
import React from 'react';

function Greeting({ name, age }) {
  // 在 JSX 中可以直接嵌入 JavaScript 表达式 (用花括号包裹)
  return (
    <div>
      <h1>Hello, {name}!</h1>
      <p>You are {age} years old.</p>
      <p>Next year you will be {age + 1}.</p> {/* 嵌入计算 */} 
      {age >= 18 && <p>You are an adult.</p>} {/* 条件渲染 */} 
    </div>
  );
}

function App() {
  return <Greeting name="Charlie" age={40} />;
}

export default App;
```

**类比与差异：**

*   **相似性**：
    *   **目的**：都是为了将数据和UI结构结合起来，动态生成最终的界面。
    *   **嵌入逻辑**：都允许嵌入变量、进行简单的逻辑判断（如条件渲染）和循环。
*   **差异性**：
    *   **本质**：Go/Python模板引擎通常是**字符串处理**，将数据填充到文本模板中。JSX是**JavaScript语法扩展**，最终会被编译成JavaScript对象（React元素），它拥有更强的编程能力和类型检查（配合TypeScript）。
    *   **集成度**：JSX与JavaScript代码无缝集成，可以在JSX中直接调用JavaScript函数、使用JavaScript变量，反之亦然。模板引擎通常与后端语言的集成相对松散一些。
    *   **关注点**：模板引擎主要关注服务端渲染（SSR）或预渲染。JSX主要用于在客户端（浏览器）或服务端（通过Node.js）描述UI结构，由React库负责将其渲染到DOM或字符串。

对于后端开发者来说，JSX的学习曲线相对平缓，因为它借鉴了熟悉的HTML语法。关键在于理解JSX并非HTML字符串，而是创建React元素的便捷方式，并且它与JavaScript的结合更为紧密。

### 1.1.4 虚拟DOM：对比后端模型与视图的分离

在经典的后端MVC（Model-View-Controller）或类似架构中，模型（Model）负责数据和业务逻辑，视图（View）负责展示数据（通常是HTML模板），控制器（Controller）负责协调两者。当数据变化时，控制器通常会重新渲染整个视图或部分视图。

React引入了**虚拟DOM（Virtual DOM）**的概念。虚拟DOM是对真实DOM的一种轻量级内存表示。当组件的状态（state）或属性（props）发生变化时，React并不会立即去操作真实的浏览器DOM（这是一个相对昂贵的操作），而是会执行以下步骤：

1.  **重新计算**：React会重新调用相关组件的渲染函数（即函数组件本身），生成一个新的虚拟DOM树。
2.  **比较（Diffing）**：React会将新的虚拟DOM树与上一次渲染的旧虚拟DOM树进行比较，找出两者之间的差异（例如，哪个节点的文本变了，哪个节点被添加或删除了）。这个比较算法是高效优化的。
3.  **更新（Reconciliation）**：React只将计算出的差异部分应用到真实的浏览器DOM上，进行最小化的更新。

**类比与差异：**

*   **相似性**：
    *   **分离关注点**：虚拟DOM机制进一步强化了数据（React组件的状态和属性）与视图（真实DOM）的分离。开发者只需要关心如何根据数据生成UI描述（JSX），而无需手动操作DOM。
    *   **变更驱动**：与后端数据变更触发视图更新类似，React中状态或属性的变更会驱动UI的更新。
*   **差异性**：
    *   **抽象层级**：虚拟DOM在真实DOM之上增加了一个抽象层。后端MVC通常是数据模型到HTML字符串的直接映射（或通过模板引擎）。
    *   **性能优化**：虚拟DOM的主要目的是**性能优化**。通过在内存中进行高效的Diffing计算，最大限度地减少了对昂贵的真实DOM的操作，从而提高渲染性能，尤其是在复杂UI或频繁更新的场景下。
    *   **跨平台能力**：虚拟DOM使得React能够脱离浏览器环境。因为React操作的是内存中的虚拟DOM对象，所以可以将这棵树渲染到不同的目标平台，如React Native将其渲染为原生移动组件，或者在服务器端渲染为HTML字符串。

理解虚拟DOM有助于解释为什么React能够实现高效的UI更新。后端开发者可以将虚拟DOM类比为一种**渲染缓存和变更集计算机制**。你只需要声明性地描述你想要的UI状态，React会负责高效地将其同步到实际的界面上。

---

（章节1.1结束，后续将继续撰写1.2 React状态管理）
