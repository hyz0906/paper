/**
 * 注册页面 - 表现层
 * 
 * 类比Go后端的注册处理器:
 * ```go
 * func RegisterHandler(c *gin.Context) {
 *   // 处理注册请求
 * }
 * ```
 */

import React from 'react';
import { Navigate } from 'react-router-dom';
import { RegisterForm } from '../components/AuthComponents';
import { useAuth } from '../hooks/useAuth';

// 注册页面组件 - 类比Go的注册处理器
export const RegisterPage: React.FC = () => {
  const { register, isAuthenticated, isLoading, error } = useAuth();

  // 如果已认证，重定向到仪表盘 - 类比Go的认证检查
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  // 处理注册 - 类比Go的注册处理
  const handleRegister = async (name: string, email: string, password: string) => {
    try {
      await register(name, email, password);
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center">
      <div className="max-w-md w-full mx-auto">
        <div className="bg-white p-8 border border-gray-300 rounded-lg shadow-lg">
          <RegisterForm
            onRegister={handleRegister}
            onSwitchToLogin={() => window.location.href = '/login'}
            isLoading={isLoading}
            error={error}
          />
        </div>
      </div>
    </div>
  );
};
