/**
 * 项目领域模型
 * 
 * 类比Go后端的领域模型:
 * ```go
 * type ProjectID string
 * 
 * type ProjectStatus string
 * 
 * const (
 *   ProjectStatusActive ProjectStatus = "ACTIVE"
 *   ProjectStatusArchived ProjectStatus = "ARCHIVED"
 * )
 * 
 * type Project struct {
 *   ID ProjectID `json:"id"`
 *   Name string `json:"name"`
 *   Description string `json:"description"`
 *   Status ProjectStatus `json:"status"`
 *   OwnerID UserID `json:"ownerId"`
 *   Members []UserID `json:"members"`
 *   CreatedAt time.Time `json:"createdAt"`
 *   UpdatedAt time.Time `json:"updatedAt"`
 * }
 * ```
 */

import { UserID } from './user';

// 值对象
export type ProjectID = string;

// 枚举
export enum ProjectStatus {
  ACTIVE = "ACTIVE",
  ARCHIVED = "ARCHIVED"
}

// 实体
export interface Project {
  id: ProjectID;
  name: string;
  description: string;
  status: ProjectStatus;
  ownerId: UserID;
  members: UserID[];
  createdAt: string; // ISO 8601格式
  updatedAt: string; // ISO 8601格式
}

// 领域事件
export interface ProjectCreatedEvent {
  projectId: ProjectID;
  ownerId: UserID;
  createdAt: string;
}

export interface ProjectArchivedEvent {
  projectId: ProjectID;
  archivedBy: UserID;
  archivedAt: string;
}

export interface MemberAddedEvent {
  projectId: ProjectID;
  userId: UserID;
  addedBy: UserID;
  addedAt: string;
}

// 领域服务
export function isProjectActive(project: Project): boolean {
  return project.status === ProjectStatus.ACTIVE;
}

export function canAddMember(project: Project, userId: UserID): boolean {
  return isProjectActive(project) && !project.members.includes(userId);
}

export function canRemoveMember(project: Project, userId: UserID): boolean {
  return isProjectActive(project) && project.members.includes(userId) && project.ownerId !== userId;
}

export function canArchiveProject(project: Project, userId: UserID): boolean {
  return isProjectActive(project) && project.ownerId === userId;
}

// 值对象工厂
export function createProjectId(): ProjectID {
  return `project-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

// 实体工厂
export function createProject(
  name: string,
  description: string,
  ownerId: UserID,
  members: UserID[] = []
): Project {
  const now = new Date().toISOString();
  // 确保所有者也是成员
  const allMembers = members.includes(ownerId) 
    ? members 
    : [ownerId, ...members];
  
  return {
    id: createProjectId(),
    name,
    description,
    status: ProjectStatus.ACTIVE,
    ownerId,
    members: allMembers,
    createdAt: now,
    updatedAt: now
  };
}
