/**
 * 任务Hook - 表现层
 * 
 * 类比Go后端的任务控制器:
 * ```go
 * type TaskController struct {
 *   service TaskService
 * }
 * ```
 */

import { useState, useCallback, useEffect } from 'react';
import { Task, TaskID, TaskStatus } from '../../domain/task';
import { ProjectID } from '../../domain/project';
import { UserID } from '../../domain/user';
import { taskService } from '../../application/taskService';
import { logger } from '../../infrastructure/logger/logger';
import { eventBus } from '../../infrastructure/events/eventBus';

// 任务状态接口
interface TaskState {
  tasks: Task[];
  currentTask: Task | null;
  isLoading: boolean;
  error: string | null;
}

// 任务Hook返回接口
interface UseTaskReturn extends TaskState {
  fetchProjectTasks: (projectId: ProjectID) => Promise<Task[]>;
  fetchTask: (taskId: TaskID) => Promise<Task | null>;
  createTask: (title: string, description: string, projectId: ProjectID, assigneeId?: UserID) => Promise<Task | null>;
  updateTask: (id: TaskID, updates: { title?: string; description?: string; status?: TaskStatus }) => Promise<Task | null>;
  updateTaskStatus: (taskId: TaskID, status: TaskStatus) => Promise<Task | null>;
  assignTask: (taskId: TaskID, assigneeId: UserID) => Promise<Task | null>;
  deleteTask: (taskId: TaskID) => Promise<boolean>;
}

// 任务Hook - 类比Go的任务控制器
export function useTask(): UseTaskReturn {
  // 状态管理 - 类比Go的控制器状态
  const [state, setState] = useState<TaskState>({
    tasks: [],
    currentTask: null,
    isLoading: false,
    error: null
  });

  // 获取项目任务列表 - 类比Go的GetProjectTasks处理器
  const fetchProjectTasks = useCallback(async (projectId: ProjectID): Promise<Task[]> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const tasks = await taskService.getProjectTasks(projectId);
      
      setState(prev => ({
        ...prev,
        tasks,
        isLoading: false,
        error: null
      }));
      
      return tasks;
    } catch (error) {
      logger.error(`Failed to fetch tasks for project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '获取任务列表失败'
      }));
      
      return [];
    }
  }, []);

  // 获取单个任务 - 类比Go的GetTask处理器
  const fetchTask = useCallback(async (taskId: TaskID): Promise<Task | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const task = await taskService.getTask(taskId);
      
      setState(prev => ({
        ...prev,
        currentTask: task,
        isLoading: false,
        error: null
      }));
      
      return task;
    } catch (error) {
      logger.error(`Failed to fetch task ${taskId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '获取任务详情失败'
      }));
      
      return null;
    }
  }, []);

  // 创建任务 - 类比Go的CreateTask处理器
  const createTask = useCallback(async (
    title: string,
    description: string,
    projectId: ProjectID,
    assigneeId?: UserID
  ): Promise<Task | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const task = await taskService.createTask({
        title,
        description,
        projectId,
        assigneeId
      });
      
      setState(prev => ({
        ...prev,
        tasks: [...prev.tasks, task],
        currentTask: task,
        isLoading: false,
        error: null
      }));
      
      return task;
    } catch (error) {
      logger.error('Failed to create task', error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '创建任务失败'
      }));
      
      return null;
    }
  }, []);

  // 更新任务 - 类比Go的UpdateTask处理器
  const updateTask = useCallback(async (
    id: TaskID,
    updates: { title?: string; description?: string; status?: TaskStatus }
  ): Promise<Task | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const task = await taskService.updateTask({
        id,
        ...updates
      });
      
      setState(prev => ({
        ...prev,
        tasks: prev.tasks.map(t => t.id === id ? task : t),
        currentTask: prev.currentTask?.id === id ? task : prev.currentTask,
        isLoading: false,
        error: null
      }));
      
      return task;
    } catch (error) {
      logger.error(`Failed to update task ${id}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '更新任务失败'
      }));
      
      return null;
    }
  }, []);

  // 更新任务状态 - 类比Go的UpdateTaskStatus处理器
  const updateTaskStatus = useCallback(async (
    taskId: TaskID,
    status: TaskStatus
  ): Promise<Task | null> => {
    return updateTask(taskId, { status });
  }, [updateTask]);

  // 分配任务 - 类比Go的AssignTask处理器
  const assignTask = useCallback(async (
    taskId: TaskID,
    assigneeId: UserID
  ): Promise<Task | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const task = await taskService.assignTask({
        taskId,
        assigneeId
      });
      
      setState(prev => ({
        ...prev,
        tasks: prev.tasks.map(t => t.id === taskId ? task : t),
        currentTask: prev.currentTask?.id === taskId ? task : prev.currentTask,
        isLoading: false,
        error: null
      }));
      
      return task;
    } catch (error) {
      logger.error(`Failed to assign task ${taskId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '分配任务失败'
      }));
      
      return null;
    }
  }, []);

  // 删除任务 - 类比Go的DeleteTask处理器
  const deleteTask = useCallback(async (taskId: TaskID): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      await taskService.deleteTask(taskId);
      
      setState(prev => ({
        ...prev,
        tasks: prev.tasks.filter(t => t.id !== taskId),
        currentTask: prev.currentTask?.id === taskId ? null : prev.currentTask,
        isLoading: false,
        error: null
      }));
      
      return true;
    } catch (error) {
      logger.error(`Failed to delete task ${taskId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '删除任务失败'
      }));
      
      return false;
    }
  }, []);

  // 监听任务事件 - 类比Go的事件监听
  useEffect(() => {
    // 任务创建事件处理
    const createdUnsubscribe = eventBus.subscribe('task:created', (data: any) => {
      if (data.taskId) {
        fetchTask(data.taskId);
      }
    });
    
    // 任务更新事件处理
    const updatedUnsubscribe = eventBus.subscribe('task:updated', (data: any) => {
      if (data.taskId && state.currentTask?.id === data.taskId) {
        fetchTask(data.taskId);
      }
    });
    
    // 清理订阅
    return () => {
      createdUnsubscribe();
      updatedUnsubscribe();
    };
  }, [fetchTask, state.currentTask]);

  return {
    ...state,
    fetchProjectTasks,
    fetchTask,
    createTask,
    updateTask,
    updateTaskStatus,
    assignTask,
    deleteTask
  };
}
