/**
 * 仪表盘屏幕 - 表现层
 * 
 * 类比Go后端的仪表盘处理器:
 * ```go
 * func DashboardHandler(c *gin.Context) {
 *   // 处理仪表盘请求
 * }
 * ```
 */

import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, Divider } from 'react-native-paper';
import { useAuth } from '../../hooks/useAuth';
import { useProject } from '../../hooks/useProject';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { MainTabParamList } from '../../navigation/AppNavigator';
import { Ionicons } from '@expo/vector-icons';

// 导航属性类型
type DashboardScreenNavigationProp = BottomTabNavigationProp<MainTabParamList, 'Dashboard'>;

// 组件属性类型
type Props = {
  navigation: DashboardScreenNavigationProp;
};

// 仪表盘屏幕组件 - 类比Go的仪表盘处理器
export const DashboardScreen: React.FC<Props> = ({ navigation }) => {
  const { currentUser } = useAuth();
  const { projects, fetchProjects, isLoading, error } = useProject();

  // 组件挂载时获取项目列表 - 类比Go的初始化逻辑
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  // 最近活动项目 - 取最新的3个项目
  const recentProjects = projects.slice(0, 3);

  // 导航到项目详情
  const navigateToProject = (projectId: string) => {
    navigation.navigate('Projects', {
      screen: 'ProjectDetail',
      params: { projectId }
    });
  };

  // 导航到项目列表
  const navigateToProjects = () => {
    navigation.navigate('Projects');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Welcome, {currentUser?.name}</Text>
        <Text style={styles.subGreeting}>Here's an overview of your projects and tasks</Text>
      </View>

      <ScrollView style={styles.content}>
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#4a6da7" />
            <Text style={styles.loadingText}>Loading dashboard data...</Text>
          </View>
        ) : error ? (
          <Card style={styles.errorCard}>
            <Card.Content>
              <Text style={styles.errorText}>{error}</Text>
            </Card.Content>
          </Card>
        ) : (
          <>
            {/* 最近项目卡片 */}
            <Card style={styles.card}>
              <Card.Content>
                <Title>Recent Projects</Title>
                
                {recentProjects.length === 0 ? (
                  <Paragraph style={styles.emptyText}>No projects yet</Paragraph>
                ) : (
                  <View style={styles.projectsList}>
                    {recentProjects.map(project => (
                      <TouchableOpacity 
                        key={project.id} 
                        onPress={() => navigateToProject(project.id)}
                        style={styles.projectItem}
                      >
                        <View>
                          <Text style={styles.projectTitle}>{project.name}</Text>
                          <Text style={styles.projectDescription}>{project.description}</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color="#4a6da7" />
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
              </Card.Content>
              <Card.Actions>
                <Button 
                  onPress={navigateToProjects}
                  color="#4a6da7"
                >
                  View All Projects
                </Button>
              </Card.Actions>
            </Card>
            
            {/* 统计卡片 */}
            <Card style={styles.card}>
              <Card.Content>
                <Title>Statistics</Title>
                
                <View style={styles.statsGrid}>
                  <View style={[styles.statItem, { backgroundColor: '#e3f2fd' }]}>
                    <Text style={styles.statLabel}>Total Projects</Text>
                    <Text style={styles.statValue}>{projects.length}</Text>
                  </View>
                  
                  <View style={[styles.statItem, { backgroundColor: '#e8f5e9' }]}>
                    <Text style={styles.statLabel}>Active Projects</Text>
                    <Text style={styles.statValue}>
                      {projects.filter(p => p.status === 'ACTIVE').length}
                    </Text>
                  </View>
                  
                  <View style={[styles.statItem, { backgroundColor: '#fff8e1' }]}>
                    <Text style={styles.statLabel}>Your Tasks</Text>
                    <Text style={styles.statValue}>--</Text>
                  </View>
                  
                  <View style={[styles.statItem, { backgroundColor: '#f3e5f5' }]}>
                    <Text style={styles.statLabel}>Completed Tasks</Text>
                    <Text style={styles.statValue}>--</Text>
                  </View>
                </View>
              </Card.Content>
            </Card>
            
            {/* 快速操作卡片 */}
            <Card style={styles.card}>
              <Card.Content>
                <Title>Quick Actions</Title>
              </Card.Content>
              <Card.Actions style={styles.quickActions}>
                <Button 
                  mode="contained" 
                  onPress={navigateToProjects}
                  style={[styles.actionButton, { backgroundColor: '#4a6da7' }]}
                >
                  Create New Project
                </Button>
                
                {projects.length > 0 && (
                  <Button 
                    mode="contained"
                    onPress={() => navigateToProject(projects[0].id)}
                    style={[styles.actionButton, { backgroundColor: '#43a047' }]}
                  >
                    Add New Task
                  </Button>
                )}
                
                <Button 
                  mode="contained"
                  onPress={navigateToProjects}
                  style={[styles.actionButton, { backgroundColor: '#7e57c2' }]}
                >
                  View All Projects
                </Button>
              </Card.Actions>
            </Card>
          </>
        )}
      </ScrollView>
    </View>
  );
};

// 样式
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#4a6da7',
    padding: 20,
    paddingTop: 40,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  subGreeting: {
    fontSize: 16,
    color: '#e1e1e1',
    marginTop: 5,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  card: {
    marginBottom: 16,
    elevation: 2,
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  },
  errorCard: {
    backgroundColor: '#ffebee',
  },
  errorText: {
    color: '#d32f2f',
  },
  emptyText: {
    color: '#757575',
    fontStyle: 'italic',
    marginTop: 10,
  },
  projectsList: {
    marginTop: 10,
  },
  projectItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  projectTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#4a6da7',
  },
  projectDescription: {
    fontSize: 14,
    color: '#757575',
    marginTop: 2,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 10,
    justifyContent: 'space-between',
  },
  statItem: {
    width: '48%',
    padding: 16,
    borderRadius: 8,
    marginBottom: 10,
  },
  statLabel: {
    fontSize: 14,
    color: '#757575',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 5,
  },
  quickActions: {
    flexDirection: 'column',
    alignItems: 'stretch',
  },
  actionButton: {
    marginVertical: 5,
  },
});
