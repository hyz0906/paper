/**
 * 用户领域模型
 * 
 * 类比Go后端的领域模型:
 * ```go
 * type UserID string
 * 
 * type UserRole string
 * 
 * const (
 *   UserRoleAdmin UserRole = "ADMIN"
 *   UserRoleMember UserRole = "MEMBER"
 *   UserRoleViewer UserRole = "VIEWER"
 * )
 * 
 * type User struct {
 *   ID UserID `json:"id"`
 *   Email string `json:"email"`
 *   Name string `json:"name"`
 *   Role UserRole `json:"role"`
 *   AvatarURL string `json:"avatarUrl,omitempty"`
 *   CreatedAt time.Time `json:"createdAt"`
 *   UpdatedAt time.Time `json:"updatedAt"`
 * }
 * ```
 */

// 值对象
export type UserID = string;

// 枚举
export enum UserRole {
  ADMIN = "ADMIN",
  MEMBER = "MEMBER",
  VIEWER = "VIEWER"
}

// 实体
export interface User {
  id: UserID;
  email: string;
  name: string;
  role: UserRole;
  avatarUrl?: string;
  createdAt: string; // ISO 8601格式
  updatedAt: string; // ISO 8601格式
}

// 领域事件
export interface UserRegisteredEvent {
  userId: UserID;
  email: string;
  registeredAt: string;
}

export interface UserRoleChangedEvent {
  userId: UserID;
  oldRole: UserRole;
  newRole: UserRole;
  changedAt: string;
}

// 领域服务
export function canManageUsers(user: User): boolean {
  return user.role === UserRole.ADMIN;
}

export function canEditProject(user: User): boolean {
  return user.role === UserRole.ADMIN || user.role === UserRole.MEMBER;
}

export function canViewProject(user: User): boolean {
  return true; // 所有角色都可以查看项目
}

// 值对象工厂
export function createUserId(): UserID {
  return `user-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

// 实体工厂
export function createUser(
  email: string,
  name: string,
  role: UserRole = UserRole.MEMBER,
  avatarUrl?: string
): User {
  const now = new Date().toISOString();
  return {
    id: createUserId(),
    email,
    name,
    role,
    avatarUrl,
    createdAt: now,
    updatedAt: now
  };
}
