/**
 * 项目Hook - 表现层
 * 
 * 类比Go后端的项目控制器:
 * ```go
 * type ProjectController struct {
 *   service ProjectService
 * }
 * ```
 */

import { useState, useCallback, useEffect } from 'react';
import { Project, ProjectID, ProjectStatus } from '../../domain/project';
import { UserID } from '../../domain/user';
import { projectService } from '../../application/projectService';
import { logger } from '../../infrastructure/logger/logger';
import { eventBus } from '../../infrastructure/events/eventBus';

// 项目状态接口
interface ProjectState {
  projects: Project[];
  currentProject: Project | null;
  isLoading: boolean;
  error: string | null;
}

// 项目Hook返回接口
interface UseProjectReturn extends ProjectState {
  fetchUserProjects: (userId: UserID) => Promise<Project[]>;
  fetchProject: (projectId: ProjectID) => Promise<Project | null>;
  createProject: (name: string, description: string, ownerId: UserID) => Promise<Project | null>;
  updateProject: (id: ProjectID, updates: { name?: string; description?: string }) => Promise<Project | null>;
  archiveProject: (projectId: ProjectID) => Promise<Project | null>;
  activateProject: (projectId: ProjectID) => Promise<Project | null>;
  deleteProject: (projectId: ProjectID) => Promise<boolean>;
  addProjectMember: (projectId: ProjectID, userId: UserID) => Promise<Project | null>;
  removeProjectMember: (projectId: ProjectID, userId: UserID) => Promise<Project | null>;
}

// 项目Hook - 类比Go的项目控制器
export function useProject(): UseProjectReturn {
  // 状态管理 - 类比Go的控制器状态
  const [state, setState] = useState<ProjectState>({
    projects: [],
    currentProject: null,
    isLoading: false,
    error: null
  });

  // 获取用户项目列表 - 类比Go的GetUserProjects处理器
  const fetchUserProjects = useCallback(async (userId: UserID): Promise<Project[]> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const projects = await projectService.getUserProjects(userId);
      
      setState(prev => ({
        ...prev,
        projects,
        isLoading: false,
        error: null
      }));
      
      return projects;
    } catch (error) {
      logger.error(`Failed to fetch projects for user ${userId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '获取项目列表失败'
      }));
      
      return [];
    }
  }, []);

  // 获取单个项目 - 类比Go的GetProject处理器
  const fetchProject = useCallback(async (projectId: ProjectID): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.getProject(projectId);
      
      setState(prev => ({
        ...prev,
        currentProject: project,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error(`Failed to fetch project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '获取项目详情失败'
      }));
      
      return null;
    }
  }, []);

  // 创建项目 - 类比Go的CreateProject处理器
  const createProject = useCallback(async (
    name: string,
    description: string,
    ownerId: UserID
  ): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.createProject({
        name,
        description,
        ownerId
      });
      
      setState(prev => ({
        ...prev,
        projects: [...prev.projects, project],
        currentProject: project,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error('Failed to create project', error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '创建项目失败'
      }));
      
      return null;
    }
  }, []);

  // 更新项目 - 类比Go的UpdateProject处理器
  const updateProject = useCallback(async (
    id: ProjectID,
    updates: { name?: string; description?: string }
  ): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.updateProject({
        id,
        ...updates
      });
      
      setState(prev => ({
        ...prev,
        projects: prev.projects.map(p => p.id === id ? project : p),
        currentProject: prev.currentProject?.id === id ? project : prev.currentProject,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error(`Failed to update project ${id}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '更新项目失败'
      }));
      
      return null;
    }
  }, []);

  // 归档项目 - 类比Go的ArchiveProject处理器
  const archiveProject = useCallback(async (projectId: ProjectID): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.archiveProject(projectId);
      
      setState(prev => ({
        ...prev,
        projects: prev.projects.map(p => p.id === projectId ? project : p),
        currentProject: prev.currentProject?.id === projectId ? project : prev.currentProject,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error(`Failed to archive project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '归档项目失败'
      }));
      
      return null;
    }
  }, []);

  // 激活项目 - 类比Go的ActivateProject处理器
  const activateProject = useCallback(async (projectId: ProjectID): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.activateProject(projectId);
      
      setState(prev => ({
        ...prev,
        projects: prev.projects.map(p => p.id === projectId ? project : p),
        currentProject: prev.currentProject?.id === projectId ? project : prev.currentProject,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error(`Failed to activate project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '激活项目失败'
      }));
      
      return null;
    }
  }, []);

  // 删除项目 - 类比Go的DeleteProject处理器
  const deleteProject = useCallback(async (projectId: ProjectID): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      await projectService.deleteProject(projectId);
      
      setState(prev => ({
        ...prev,
        projects: prev.projects.filter(p => p.id !== projectId),
        currentProject: prev.currentProject?.id === projectId ? null : prev.currentProject,
        isLoading: false,
        error: null
      }));
      
      return true;
    } catch (error) {
      logger.error(`Failed to delete project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '删除项目失败'
      }));
      
      return false;
    }
  }, []);

  // 添加项目成员 - 类比Go的AddProjectMember处理器
  const addProjectMember = useCallback(async (
    projectId: ProjectID,
    userId: UserID
  ): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.addProjectMember({ projectId, userId });
      
      setState(prev => ({
        ...prev,
        projects: prev.projects.map(p => p.id === projectId ? project : p),
        currentProject: prev.currentProject?.id === projectId ? project : prev.currentProject,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error(`Failed to add member to project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '添加项目成员失败'
      }));
      
      return null;
    }
  }, []);

  // 移除项目成员 - 类比Go的RemoveProjectMember处理器
  const removeProjectMember = useCallback(async (
    projectId: ProjectID,
    userId: UserID
  ): Promise<Project | null> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const project = await projectService.removeProjectMember({ projectId, userId });
      
      setState(prev => ({
        ...prev,
        projects: prev.projects.map(p => p.id === projectId ? project : p),
        currentProject: prev.currentProject?.id === projectId ? project : prev.currentProject,
        isLoading: false,
        error: null
      }));
      
      return project;
    } catch (error) {
      logger.error(`Failed to remove member from project ${projectId}`, error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '移除项目成员失败'
      }));
      
      return null;
    }
  }, []);

  // 监听项目事件 - 类比Go的事件监听
  useEffect(() => {
    // 项目创建事件处理
    const createdUnsubscribe = eventBus.subscribe('project:created', (data: any) => {
      if (data.projectId) {
        fetchProject(data.projectId);
      }
    });
    
    // 项目更新事件处理
    const updatedUnsubscribe = eventBus.subscribe('project:updated', (data: any) => {
      if (data.projectId && state.currentProject?.id === data.projectId) {
        fetchProject(data.projectId);
      }
    });
    
    // 清理订阅
    return () => {
      createdUnsubscribe();
      updatedUnsubscribe();
    };
  }, [fetchProject, state.currentProject]);

  return {
    ...state,
    fetchUserProjects,
    fetchProject,
    createProject,
    updateProject,
    archiveProject,
    activateProject,
    deleteProject,
    addProjectMember,
    removeProjectMember
  };
}
