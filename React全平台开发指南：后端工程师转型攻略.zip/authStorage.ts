/**
 * 认证存储 - 基础设施层
 * 
 * 类比Go后端的认证存储:
 * ```go
 * type AuthStorage struct {
 *   tokenStore store.Store
 * }
 * 
 * func NewAuthStorage(tokenStore store.Store) *AuthStorage {
 *   return &AuthStorage{
 *     tokenStore: tokenStore,
 *   }
 * }
 * 
 * func (s *AuthStorage) SaveToken(token string) error {
 *   // 实现保存令牌逻辑
 * }
 * ```
 */

// 存储键常量
const AUTH_TOKEN_KEY = 'auth_token';
const USER_INFO_KEY = 'user_info';

// 保存认证令牌 - 类比Go的SaveToken方法
export async function saveAuthToken(token: string): Promise<void> {
  try {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
  } catch (error) {
    console.error('Failed to save auth token:', error);
    throw error;
  }
}

// 获取认证令牌 - 类比Go的GetToken方法
export async function getAuthToken(): Promise<string | null> {
  try {
    return localStorage.getItem(AUTH_TOKEN_KEY);
  } catch (error) {
    console.error('Failed to get auth token:', error);
    return null;
  }
}

// 删除认证令牌 - 类比Go的RemoveToken方法
export async function removeAuthToken(): Promise<void> {
  try {
    localStorage.removeItem(AUTH_TOKEN_KEY);
  } catch (error) {
    console.error('Failed to remove auth token:', error);
    throw error;
  }
}

// 保存用户信息 - 类比Go的SaveUserInfo方法
export async function saveUserInfo(userInfo: any): Promise<void> {
  try {
    localStorage.setItem(USER_INFO_KEY, JSON.stringify(userInfo));
  } catch (error) {
    console.error('Failed to save user info:', error);
    throw error;
  }
}

// 获取用户信息 - 类比Go的GetUserInfo方法
export async function getUserInfo<T>(): Promise<T | null> {
  try {
    const userInfoStr = localStorage.getItem(USER_INFO_KEY);
    if (!userInfoStr) {
      return null;
    }
    return JSON.parse(userInfoStr) as T;
  } catch (error) {
    console.error('Failed to get user info:', error);
    return null;
  }
}

// 删除用户信息 - 类比Go的RemoveUserInfo方法
export async function removeUserInfo(): Promise<void> {
  try {
    localStorage.removeItem(USER_INFO_KEY);
  } catch (error) {
    console.error('Failed to remove user info:', error);
    throw error;
  }
}

// 清除所有认证数据 - 类比Go的ClearAll方法
export async function clearAuthData(): Promise<void> {
  try {
    await removeAuthToken();
    await removeUserInfo();
  } catch (error) {
    console.error('Failed to clear auth data:', error);
    throw error;
  }
}
