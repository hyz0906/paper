/**
 * 项目页面 - 表现层
 * 
 * 类比Go后端的项目列表处理器:
 * ```go
 * func ProjectListHandler(c *gin.Context) {
 *   // 处理项目列表请求
 * }
 * ```
 */

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useProject } from '../hooks/useProject';
import { ProjectList, CreateProjectForm } from '../components/ProjectComponents';

// 项目页面组件 - 类比Go的项目列表处理器
export const ProjectPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { 
    projects, 
    fetchProjects, 
    createProject, 
    archiveProject, 
    deleteProject,
    isLoading, 
    error 
  } = useProject();
  const navigate = useNavigate();

  // 组件挂载时获取项目列表 - 类比Go的初始化逻辑
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  // 处理项目创建 - 类比Go的项目创建处理
  const handleCreateProject = async (name: string, description: string) => {
    try {
      const newProject = await createProject(name, description);
      navigate(`/projects/${newProject.id}`);
    } catch (error) {
      console.error('Failed to create project:', error);
    }
  };

  // 处理项目归档 - 类比Go的项目归档处理
  const handleArchiveProject = async (projectId: string) => {
    try {
      await archiveProject(projectId);
    } catch (error) {
      console.error('Failed to archive project:', error);
    }
  };

  // 处理项目删除 - 类比Go的项目删除处理
  const handleDeleteProject = async (projectId: string) => {
    try {
      await deleteProject(projectId);
    } catch (error) {
      console.error('Failed to delete project:', error);
    }
  };

  // 处理项目选择 - 类比Go的项目详情跳转
  const handleProjectSelect = (projectId: string) => {
    navigate(`/projects/${projectId}`);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Projects</h1>
        <p className="text-gray-600">Manage your projects and tasks</p>
      </div>

      <CreateProjectForm onProjectCreate={handleCreateProject} />

      {isLoading && projects.length === 0 ? (
        <div className="text-center py-8">
          <p>Loading projects...</p>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      ) : (
        <ProjectList
          projects={projects}
          currentUser={currentUser!}
          onArchive={handleArchiveProject}
          onDelete={handleDeleteProject}
          onProjectSelect={handleProjectSelect}
        />
      )}
    </div>
  );
};
