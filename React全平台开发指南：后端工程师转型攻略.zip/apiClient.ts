/**
 * API客户端 - 基础设施层
 * 
 * 类比Go后端的HTTP客户端:
 * ```go
 * type APIClient struct {
 *   baseURL string
 *   httpClient *http.Client
 * }
 * 
 * func NewAPIClient(baseURL string) *APIClient {
 *   return &APIClient{
 *     baseURL: baseURL,
 *     httpClient: &http.Client{
 *       Timeout: 10 * time.Second,
 *     },
 *   }
 * }
 * 
 * func (c *APIClient) Get(path string) ([]byte, error) {
 *   // 实现GET请求
 * }
 * ```
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { getAuthToken } from '../storage/authStorage';

// 类比Go的APIClient结构体
class ApiClient {
  private client: AxiosInstance;
  private baseURL: string;

  constructor(baseURL: string) {
    this.baseURL = baseURL;
    this.client = axios.create({
      baseURL,
      timeout: 10000, // 10秒超时，类比Go的http.Client超时设置
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // 请求拦截器 - 类比Go的请求中间件
    this.client.interceptors.request.use(
      async (config) => {
        // 添加认证令牌
        const token = await getAuthToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // 响应拦截器 - 类比Go的响应中间件
    this.client.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        // 处理常见错误
        if (error.response) {
          // 服务器响应错误
          switch (error.response.status) {
            case 401:
              // 未授权，可以触发登出或刷新令牌
              console.error('Unauthorized access');
              // 可以在这里触发登出操作
              break;
            case 403:
              console.error('Forbidden access');
              break;
            case 404:
              console.error('Resource not found');
              break;
            case 500:
              console.error('Server error');
              break;
            default:
              console.error(`HTTP error: ${error.response.status}`);
          }
        } else if (error.request) {
          // 请求发送但没有收到响应
          console.error('No response received from server');
        } else {
          // 请求设置错误
          console.error('Request configuration error:', error.message);
        }
        return Promise.reject(error);
      }
    );
  }

  // GET请求 - 类比Go的Get方法
  async get<T>(path: string, config?: AxiosRequestConfig): Promise<T> {
    try {
      const response: AxiosResponse<T> = await this.client.get(path, config);
      return response.data;
    } catch (error) {
      console.error(`GET request failed for ${path}:`, error);
      throw error;
    }
  }

  // POST请求 - 类比Go的Post方法
  async post<T>(path: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    try {
      const response: AxiosResponse<T> = await this.client.post(path, data, config);
      return response.data;
    } catch (error) {
      console.error(`POST request failed for ${path}:`, error);
      throw error;
    }
  }

  // PUT请求 - 类比Go的Put方法
  async put<T>(path: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    try {
      const response: AxiosResponse<T> = await this.client.put(path, data, config);
      return response.data;
    } catch (error) {
      console.error(`PUT request failed for ${path}:`, error);
      throw error;
    }
  }

  // DELETE请求 - 类比Go的Delete方法
  async delete<T>(path: string, config?: AxiosRequestConfig): Promise<T> {
    try {
      const response: AxiosResponse<T> = await this.client.delete(path, config);
      return response.data;
    } catch (error) {
      console.error(`DELETE request failed for ${path}:`, error);
      throw error;
    }
  }

  // 批量请求 - 类比Go的并发请求
  async all<T>(requests: Promise<T>[]): Promise<T[]> {
    try {
      return await Promise.all(requests);
    } catch (error) {
      console.error('Batch request failed:', error);
      throw error;
    }
  }
}

// 创建API客户端实例 - 类比Go的NewAPIClient函数
export const apiClient = new ApiClient(
  process.env.REACT_APP_API_URL || 'http://localhost:3001/api'
);
