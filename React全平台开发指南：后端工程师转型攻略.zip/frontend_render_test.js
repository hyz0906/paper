/**
 * 前端渲染性能测试脚本 - React组件渲染性能测试
 * 
 * 本脚本用于测试React前端渲染的性能指标，包括初始渲染时间、重渲染时间等
 * 测试结果将与Go后端API性能进行对比
 */

import React from 'react';
import ReactDOM from 'react-dom';
import { act } from 'react-dom/test-utils';
import { MemoryRouter } from 'react-router-dom';
import { Profiler } from 'react';

// 导入测试组件
import ProjectList from '../web-example/src/presentation/pages/ProjectPage';
import ProjectDetail from '../web-example/src/presentation/pages/ProjectDetailPage';
import TaskList from '../web-example/src/presentation/components/TaskComponents';

// 性能数据收集
const performanceData = {
  initialRender: [],
  rerender: [],
  componentBreakdown: {},
  memoryUsage: []
};

// Profiler回调函数
const onRenderCallback = (
  id, // 发生提交的 Profiler 树的 "id"
  phase, // "mount" （首次挂载） 或 "update" （重渲染）
  actualDuration, // 本次更新 committed 花费的渲染时间
  baseDuration, // 估计不使用 memoization 的情况下渲染整颗子树需要的时间
  startTime, // 本次更新中 React 开始渲染的时间
  commitTime, // 本次更新中 React committed 的时间
  interactions // 属于本次更新的 interactions 的集合
) => {
  // 记录性能数据
  if (phase === 'mount') {
    performanceData.initialRender.push({
      component: id,
      duration: actualDuration,
      timestamp: commitTime
    });
  } else {
    performanceData.rerender.push({
      component: id,
      duration: actualDuration,
      timestamp: commitTime
    });
  }
  
  // 组件细分性能
  if (!performanceData.componentBreakdown[id]) {
    performanceData.componentBreakdown[id] = [];
  }
  
  performanceData.componentBreakdown[id].push({
    phase,
    actualDuration,
    baseDuration,
    timestamp: commitTime
  });
};

// 测试容器
const container = document.createElement('div');
document.body.appendChild(container);

// 记录内存使用
function recordMemoryUsage() {
  if (window.performance && window.performance.memory) {
    performanceData.memoryUsage.push({
      timestamp: Date.now(),
      usedJSHeapSize: window.performance.memory.usedJSHeapSize,
      totalJSHeapSize: window.performance.memory.totalJSHeapSize
    });
  }
}

// 清理测试容器
function cleanupContainer() {
  ReactDOM.unmountComponentAtNode(container);
}

// 测试数据
const testProjects = Array(100).fill(null).map((_, index) => ({
  id: `project-${index}`,
  name: `Project ${index}`,
  description: `This is test project ${index}`,
  status: index % 3 === 0 ? 'ARCHIVED' : 'ACTIVE',
  ownerId: 'user-1',
  members: ['user-1', 'user-2'],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
}));

const testTasks = Array(200).fill(null).map((_, index) => ({
  id: `task-${index}`,
  title: `Task ${index}`,
  description: `This is test task ${index}`,
  status: index % 3 === 0 ? 'DONE' : (index % 3 === 1 ? 'IN_PROGRESS' : 'TODO'),
  projectId: `project-${Math.floor(index / 10)}`,
  assigneeId: index % 2 === 0 ? 'user-1' : undefined,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
}));

// 测试1: 项目列表初始渲染性能
function testProjectListInitialRender() {
  console.log('Testing ProjectList initial render performance...');
  recordMemoryUsage();
  
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="ProjectList" onRender={onRenderCallback}>
          <ProjectList projects={testProjects} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
}

// 测试2: 项目列表重渲染性能
function testProjectListRerender() {
  console.log('Testing ProjectList rerender performance...');
  
  // 首次渲染
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="ProjectList" onRender={onRenderCallback}>
          <ProjectList projects={testProjects.slice(0, 50)} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
  
  // 重渲染 - 增加项目数量
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="ProjectList" onRender={onRenderCallback}>
          <ProjectList projects={testProjects} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
}

// 测试3: 项目详情页面渲染性能
function testProjectDetailRender() {
  console.log('Testing ProjectDetail render performance...');
  recordMemoryUsage();
  
  const testProject = testProjects[0];
  const projectTasks = testTasks.filter(task => task.projectId === testProject.id);
  
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="ProjectDetail" onRender={onRenderCallback}>
          <ProjectDetail 
            project={testProject} 
            tasks={projectTasks}
            isLoading={false} 
            error={null} 
          />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
}

// 测试4: 任务列表渲染性能
function testTaskListRender() {
  console.log('Testing TaskList render performance...');
  recordMemoryUsage();
  
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="TaskList" onRender={onRenderCallback}>
          <TaskList tasks={testTasks} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
}

// 测试5: 任务列表筛选性能
function testTaskListFiltering() {
  console.log('Testing TaskList filtering performance...');
  
  // 首次渲染所有任务
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="TaskListFiltering" onRender={onRenderCallback}>
          <TaskList tasks={testTasks} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
  
  // 筛选待处理任务
  const todoTasks = testTasks.filter(task => task.status === 'TODO');
  
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="TaskListFiltering" onRender={onRenderCallback}>
          <TaskList tasks={todoTasks} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
  
  // 筛选进行中任务
  const inProgressTasks = testTasks.filter(task => task.status === 'IN_PROGRESS');
  
  act(() => {
    ReactDOM.render(
      <MemoryRouter>
        <Profiler id="TaskListFiltering" onRender={onRenderCallback}>
          <TaskList tasks={inProgressTasks} isLoading={false} error={null} />
        </Profiler>
      </MemoryRouter>,
      container
    );
  });
  
  recordMemoryUsage();
}

// 运行所有测试
async function runAllTests() {
  console.log('Starting React rendering performance tests...');
  
  // 测试1: 项目列表初始渲染
  testProjectListInitialRender();
  cleanupContainer();
  
  // 测试2: 项目列表重渲染
  testProjectListRerender();
  cleanupContainer();
  
  // 测试3: 项目详情页面渲染
  testProjectDetailRender();
  cleanupContainer();
  
  // 测试4: 任务列表渲染
  testTaskListRender();
  cleanupContainer();
  
  // 测试5: 任务列表筛选
  testTaskListFiltering();
  cleanupContainer();
  
  // 输出性能数据
  console.log('Performance test results:');
  console.log(JSON.stringify(performanceData, null, 2));
  
  // 保存性能数据到文件
  if (typeof window.savePerformanceData === 'function') {
    window.savePerformanceData(performanceData);
  }
  
  console.log('React rendering performance tests completed.');
}

// 导出测试函数
export { runAllTests };
