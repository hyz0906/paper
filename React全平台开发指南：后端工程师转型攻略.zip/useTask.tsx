/**
 * 任务Hook - 表现层
 * 
 * 类比Go后端的任务服务:
 * ```go
 * type TaskService struct {
 *   // ...
 * }
 * 
 * func (s *TaskService) GetProjectTasks(projectID string) ([]Task, error) {
 *   // 获取项目任务逻辑
 * }
 * ```
 */

import { useState, useCallback, useContext, createContext } from 'react';
import { Task, TaskID, TaskStatus } from '../../domain/task';
import { taskService } from '../../application/taskService';
import { useAuth } from './useAuth';
import { logger } from '../../infrastructure/logger/logger';
import { ProjectID } from '../../domain/project';

// 任务上下文类型
interface TaskContextType {
  tasks: Task[];
  currentTask: Task | null;
  isLoading: boolean;
  error: string | null;
  fetchTasks: (projectId: ProjectID) => Promise<void>;
  fetchTask: (taskId: TaskID) => Promise<void>;
  createTask: (title: string, description: string, projectId: ProjectID) => Promise<Task>;
  updateTaskStatus: (taskId: TaskID, status: TaskStatus) => Promise<Task>;
  assignTask: (taskId: TaskID, userId: string) => Promise<Task>;
  deleteTask: (taskId: TaskID) => Promise<void>;
}

// 创建任务上下文 - 类比Go的上下文
const TaskContext = createContext<TaskContextType>({
  tasks: [],
  currentTask: null,
  isLoading: false,
  error: null,
  fetchTasks: async () => {},
  fetchTask: async () => {},
  createTask: async () => ({ id: '', title: '', description: '', status: TaskStatus.TODO, projectId: '', createdAt: '', updatedAt: '' }),
  updateTaskStatus: async () => ({ id: '', title: '', description: '', status: TaskStatus.TODO, projectId: '', createdAt: '', updatedAt: '' }),
  assignTask: async () => ({ id: '', title: '', description: '', status: TaskStatus.TODO, projectId: '', createdAt: '', updatedAt: '' }),
  deleteTask: async () => {},
});

// 任务提供者组件 - 类比Go的服务提供者
export const TaskProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [currentTask, setCurrentTask] = useState<Task | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { currentUser } = useAuth();

  // 获取项目任务列表 - 类比Go的获取任务列表
  const fetchTasks = useCallback(async (projectId: ProjectID) => {
    try {
      setIsLoading(true);
      setError(null);
      const projectTasks = await taskService.getProjectTasks(projectId);
      setTasks(projectTasks);
    } catch (err) {
      logger.error(`Failed to fetch tasks for project ${projectId}`, err as Error);
      setError('Failed to load tasks. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 获取单个任务 - 类比Go的获取任务详情
  const fetchTask = useCallback(async (taskId: TaskID) => {
    try {
      setIsLoading(true);
      setError(null);
      const task = await taskService.getTask(taskId);
      setCurrentTask(task);
    } catch (err) {
      logger.error(`Failed to fetch task ${taskId}`, err as Error);
      setError('Failed to load task details. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 创建任务 - 类比Go的创建任务
  const createTask = useCallback(async (title: string, description: string, projectId: ProjectID): Promise<Task> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const newTask = await taskService.createTask({
        title,
        description,
        projectId,
        assigneeId: currentUser?.id // 可选择自动分配给自己
      });
      
      setTasks(prev => [...prev, newTask]);
      return newTask;
    } catch (err) {
      logger.error('Failed to create task', err as Error);
      setError('Failed to create task. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  // 更新任务状态 - 类比Go的更新任务
  const updateTaskStatus = useCallback(async (taskId: TaskID, status: TaskStatus): Promise<Task> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const updatedTask = await taskService.updateTask({
        id: taskId,
        status
      });
      
      setTasks(prev => 
        prev.map(t => t.id === taskId ? updatedTask : t)
      );
      
      if (currentTask?.id === taskId) {
        setCurrentTask(updatedTask);
      }
      
      return updatedTask;
    } catch (err) {
      logger.error(`Failed to update task ${taskId}`, err as Error);
      setError('Failed to update task status. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentTask]);

  // 分配任务 - 类比Go的分配任务
  const assignTask = useCallback(async (taskId: TaskID, userId: string): Promise<Task> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const updatedTask = await taskService.assignTask({
        taskId,
        assigneeId: userId
      });
      
      setTasks(prev => 
        prev.map(t => t.id === taskId ? updatedTask : t)
      );
      
      if (currentTask?.id === taskId) {
        setCurrentTask(updatedTask);
      }
      
      return updatedTask;
    } catch (err) {
      logger.error(`Failed to assign task ${taskId}`, err as Error);
      setError('Failed to assign task. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentTask]);

  // 删除任务 - 类比Go的删除任务
  const deleteTask = useCallback(async (taskId: TaskID): Promise<void> => {
    try {
      setIsLoading(true);
      setError(null);
      
      await taskService.deleteTask(taskId);
      
      setTasks(prev => prev.filter(t => t.id !== taskId));
      
      if (currentTask?.id === taskId) {
        setCurrentTask(null);
      }
    } catch (err) {
      logger.error(`Failed to delete task ${taskId}`, err as Error);
      setError('Failed to delete task. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentTask]);

  // 提供任务上下文
  return (
    <TaskContext.Provider
      value={{
        tasks,
        currentTask,
        isLoading,
        error,
        fetchTasks,
        fetchTask,
        createTask,
        updateTaskStatus,
        assignTask,
        deleteTask
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

// 使用任务Hook - 类比Go的服务注入
export const useTask = () => useContext(TaskContext);
