/**
 * 404页面 - 表现层
 * 
 * 类比Go后端的404处理器:
 * ```go
 * func NotFoundHandler(c *gin.Context) {
 *   c.JSON(404, gin.H{"error": "Page not found"})
 * }
 * ```
 */

import React from 'react';
import { Link } from 'react-router-dom';

// 404页面组件 - 类比Go的404处理器
export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-gray-800 mb-4">404</h1>
        <h2 className="text-2xl font-medium text-gray-600 mb-6">Page Not Found</h2>
        <p className="text-gray-500 mb-8">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <Link 
          to="/dashboard" 
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
        >
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
};
