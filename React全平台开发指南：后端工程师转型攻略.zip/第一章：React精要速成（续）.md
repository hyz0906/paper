# 第一章：React精要速成（续）

## 1.4 后端迁移模式对照表

对于从Golang或Python后端开发转向React前端开发的工程师，理解两种开发范式之间的映射关系至关重要。本节提供了一个全面的对照表，帮助您将熟悉的后端概念映射到React中的对应概念，加速学习和迁移过程。

### 1.4.1 请求处理模式：Gin Handler → React组件

| Gin/Go后端模式 | React前端模式 | 说明 |
|--------------|-------------|------|
| `gin.Context` | `props` | Gin的Context包含请求信息，React的props包含组件输入 |
| `c.Param("id")` | `props.id` | 获取路由参数/组件属性 |
| `c.Query("filter")` | `useSearchParams()` | 获取查询参数 |
| `c.PostForm("name")` | `useState()` + `onChange` | 处理表单输入 |
| `c.JSON(200, data)` | `return <JSX>` | 返回响应/渲染UI |
| `c.Redirect(302, "/login")` | `navigate("/login")` | 重定向 |
| `gin.HandlerFunc` | `React.FC<Props>` | 处理函数类型定义 |
| `r.GET("/users", ListUsers)` | `<Route path="/users" element={<ListUsers />} />` | 路由注册 |
| `middleware.Auth()` | `<ProtectedRoute>` 或 HOC | 中间件/权限控制 |
| `c.Error(err)` | `try/catch` 或 Error Boundary | 错误处理 |

```go
// Gin处理函数示例
func GetUserProfile(c *gin.Context) {
    userID := c.Param("id")
    user, err := db.GetUser(userID)
    if err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "User not found"})
        return
    }
    c.JSON(http.StatusOK, user)
}
```

```jsx
// 对应的React组件
function UserProfile({ id }) {
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    
    useEffect(() => {
        async function fetchUser() {
            try {
                const response = await fetch(`/api/users/${id}`);
                if (!response.ok) throw new Error('User not found');
                const data = await response.json();
                setUser(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        }
        
        fetchUser();
    }, [id]);
    
    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    
    return (
        <div>
            <h2>{user.name}</h2>
            <p>Email: {user.email}</p>
            {/* 其他用户信息 */}
        </div>
    );
}
```

### 1.4.2 中间件概念：Go中间件 → React高阶组件/Hooks

| Go中间件模式 | React前端模式 | 说明 |
|------------|-------------|------|
| 认证中间件 | 认证HOC或Hook | 验证用户身份 |
| 日志中间件 | 日志HOC或Hook | 记录操作日志 |
| 错误处理中间件 | Error Boundary | 捕获和处理错误 |
| CORS中间件 | API客户端配置 | 处理跨域请求 |
| 限流中间件 | 节流/防抖Hook | 控制操作频率 |
| 请求ID中间件 | 请求拦截器 | 为请求添加唯一标识 |
| 压缩中间件 | 网络层配置 | 优化传输大小 |

```go
// Go认证中间件示例
func AuthMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        token := c.GetHeader("Authorization")
        if token == "" {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
            return
        }
        
        userID, err := validateToken(token)
        if err != nil {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Invalid token"})
            return
        }
        
        c.Set("userID", userID)
        c.Next()
    }
}

// 使用中间件
r.Use(AuthMiddleware())
r.GET("/profile", GetProfile)
```

```jsx
// React认证HOC示例
function withAuth(Component) {
    return function AuthenticatedComponent(props) {
        const [isAuthenticated, setIsAuthenticated] = useState(false);
        const [loading, setLoading] = useState(true);
        const navigate = useNavigate();
        
        useEffect(() => {
            async function checkAuth() {
                try {
                    const token = localStorage.getItem('token');
                    if (!token) throw new Error('No token');
                    
                    const response = await fetch('/api/validate-token', {
                        headers: { Authorization: `Bearer ${token}` }
                    });
                    
                    if (!response.ok) throw new Error('Invalid token');
                    
                    setIsAuthenticated(true);
                } catch (err) {
                    navigate('/login', { replace: true });
                } finally {
                    setLoading(false);
                }
            }
            
            checkAuth();
        }, [navigate]);
        
        if (loading) return <p>Checking authentication...</p>;
        
        return isAuthenticated ? <Component {...props} /> : null;
    };
}

// 使用HOC
const ProtectedProfile = withAuth(Profile);

// 或者使用认证Hook
function useAuth() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    
    useEffect(() => {
        // 验证逻辑...
    }, [navigate]);
    
    return { user, loading };
}

function Profile() {
    const { user, loading } = useAuth();
    
    if (loading) return <p>Loading...</p>;
    
    return <div>Welcome, {user.name}!</div>;
}
```

### 1.4.3 错误处理：Go错误传播 → React错误边界

| Go错误处理模式 | React错误处理模式 | 说明 |
|--------------|----------------|------|
| `if err != nil { return err }` | `try/catch` | 基本错误检查和传播 |
| 自定义错误类型 | 自定义错误对象 | 区分不同类型的错误 |
| `errors.Wrap` | 错误对象添加上下文 | 丰富错误信息 |
| panic/recover | Error Boundary | 处理未捕获的异常 |
| 错误日志记录 | 错误监控服务(Sentry) | 记录和分析错误 |
| 错误码 | HTTP状态码/API错误响应 | 标准化错误表示 |

```go
// Go错误处理示例
func GetUserData(userID string) (*UserData, error) {
    user, err := db.GetUser(userID)
    if err != nil {
        return nil, fmt.Errorf("failed to get user: %w", err)
    }
    
    posts, err := db.GetUserPosts(userID)
    if err != nil {
        return nil, fmt.Errorf("failed to get user posts: %w", err)
    }
    
    return &UserData{
        User:  user,
        Posts: posts,
    }, nil
}

func HandleUserRequest(c *gin.Context) {
    userID := c.Param("id")
    
    userData, err := GetUserData(userID)
    if err != nil {
        // 记录错误
        log.Printf("Error getting user data: %v", err)
        
        // 返回适当的错误响应
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get user data"})
        return
    }
    
    c.JSON(http.StatusOK, userData)
}
```

```jsx
// React错误处理示例
// 1. 错误边界组件
class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }
    
    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }
    
    componentDidCatch(error, errorInfo) {
        // 记录错误到服务
        console.error("Error caught by boundary:", error, errorInfo);
        // 可以发送到Sentry等错误监控服务
    }
    
    render() {
        if (this.state.hasError) {
            return this.props.fallback || <h2>Something went wrong.</h2>;
        }
        
        return this.props.children;
    }
}

// 2. 使用try/catch处理异步操作
function UserProfile({ userId }) {
    const [userData, setUserData] = useState(null);
    const [error, setError] = useState(null);
    
    useEffect(() => {
        async function fetchUserData() {
            try {
                const response = await fetch(`/api/users/${userId}`);
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.message || 'Failed to fetch user data');
                }
                
                const data = await response.json();
                setUserData(data);
            } catch (err) {
                console.error('Error fetching user data:', err);
                setError(err.message);
                
                // 可以根据错误类型做不同处理
                if (err.message.includes('not found')) {
                    // 处理404错误
                } else {
                    // 处理其他错误
                }
            }
        }
        
        fetchUserData();
    }, [userId]);
    
    if (error) return <div>Error: {error}</div>;
    if (!userData) return <div>Loading...</div>;
    
    return (
        <div>
            <h2>{userData.name}</h2>
            {/* 其他用户信息 */}
        </div>
    );
}

// 3. 在应用中使用错误边界
function App() {
    return (
        <ErrorBoundary fallback={<div>Something went wrong in the app.</div>}>
            <Router>
                <Routes>
                    <Route path="/users/:id" element={
                        <ErrorBoundary fallback={<div>Failed to load user profile.</div>}>
                            <UserProfile />
                        </ErrorBoundary>
                    } />
                    {/* 其他路由 */}
                </Routes>
            </Router>
        </ErrorBoundary>
    );
}
```

### 1.4.4 依赖注入：Go wire → React Context

| Go依赖注入模式 | React依赖注入模式 | 说明 |
|--------------|----------------|------|
| 构造函数注入 | Props传递 | 显式传递依赖 |
| `wire.Build` | Context Provider | 配置依赖图 |
| 接口抽象 | 自定义Hook | 抽象依赖实现 |
| `context.Context` | React Context | 跨层级传递依赖 |
| 服务定位器 | useContext | 获取依赖 |
| 单例模式 | 全局Context | 共享单一实例 |

```go
// Go依赖注入示例 (使用wire)
// wire.go
package main

import (
    "github.com/google/wire"
)

func InitializeUserService(db *Database, logger *Logger) *UserService {
    return NewUserService(db, logger)
}

var UserServiceSet = wire.NewSet(
    NewDatabase,
    NewLogger,
    wire.Bind(new(UserRepository), new(*DatabaseUserRepository)),
    NewDatabaseUserRepository,
    NewUserService,
)

// 生成的代码会创建所有依赖并正确注入
```

```jsx
// React Context依赖注入示例
// 1. 创建Context
const ServicesContext = createContext(null);

// 2. 创建Provider
function ServicesProvider({ children }) {
    // 创建服务实例
    const [services] = useState(() => {
        const logger = new Logger();
        const api = new ApiClient();
        const userService = new UserService(api, logger);
        
        return {
            logger,
            api,
            userService
        };
    });
    
    return (
        <ServicesContext.Provider value={services}>
            {children}
        </ServicesContext.Provider>
    );
}

// 3. 创建自定义Hook简化访问
function useServices() {
    const context = useContext(ServicesContext);
    if (!context) {
        throw new Error('useServices must be used within a ServicesProvider');
    }
    return context;
}

// 4. 在组件中使用
function UserProfile({ userId }) {
    const { userService } = useServices();
    const [user, setUser] = useState(null);
    
    useEffect(() => {
        async function loadUser() {
            const userData = await userService.getUser(userId);
            setUser(userData);
        }
        
        loadUser();
    }, [userId, userService]);
    
    // 渲染用户信息
    return user ? <div>{user.name}</div> : <div>Loading...</div>;
}

// 5. 在应用根组件中提供服务
function App() {
    return (
        <ServicesProvider>
            <Router>
                <Routes>
                    <Route path="/users/:id" element={<UserProfile />} />
                    {/* 其他路由 */}
                </Routes>
            </Router>
        </ServicesProvider>
    );
}
```

### 1.4.5 并发模型：Goroutines → JavaScript异步模型

| Go并发模式 | React/JavaScript并发模式 | 说明 |
|-----------|------------------------|------|
| Goroutine | Promise/async-await | 异步执行单元 |
| Channel | 状态更新 + useEffect | 通信机制 |
| select | Promise.race | 等待多个操作 |
| WaitGroup | Promise.all | 等待多个操作完成 |
| Mutex | 不需要（单线程） | 同步访问 |
| Context取消 | AbortController | 取消操作 |
| 超时控制 | setTimeout + cleanup | 超时处理 |

```go
// Go并发模式示例
func FetchUserData(ctx context.Context, userID string) (*UserData, error) {
    // 创建结果通道
    userCh := make(chan *User, 1)
    postsCh := make(chan []Post, 1)
    errorCh := make(chan error, 2)
    
    // 并发获取用户信息
    go func() {
        user, err := db.GetUser(ctx, userID)
        if err != nil {
            errorCh <- fmt.Errorf("failed to get user: %w", err)
            return
        }
        userCh <- user
    }()
    
    // 并发获取用户帖子
    go func() {
        posts, err := db.GetUserPosts(ctx, userID)
        if err != nil {
            errorCh <- fmt.Errorf("failed to get posts: %w", err)
            return
        }
        postsCh <- posts
    }()
    
    // 使用select等待结果
    var user *User
    var posts []Post
    
    // 等待两个结果
    for i := 0; i < 2; i++ {
        select {
        case user = <-userCh:
            // 获取到用户信息
        case posts = <-postsCh:
            // 获取到帖子列表
        case err := <-errorCh:
            // 发生错误
            return nil, err
        case <-ctx.Done():
            // 操作被取消
            return nil, ctx.Err()
        case <-time.After(5 * time.Second):
            // 超时
            return nil, errors.New("operation timed out")
        }
    }
    
    return &UserData{
        User:  user,
        Posts: posts,
    }, nil
}
```

```jsx
// React/JavaScript并发模式示例
function UserProfile({ userId }) {
    const [userData, setUserData] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    
    useEffect(() => {
        // 创建AbortController用于取消请求
        const controller = new AbortController();
        const signal = controller.signal;
        
        async function fetchUserData() {
            try {
                // 并发请求用户信息和帖子
                const [userResponse, postsResponse] = await Promise.all([
                    fetch(`/api/users/${userId}`, { signal }),
                    fetch(`/api/users/${userId}/posts`, { signal })
                ]);
                
                // 检查响应状态
                if (!userResponse.ok || !postsResponse.ok) {
                    throw new Error('Failed to fetch user data');
                }
                
                // 并发解析JSON响应
                const [user, posts] = await Promise.all([
                    userResponse.json(),
                    postsResponse.json()
                ]);
                
                // 组合数据
                setUserData({ user, posts });
            } catch (err) {
                // 忽略取消错误
                if (err.name !== 'AbortError') {
                    console.error('Error fetching data:', err);
                    setError(err.message);
                }
            } finally {
                setLoading(false);
            }
        }
        
        // 设置超时
        const timeoutId = setTimeout(() => {
            controller.abort();
            setError('Request timed out');
            setLoading(false);
        }, 5000);
        
        fetchUserData();
        
        // 清理函数
        return () => {
            controller.abort(); // 取消进行中的请求
            clearTimeout(timeoutId); // 清除超时
        };
    }, [userId]);
    
    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    
    return (
        <div>
            <h2>{userData.user.name}</h2>
            <h3>Posts</h3>
            <ul>
                {userData.posts.map(post => (
                    <li key={post.id}>{post.title}</li>
                ))}
            </ul>
        </div>
    );
}
```

### 1.4.6 数据流：Go数据流 → React单向数据流

| Go数据流模式 | React数据流模式 | 说明 |
|------------|---------------|------|
| 函数参数传递 | Props向下传递 | 显式数据传递 |
| 返回值 | 回调函数 | 向上传递数据 |
| 全局变量 | Context | 共享状态 |
| 发布-订阅模式 | 状态管理库(Redux) | 复杂状态管理 |
| 管道处理 | 数据转换Hook | 数据转换链 |
| 数据验证 | 表单验证库 | 输入验证 |

```go
// Go数据流示例
type UserService struct {
    repo UserRepository
    cache Cache
    logger Logger
}

func (s *UserService) GetUserWithPosts(ctx context.Context, userID string) (*UserWithPosts, error) {
    // 1. 尝试从缓存获取
    if cached, found := s.cache.Get(userID); found {
        s.logger.Info("Cache hit for user", "id", userID)
        return cached.(*UserWithPosts), nil
    }
    
    // 2. 从数据库获取用户
    user, err := s.repo.GetUser(ctx, userID)
    if err != nil {
        return nil, fmt.Errorf("failed to get user: %w", err)
    }
    
    // 3. 获取用户帖子
    posts, err := s.repo.GetUserPosts(ctx, userID)
    if err != nil {
        return nil, fmt.Errorf("failed to get user posts: %w", err)
    }
    
    // 4. 组合数据
    result := &UserWithPosts{
        User:  user,
        Posts: posts,
    }
    
    // 5. 更新缓存
    s.cache.Set(userID, result)
    
    return result, nil
}
```

```jsx
// React单向数据流示例
// 1. 数据获取Hook
function useUserWithPosts(userId) {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    
    // 缓存实例
    const cache = useMemo(() => new Map(), []);
    
    useEffect(() => {
        async function fetchData() {
            // 1. 尝试从缓存获取
            if (cache.has(userId)) {
                console.log('Cache hit for user', userId);
                setData(cache.get(userId));
                setLoading(false);
                return;
            }
            
            setLoading(true);
            setError(null);
            
            try {
                // 2. 获取用户数据
                const userResponse = await fetch(`/api/users/${userId}`);
                if (!userResponse.ok) throw new Error('Failed to fetch user');
                const user = await userResponse.json();
                
                // 3. 获取用户帖子
                const postsResponse = await fetch(`/api/users/${userId}/posts`);
                if (!postsResponse.ok) throw new Error('Failed to fetch posts');
                const posts = await postsResponse.json();
                
                // 4. 组合数据
                const result = { user, posts };
                
                // 5. 更新缓存
                cache.set(userId, result);
                
                setData(result);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        }
        
        fetchData();
    }, [userId, cache]);
    
    return { data, loading, error };
}

// 2. 父组件
function UserProfilePage({ userId }) {
    const { data, loading, error } = useUserWithPosts(userId);
    
    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    
    return (
        <div>
            <UserInfo user={data.user} />
            <UserPosts posts={data.posts} />
        </div>
    );
}

// 3. 子组件 - 只接收所需数据
function UserInfo({ user }) {
    return (
        <div>
            <h2>{user.name}</h2>
            <p>Email: {user.email}</p>
        </div>
    );
}

function UserPosts({ posts }) {
    return (
        <div>
            <h3>Posts</h3>
            <ul>
                {posts.map(post => (
                    <li key={post.id}>{post.title}</li>
                ))}
            </ul>
        </div>
    );
}
```

### 1.4.7 配置管理：Go配置 → React环境变量

| Go配置模式 | React配置模式 | 说明 |
|-----------|-------------|------|
| 环境变量 | .env文件 | 环境特定配置 |
| 配置文件 | 构建时常量 | 静态配置 |
| 命令行参数 | 构建参数 | 构建时配置 |
| 配置结构体 | 配置Context | 应用级配置 |
| 动态配置 | 远程配置API | 运行时配置 |

```go
// Go配置管理示例
type Config struct {
    Server struct {
        Port    int    `yaml:"port"`
        Host    string `yaml:"host"`
        Timeout int    `yaml:"timeout"`
    } `yaml:"server"`
    
    Database struct {
        DSN      string `yaml:"dsn"`
        MaxConns int    `yaml:"maxConns"`
    } `yaml:"database"`
    
    Auth struct {
        JWTSecret string `yaml:"jwtSecret"`
        TokenTTL  int    `yaml:"tokenTTL"`
    } `yaml:"auth"`
}

func LoadConfig() (*Config, error) {
    // 从文件加载配置
    configFile := os.Getenv("CONFIG_FILE")
    if configFile == "" {
        configFile = "config.yaml"
    }
    
    data, err := ioutil.ReadFile(configFile)
    if err != nil {
        return nil, fmt.Errorf("failed to read config file: %w", err)
    }
    
    var config Config
    if err := yaml.Unmarshal(data, &config); err != nil {
        return nil, fmt.Errorf("failed to parse config: %w", err)
    }
    
    // 环境变量覆盖
    if port := os.Getenv("SERVER_PORT"); port != "" {
        portInt, _ := strconv.Atoi(port)
        config.Server.Port = portInt
    }
    
    return &config, nil
}
```

```jsx
// React配置管理示例
// .env.development
REACT_APP_API_URL=http://localhost:8080/api
REACT_APP_AUTH_ENABLED=true
REACT_APP_LOG_LEVEL=debug

// .env.production
REACT_APP_API_URL=https://api.example.com
REACT_APP_AUTH_ENABLED=true
REACT_APP_LOG_LEVEL=error

// 配置模块 (src/config.js)
const config = {
    api: {
        baseUrl: process.env.REACT_APP_API_URL || 'http://localhost:8080/api',
        timeout: parseInt(process.env.REACT_APP_API_TIMEOUT || '5000', 10),
    },
    auth: {
        enabled: process.env.REACT_APP_AUTH_ENABLED === 'true',
        tokenKey: 'auth_token',
    },
    logging: {
        level: process.env.REACT_APP_LOG_LEVEL || 'info',
        enabled: process.env.NODE_ENV !== 'production',
    },
};

// 在开发环境下验证配置
if (process.env.NODE_ENV === 'development') {
    console.log('App configuration:', config);
    
    // 验证必要的配置
    if (!config.api.baseUrl) {
        console.error('API base URL is not configured!');
    }
}

export default Object.freeze(config);

// 在组件中使用配置
import React from 'react';
import config from '../config';

function ApiClient() {
    const [apiStatus, setApiStatus] = useState('unknown');
    
    useEffect(() => {
        async function checkApi() {
            try {
                const response = await fetch(`${config.api.baseUrl}/status`, {
                    timeout: config.api.timeout,
                });
                
                if (response.ok) {
                    setApiStatus('online');
                } else {
                    setApiStatus('error');
                }
            } catch (err) {
                setApiStatus('offline');
                if (config.logging.enabled) {
                    console.error('API check failed:', err);
                }
            }
        }
        
        checkApi();
    }, []);
    
    return (
        <div>
            <h2>API Status</h2>
            <p>Status: {apiStatus}</p>
            <p>Endpoint: {config.api.baseUrl}</p>
        </div>
    );
}
```

### 1.4.8 日志与监控：Go日志 → React日志

| Go日志模式 | React日志模式 | 说明 |
|-----------|-------------|------|
| 结构化日志 | 自定义日志工具 | 格式化日志记录 |
| 日志级别 | 日志过滤 | 控制日志详细程度 |
| 日志中间件 | 日志HOC/Hook | 自动记录操作 |
| Prometheus指标 | 性能监控API | 收集性能指标 |
| 分布式追踪 | 前端性能追踪 | 跟踪请求流程 |
| 健康检查 | 应用状态监控 | 监控应用健康状态 |

```go
// Go日志与监控示例
package main

import (
    "net/http"
    "time"
    
    "github.com/gin-gonic/gin"
    "github.com/sirupsen/logrus"
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
    // 定义Prometheus指标
    httpRequestsTotal = prometheus.NewCounterVec(
        prometheus.CounterOpts{
            Name: "http_requests_total",
            Help: "Total number of HTTP requests",
        },
        []string{"method", "endpoint", "status"},
    )
    
    httpRequestDuration = prometheus.NewHistogramVec(
        prometheus.HistogramOpts{
            Name:    "http_request_duration_seconds",
            Help:    "HTTP request duration in seconds",
            Buckets: prometheus.DefBuckets,
        },
        []string{"method", "endpoint"},
    )
)

func init() {
    // 注册Prometheus指标
    prometheus.MustRegister(httpRequestsTotal)
    prometheus.MustRegister(httpRequestDuration)
}

// 日志中间件
func LoggerMiddleware(logger *logrus.Logger) gin.HandlerFunc {
    return func(c *gin.Context) {
        startTime := time.Now()
        
        // 处理请求
        c.Next()
        
        // 计算请求时间
        duration := time.Since(startTime)
        
        // 记录请求日志
        logger.WithFields(logrus.Fields{
            "method":     c.Request.Method,
            "path":       c.Request.URL.Path,
            "status":     c.Writer.Status(),
            "duration":   duration.Seconds(),
            "client_ip":  c.ClientIP(),
            "user_agent": c.Request.UserAgent(),
        }).Info("HTTP request")
        
        // 更新Prometheus指标
        httpRequestsTotal.WithLabelValues(
            c.Request.Method,
            c.Request.URL.Path,
            string(c.Writer.Status()),
        ).Inc()
        
        httpRequestDuration.WithLabelValues(
            c.Request.Method,
            c.Request.URL.Path,
        ).Observe(duration.Seconds())
    }
}

func main() {
    // 配置日志
    logger := logrus.New()
    logger.SetFormatter(&logrus.JSONFormatter{})
    
    // 创建Gin路由
    r := gin.New()
    r.Use(gin.Recovery())
    r.Use(LoggerMiddleware(logger))
    
    // API路由
    r.GET("/users/:id", GetUser)
    
    // 监控端点
    r.GET("/metrics", gin.WrapH(promhttp.Handler()))
    r.GET("/health", HealthCheck)
    
    // 启动服务器
    r.Run(":8080")
}

func HealthCheck(c *gin.Context) {
    c.JSON(http.StatusOK, gin.H{
        "status": "up",
        "time":   time.Now(),
    })
}
```

```jsx
// React日志与监控示例
// 1. 日志服务 (src/services/logger.js)
class Logger {
    constructor() {
        this.logLevel = process.env.REACT_APP_LOG_LEVEL || 'info';
        this.levels = {
            debug: 0,
            info: 1,
            warn: 2,
            error: 3,
        };
    }
    
    shouldLog(level) {
        return this.levels[level] >= this.levels[this.logLevel];
    }
    
    formatMessage(level, message, context = {}) {
        return {
            timestamp: new Date().toISOString(),
            level,
            message,
            ...context,
            environment: process.env.NODE_ENV,
            userAgent: navigator.userAgent,
        };
    }
    
    debug(message, context) {
        if (this.shouldLog('debug')) {
            console.debug(this.formatMessage('debug', message, context));
        }
    }
    
    info(message, context) {
        if (this.shouldLog('info')) {
            console.info(this.formatMessage('info', message, context));
        }
    }
    
    warn(message, context) {
        if (this.shouldLog('warn')) {
            console.warn(this.formatMessage('warn', message, context));
        }
    }
    
    error(message, error, context) {
        if (this.shouldLog('error')) {
            console.error(
                this.formatMessage('error', message, {
                    ...context,
                    errorName: error?.name,
                    errorMessage: error?.message,
                    stack: error?.stack,
                })
            );
            
            // 可以将错误发送到Sentry等服务
            if (window.Sentry) {
                window.Sentry.captureException(error, {
                    extra: context,
                });
            }
        }
    }
    
    // 记录API请求
    logApiRequest(method, url, duration, status, error) {
        this.info('API Request', {
            method,
            url,
            duration,
            status,
            error: error?.message,
        });
        
        // 记录性能指标
        if (window.performance && window.performance.mark) {
            window.performance.mark(`api-${method}-${url}-${status}`);
        }
    }
}

export default new Logger();

// 2. API客户端 (src/services/api.js)
import logger from './logger';

class ApiClient {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
    }
    
    async request(method, endpoint, data = null) {
        const url = `${this.baseUrl}${endpoint}`;
        const startTime = performance.now();
        let status = 'unknown';
        
        try {
            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
            };
            
            if (data) {
                options.body = JSON.stringify(data);
            }
            
            const response = await fetch(url, options);
            status = response.status;
            
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || 'API request failed');
            }
            
            return result;
        } catch (error) {
            logger.error(`API ${method} ${endpoint} failed`, error);
            throw error;
        } finally {
            const duration = performance.now() - startTime;
            logger.logApiRequest(method, endpoint, duration, status);
        }
    }
    
    get(endpoint) {
        return this.request('GET', endpoint);
    }
    
    post(endpoint, data) {
        return this.request('POST', endpoint, data);
    }
    
    // 其他方法...
}

export default new ApiClient(process.env.REACT_APP_API_URL);

// 3. 性能监控Hook (src/hooks/usePerformanceMonitoring.js)
function usePerformanceMonitoring() {
    useEffect(() => {
        if (!window.performance || !window.performance.mark) {
            return;
        }
        
        // 记录组件挂载时间
        window.performance.mark('component-mounted');
        
        // 监听性能指标
        const observer = new PerformanceObserver((list) => {
            list.getEntries().forEach((entry) => {
                logger.debug('Performance entry', {
                    name: entry.name,
                    duration: entry.duration,
                    startTime: entry.startTime,
                    entryType: entry.entryType,
                });
            });
        });
        
        observer.observe({ entryTypes: ['measure', 'resource', 'navigation'] });
        
        return () => {
            // 记录组件卸载时间
            window.performance.mark('component-unmounted');
            window.performance.measure(
                'component-lifecycle',
                'component-mounted',
                'component-unmounted'
            );
            
            // 清理观察者
            observer.disconnect();
        };
    }, []);
}

// 4. 在组件中使用
function UserProfile({ userId }) {
    const { data, loading, error } = useUserData(userId);
    usePerformanceMonitoring();
    
    useEffect(() => {
        logger.info('UserProfile mounted', { userId });
        
        return () => {
            logger.info('UserProfile unmounted', { userId });
        };
    }, [userId]);
    
    if (loading) return <div>Loading...</div>;
    
    if (error) {
        logger.error('Failed to load user profile', error, { userId });
        return <div>Error loading profile</div>;
    }
    
    return (
        <div>
            <h2>{data.name}</h2>
            {/* 其他用户信息 */}
        </div>
    );
}
```

## 总结

本章通过详细的对照表和代码示例，展示了从Go/Python后端开发迁移到React前端开发的关键模式和概念映射。这些对照表不仅帮助您理解两种开发范式之间的相似性和差异，还提供了实际的代码示例，展示如何将后端开发中的最佳实践应用到React前端开发中。

在后续章节中，我们将深入探讨跨平台工程化配置、后端衔接专项和质量保障体系，进一步帮助您构建高质量的React全平台应用。
