/**
 * 项目Hook - 表现层
 * 
 * 类比Go后端的项目服务:
 * ```go
 * type ProjectService struct {
 *   // ...
 * }
 * 
 * func (s *ProjectService) GetUserProjects(userID string) ([]Project, error) {
 *   // 获取用户项目逻辑
 * }
 * ```
 */

import { useState, useCallback, useContext, createContext } from 'react';
import { Project, ProjectID, ProjectStatus } from '../../domain/project';
import { projectService } from '../../application/projectService';
import { useAuth } from './useAuth';
import { logger } from '../../infrastructure/logger/logger';

// 项目上下文类型
interface ProjectContextType {
  projects: Project[];
  currentProject: Project | null;
  isLoading: boolean;
  error: string | null;
  fetchProjects: () => Promise<void>;
  fetchProject: (projectId: ProjectID) => Promise<void>;
  createProject: (name: string, description: string) => Promise<Project>;
  updateProject: (projectId: ProjectID, name: string, description: string) => Promise<Project>;
  archiveProject: (projectId: ProjectID) => Promise<Project>;
  deleteProject: (projectId: ProjectID) => Promise<void>;
  addMember: (projectId: ProjectID, userId: string) => Promise<Project>;
}

// 创建项目上下文 - 类比Go的上下文
const ProjectContext = createContext<ProjectContextType>({
  projects: [],
  currentProject: null,
  isLoading: false,
  error: null,
  fetchProjects: async () => {},
  fetchProject: async () => {},
  createProject: async () => ({ id: '', name: '', description: '', status: ProjectStatus.ACTIVE, ownerId: '', members: [], createdAt: '', updatedAt: '' }),
  updateProject: async () => ({ id: '', name: '', description: '', status: ProjectStatus.ACTIVE, ownerId: '', members: [], createdAt: '', updatedAt: '' }),
  archiveProject: async () => ({ id: '', name: '', description: '', status: ProjectStatus.ACTIVE, ownerId: '', members: [], createdAt: '', updatedAt: '' }),
  deleteProject: async () => {},
  addMember: async () => ({ id: '', name: '', description: '', status: ProjectStatus.ACTIVE, ownerId: '', members: [], createdAt: '', updatedAt: '' }),
});

// 项目提供者组件 - 类比Go的服务提供者
export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { currentUser } = useAuth();

  // 获取用户项目列表 - 类比Go的获取项目列表
  const fetchProjects = useCallback(async () => {
    if (!currentUser) return;
    
    try {
      setIsLoading(true);
      setError(null);
      const userProjects = await projectService.getUserProjects(currentUser.id);
      setProjects(userProjects);
    } catch (err) {
      logger.error('Failed to fetch projects', err as Error);
      setError('Failed to load projects. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  // 获取单个项目 - 类比Go的获取项目详情
  const fetchProject = useCallback(async (projectId: ProjectID) => {
    try {
      setIsLoading(true);
      setError(null);
      const project = await projectService.getProject(projectId);
      setCurrentProject(project);
    } catch (err) {
      logger.error(`Failed to fetch project ${projectId}`, err as Error);
      setError('Failed to load project details. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 创建项目 - 类比Go的创建项目
  const createProject = useCallback(async (name: string, description: string): Promise<Project> => {
    if (!currentUser) throw new Error('User not authenticated');
    
    try {
      setIsLoading(true);
      setError(null);
      
      const newProject = await projectService.createProject({
        name,
        description,
        ownerId: currentUser.id
      });
      
      setProjects(prev => [...prev, newProject]);
      return newProject;
    } catch (err) {
      logger.error('Failed to create project', err as Error);
      setError('Failed to create project. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  // 更新项目 - 类比Go的更新项目
  const updateProject = useCallback(async (projectId: ProjectID, name: string, description: string): Promise<Project> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const updatedProject = await projectService.updateProject({
        id: projectId,
        name,
        description
      });
      
      setProjects(prev => 
        prev.map(p => p.id === projectId ? updatedProject : p)
      );
      
      if (currentProject?.id === projectId) {
        setCurrentProject(updatedProject);
      }
      
      return updatedProject;
    } catch (err) {
      logger.error(`Failed to update project ${projectId}`, err as Error);
      setError('Failed to update project. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentProject]);

  // 归档项目 - 类比Go的归档项目
  const archiveProject = useCallback(async (projectId: ProjectID): Promise<Project> => {
    if (!currentUser) throw new Error('User not authenticated');
    
    try {
      setIsLoading(true);
      setError(null);
      
      const archivedProject = await projectService.archiveProject({
        projectId,
        archivedBy: currentUser.id
      });
      
      setProjects(prev => 
        prev.map(p => p.id === projectId ? archivedProject : p)
      );
      
      if (currentProject?.id === projectId) {
        setCurrentProject(archivedProject);
      }
      
      return archivedProject;
    } catch (err) {
      logger.error(`Failed to archive project ${projectId}`, err as Error);
      setError('Failed to archive project. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentUser, currentProject]);

  // 删除项目 - 类比Go的删除项目
  const deleteProject = useCallback(async (projectId: ProjectID): Promise<void> => {
    try {
      setIsLoading(true);
      setError(null);
      
      await projectService.deleteProject(projectId);
      
      setProjects(prev => prev.filter(p => p.id !== projectId));
      
      if (currentProject?.id === projectId) {
        setCurrentProject(null);
      }
    } catch (err) {
      logger.error(`Failed to delete project ${projectId}`, err as Error);
      setError('Failed to delete project. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentProject]);

  // 添加成员 - 类比Go的添加成员
  const addMember = useCallback(async (projectId: ProjectID, userId: string): Promise<Project> => {
    if (!currentUser) throw new Error('User not authenticated');
    
    try {
      setIsLoading(true);
      setError(null);
      
      const updatedProject = await projectService.addMember({
        projectId,
        userId,
        addedBy: currentUser.id
      });
      
      setProjects(prev => 
        prev.map(p => p.id === projectId ? updatedProject : p)
      );
      
      if (currentProject?.id === projectId) {
        setCurrentProject(updatedProject);
      }
      
      return updatedProject;
    } catch (err) {
      logger.error(`Failed to add member to project ${projectId}`, err as Error);
      setError('Failed to add member. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [currentUser, currentProject]);

  // 提供项目上下文
  return (
    <ProjectContext.Provider
      value={{
        projects,
        currentProject,
        isLoading,
        error,
        fetchProjects,
        fetchProject,
        createProject,
        updateProject,
        archiveProject,
        deleteProject,
        addMember
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
};

// 使用项目Hook - 类比Go的服务注入
export const useProject = () => useContext(ProjectContext);
