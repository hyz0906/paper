/**
 * 认证服务 - 应用层
 * 
 * 类比Go后端的认证服务:
 * ```go
 * type AuthService struct {
 *   userRepo repository.UserRepository
 *   tokenService TokenService
 * }
 * 
 * func (s *AuthService) Login(ctx context.Context, email, password string) (string, error) {
 *   // 实现登录逻辑
 * }
 * ```
 */

import { User, UserRole } from '../domain/user';
import { apiClient } from '../infrastructure/api/apiClient';
import { saveAuthToken, removeAuthToken, saveUserInfo, removeUserInfo, clearAuthData } from '../infrastructure/storage/authStorage';
import { logger } from '../infrastructure/logger/logger';

// 登录请求 - 类比Go的LoginRequest
export interface LoginRequest {
  email: string;
  password: string;
}

// 注册请求 - 类比Go的RegisterRequest
export interface RegisterRequest {
  email: string;
  password: string;
  name: string;
}

// 登录响应 - 类比Go的LoginResponse
export interface AuthResponse {
  token: string;
  user: User;
}

// 认证服务类 - 类比Go的AuthService
export class AuthService {
  // 登录
  async login(request: LoginRequest): Promise<User> {
    try {
      logger.info('Attempting login', { email: request.email });
      
      // 调用登录API
      const response = await apiClient.post<AuthResponse>('/auth/login', request);
      
      // 保存认证信息
      await saveAuthToken(response.token);
      await saveUserInfo(response.user);
      
      logger.info('Login successful', { userId: response.user.id });
      
      return response.user;
    } catch (error) {
      logger.error('Login failed', error as Error, { email: request.email });
      throw error;
    }
  }

  // 注册
  async register(request: RegisterRequest): Promise<User> {
    try {
      logger.info('Attempting registration', { email: request.email });
      
      // 调用注册API
      const response = await apiClient.post<AuthResponse>('/auth/register', {
        ...request,
        role: UserRole.MEMBER // 默认角色
      });
      
      // 保存认证信息
      await saveAuthToken(response.token);
      await saveUserInfo(response.user);
      
      logger.info('Registration successful', { userId: response.user.id });
      
      return response.user;
    } catch (error) {
      logger.error('Registration failed', error as Error, { email: request.email });
      throw error;
    }
  }

  // 登出
  async logout(): Promise<void> {
    try {
      logger.info('Logging out');
      
      // 清除本地认证数据
      await clearAuthData();
      
      // 可选：调用登出API
      try {
        await apiClient.post('/auth/logout');
      } catch (error) {
        // 即使API调用失败，也继续本地登出
        logger.warn('Logout API call failed, but local logout succeeded');
      }
      
      logger.info('Logout successful');
    } catch (error) {
      logger.error('Logout failed', error as Error);
      throw error;
    }
  }

  // 获取当前用户
  async getCurrentUser(): Promise<User | null> {
    try {
      // 尝试从本地存储获取
      const user = await saveUserInfo<User>();
      
      if (user) {
        return user;
      }
      
      // 如果本地没有，但有token，则从API获取
      const token = await saveAuthToken();
      if (token) {
        try {
          const response = await apiClient.get<User>('/auth/me');
          await saveUserInfo(response);
          return response;
        } catch (error) {
          // 如果API调用失败，清除可能过期的token
          if ((error as any)?.response?.status === 401) {
            await clearAuthData();
          }
          return null;
        }
      }
      
      return null;
    } catch (error) {
      logger.error('Failed to get current user', error as Error);
      return null;
    }
  }

  // 检查是否已认证
  async isAuthenticated(): Promise<boolean> {
    const user = await this.getCurrentUser();
    return !!user;
  }

  // 刷新令牌
  async refreshToken(): Promise<boolean> {
    try {
      logger.info('Refreshing auth token');
      
      const response = await apiClient.post<{ token: string }>('/auth/refresh');
      await saveAuthToken(response.token);
      
      logger.info('Token refresh successful');
      return true;
    } catch (error) {
      logger.error('Token refresh failed', error as Error);
      await clearAuthData(); // 清除过期数据
      return false;
    }
  }
}

// 创建认证服务实例
export const authService = new AuthService();
