/**
 * WebSocket服务 - 基础设施层
 * 
 * 类比Go后端的WebSocket服务:
 * ```go
 * type WebSocketClient struct {
 *   conn      *websocket.Conn
 *   handlers  map[string]func([]byte)
 *   connected bool
 * }
 * ```
 */

import Taro from '@tarojs/taro';
import { eventBus } from '../events/eventBus';
import { logger } from '../logger/logger';
import { getAuthToken } from '../storage/authStorage';

// 消息类型枚举 - 类比Go的常量
export enum MessageType {
  AUTH = 'auth',
  TASK_UPDATED = 'task_updated',
  PROJECT_UPDATED = 'project_updated',
  NOTIFICATION = 'notification',
  ERROR = 'error',
  PING = 'ping',
  PONG = 'pong'
}

// 消息接口 - 类比Go的消息结构体
interface WebSocketMessage {
  type: MessageType;
  payload: any;
  timestamp: number;
}

// 连接配置接口
interface WebSocketConfig {
  url: string;
  reconnectInterval: number;
  maxReconnectAttempts: number;
}

// WebSocket服务类 - 类比Go的WebSocketClient结构体
class WebSocketService {
  private config: WebSocketConfig;
  private socketTask: Taro.SocketTask | null = null;
  private connected: boolean = false;
  private reconnectAttempts: number = 0;
  private reconnectTimeout: any = null;
  private pingInterval: any = null;
  private lastPongTime: number = 0;
  
  constructor(config: WebSocketConfig) {
    this.config = config;
  }
  
  // 连接WebSocket - 类比Go的Connect方法
  async connect(): Promise<boolean> {
    if (this.connected) {
      return true;
    }
    
    try {
      // 获取认证令牌
      const token = await getAuthToken();
      if (!token) {
        logger.error('WebSocket connection failed: No auth token');
        return false;
      }
      
      // 创建WebSocket连接 - 小程序特有
      this.socketTask = await Taro.connectSocket({
        url: this.config.url,
        header: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      // 设置事件处理器
      this.socketTask.onOpen(this.handleOpen.bind(this));
      this.socketTask.onMessage(this.handleMessage.bind(this));
      this.socketTask.onError(this.handleError.bind(this));
      this.socketTask.onClose(this.handleClose.bind(this));
      
      return true;
    } catch (error) {
      logger.error('WebSocket connection error', error);
      this.scheduleReconnect();
      return false;
    }
  }
  
  // 断开连接 - 类比Go的Disconnect方法
  async disconnect(): Promise<void> {
    if (!this.connected || !this.socketTask) {
      return;
    }
    
    try {
      // 清除定时器
      this.clearTimers();
      
      // 关闭连接
      await this.socketTask.close({
        code: 1000,
        reason: 'Client disconnected'
      });
      
      this.socketTask = null;
      this.connected = false;
      
      logger.info('WebSocket disconnected');
    } catch (error) {
      logger.error('WebSocket disconnect error', error);
    }
  }
  
  // 发送消息 - 类比Go的SendMessage方法
  async sendMessage(type: MessageType, payload: any): Promise<boolean> {
    if (!this.connected || !this.socketTask) {
      logger.warn('Cannot send message: WebSocket not connected');
      return false;
    }
    
    try {
      const message: WebSocketMessage = {
        type,
        payload,
        timestamp: Date.now()
      };
      
      await this.socketTask.send({
        data: JSON.stringify(message)
      });
      
      return true;
    } catch (error) {
      logger.error('WebSocket send error', error);
      return false;
    }
  }
  
  // 连接打开处理 - 类比Go的onOpen回调
  private handleOpen(): void {
    this.connected = true;
    this.reconnectAttempts = 0;
    
    logger.info('WebSocket connected');
    
    // 发送认证消息
    this.sendAuthMessage();
    
    // 启动心跳检测
    this.startHeartbeat();
    
    // 发布连接事件
    eventBus.publish('websocket:connected', {});
  }
  
  // 消息处理 - 类比Go的onMessage回调
  private handleMessage(res: Taro.onSocketMessageCallbackResult): void {
    try {
      const message: WebSocketMessage = JSON.parse(res.data as string);
      
      // 更新最后一次pong时间
      if (message.type === MessageType.PONG) {
        this.lastPongTime = Date.now();
        return;
      }
      
      // 处理不同类型的消息
      switch (message.type) {
        case MessageType.TASK_UPDATED:
          eventBus.publish('task:updated', message.payload);
          break;
          
        case MessageType.PROJECT_UPDATED:
          eventBus.publish('project:updated', message.payload);
          break;
          
        case MessageType.NOTIFICATION:
          eventBus.publish('notification:received', message.payload);
          break;
          
        case MessageType.ERROR:
          logger.error('WebSocket error message', message.payload);
          eventBus.publish('websocket:error', message.payload);
          break;
          
        default:
          logger.debug('Unhandled WebSocket message type', message);
      }
    } catch (error) {
      logger.error('WebSocket message parse error', error);
    }
  }
  
  // 错误处理 - 类比Go的onError回调
  private handleError(error: any): void {
    logger.error('WebSocket error', error);
    eventBus.publish('websocket:error', { message: 'WebSocket connection error' });
  }
  
  // 连接关闭处理 - 类比Go的onClose回调
  private handleClose(res: Taro.onSocketCloseCallbackResult): void {
    this.connected = false;
    this.socketTask = null;
    
    // 清除定时器
    this.clearTimers();
    
    logger.info('WebSocket closed', { code: res.code, reason: res.reason });
    
    // 发布断开连接事件
    eventBus.publish('websocket:disconnected', { code: res.code, reason: res.reason });
    
    // 尝试重新连接
    this.scheduleReconnect();
  }
  
  // 发送认证消息 - 类比Go的sendAuth方法
  private async sendAuthMessage(): Promise<void> {
    const token = await getAuthToken();
    if (!token) {
      logger.error('Cannot send auth message: No auth token');
      return;
    }
    
    this.sendMessage(MessageType.AUTH, { token });
  }
  
  // 启动心跳检测 - 类比Go的startHeartbeat方法
  private startHeartbeat(): void {
    // 清除现有定时器
    this.clearTimers();
    
    // 设置最后一次pong时间
    this.lastPongTime = Date.now();
    
    // 每30秒发送一次ping
    this.pingInterval = setInterval(() => {
      // 检查是否超过60秒没有收到pong
      if (Date.now() - this.lastPongTime > 60000) {
        logger.warn('WebSocket heartbeat timeout');
        this.reconnect();
        return;
      }
      
      // 发送ping
      this.sendMessage(MessageType.PING, {});
    }, 30000);
  }
  
  // 安排重新连接 - 类比Go的scheduleReconnect方法
  private scheduleReconnect(): void {
    // 清除现有定时器
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
    
    // 检查重连次数
    if (this.reconnectAttempts >= this.config.maxReconnectAttempts) {
      logger.error('WebSocket max reconnect attempts reached');
      eventBus.publish('websocket:reconnect_failed', {});
      return;
    }
    
    // 计算重连延迟（指数退避）
    const delay = Math.min(
      this.config.reconnectInterval * Math.pow(1.5, this.reconnectAttempts),
      30000 // 最大30秒
    );
    
    this.reconnectAttempts++;
    
    logger.info(`WebSocket scheduling reconnect in ${delay}ms (attempt ${this.reconnectAttempts})`);
    
    // 安排重连
    this.reconnectTimeout = setTimeout(() => {
      this.reconnect();
    }, delay);
  }
  
  // 重新连接 - 类比Go的reconnect方法
  private async reconnect(): Promise<void> {
    logger.info('WebSocket reconnecting...');
    
    // 确保先断开连接
    if (this.connected && this.socketTask) {
      await this.disconnect();
    }
    
    // 尝试重新连接
    const success = await this.connect();
    
    if (success) {
      logger.info('WebSocket reconnected successfully');
      eventBus.publish('websocket:reconnected', {});
    } else {
      logger.warn('WebSocket reconnect failed');
      this.scheduleReconnect();
    }
  }
  
  // 清除定时器 - 类比Go的clearTimers方法
  private clearTimers(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
    
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
  }
}

// 创建WebSocket服务实例 - 类比Go的NewWebSocketClient函数
export const webSocketService = new WebSocketService({
  url: 'wss://api.example.com/v1/ws',
  reconnectInterval: 2000, // 初始重连间隔2秒
  maxReconnectAttempts: 10
});
