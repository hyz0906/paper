/**
 * 日志服务 - 基础设施层
 * 
 * 类比Go后端的日志服务:
 * ```go
 * type Logger struct {
 *   level LogLevel
 * }
 * 
 * func NewLogger(level LogLevel) *Logger {
 *   return &Logger{
 *     level: level,
 *   }
 * }
 * 
 * func (l *Logger) Info(msg string, fields ...Field) {
 *   // 实现信息日志
 * }
 * ```
 */

// 日志级别枚举 - 类比Go的LogLevel
export enum LogLevel {
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error',
}

// 日志字段类型 - 类比Go的Field
export interface LogField {
  key: string;
  value: any;
}

// 日志服务类 - 类比Go的Logger结构体
export class Logger {
  private level: LogLevel;
  private context: Record<string, any>;

  constructor(level: LogLevel = LogLevel.INFO, context: Record<string, any> = {}) {
    this.level = level;
    this.context = context;
  }

  // 创建带上下文的新日志器 - 类比Go的With方法
  with(context: Record<string, any>): Logger {
    return new Logger(this.level, { ...this.context, ...context });
  }

  // 设置日志级别 - 类比Go的SetLevel方法
  setLevel(level: LogLevel): void {
    this.level = level;
  }

  // 调试日志 - 类比Go的Debug方法
  debug(message: string, ...fields: LogField[]): void {
    if (this.shouldLog(LogLevel.DEBUG)) {
      this.log(LogLevel.DEBUG, message, ...fields);
    }
  }

  // 信息日志 - 类比Go的Info方法
  info(message: string, ...fields: LogField[]): void {
    if (this.shouldLog(LogLevel.INFO)) {
      this.log(LogLevel.INFO, message, ...fields);
    }
  }

  // 警告日志 - 类比Go的Warn方法
  warn(message: string, ...fields: LogField[]): void {
    if (this.shouldLog(LogLevel.WARN)) {
      this.log(LogLevel.WARN, message, ...fields);
    }
  }

  // 错误日志 - 类比Go的Error方法
  error(message: string, error?: Error, ...fields: LogField[]): void {
    if (this.shouldLog(LogLevel.ERROR)) {
      const errorFields: LogField[] = error
        ? [
            { key: 'error', value: error.message },
            { key: 'stack', value: error.stack },
          ]
        : [];
      this.log(LogLevel.ERROR, message, ...errorFields, ...fields);
    }
  }

  // 判断是否应该记录日志 - 类比Go的shouldLog方法
  private shouldLog(level: LogLevel): boolean {
    const levels = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR];
    return levels.indexOf(level) >= levels.indexOf(this.level);
  }

  // 记录日志 - 类比Go的log方法
  private log(level: LogLevel, message: string, ...fields: LogField[]): void {
    const timestamp = new Date().toISOString();
    const fieldsObj = fields.reduce((acc, field) => {
      acc[field.key] = field.value;
      return acc;
    }, {} as Record<string, any>);

    const logData = {
      timestamp,
      level,
      message,
      ...this.context,
      ...fieldsObj,
    };

    switch (level) {
      case LogLevel.DEBUG:
        console.debug(message, logData);
        break;
      case LogLevel.INFO:
        console.info(message, logData);
        break;
      case LogLevel.WARN:
        console.warn(message, logData);
        break;
      case LogLevel.ERROR:
        console.error(message, logData);
        break;
    }

    // 在生产环境中，可以将日志发送到远程服务
    if (process.env.NODE_ENV === 'production') {
      this.sendToRemoteLogging(logData);
    }
  }

  // 发送到远程日志服务 - 类比Go的远程日志
  private sendToRemoteLogging(logData: any): void {
    // 实际实现中，这里会调用远程日志服务API
    // 例如Sentry、LogRocket等
    // 简化示例，仅打印
    if (logData.level === LogLevel.ERROR) {
      console.log('Would send to remote logging:', logData);
    }
  }
}

// 创建全局日志器实例 - 类比Go的全局logger
export const logger = new Logger(
  process.env.NODE_ENV === 'production' ? LogLevel.INFO : LogLevel.DEBUG
);
