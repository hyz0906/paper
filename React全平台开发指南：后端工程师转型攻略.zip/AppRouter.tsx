/**
 * 路由配置 - 表现层
 * 
 * 类比Go后端的路由配置:
 * ```go
 * func SetupRouter(r *gin.Engine) {
 *   auth := r.Group("/auth")
 *   {
 *     auth.POST("/login", authHandler.Login)
 *     auth.POST("/register", authHandler.Register)
 *   }
 *   
 *   api := r.Group("/api")
 *   api.Use(middleware.Auth())
 *   {
 *     projects := api.Group("/projects")
 *     {
 *       projects.GET("", projectHandler.List)
 *       projects.POST("", projectHandler.Create)
 *       // ...
 *     }
 *   }
 * }
 * ```
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LoginPage } from '../pages/LoginPage';
import { RegisterPage } from '../pages/RegisterPage';
import { DashboardPage } from '../pages/DashboardPage';
import { ProjectPage } from '../pages/ProjectPage';
import { ProjectDetailPage } from '../pages/ProjectDetailPage';
import { NotFoundPage } from '../pages/NotFoundPage';
import { ProtectedRoute } from './ProtectedRoute';

// 应用路由组件 - 类比Go的路由配置
export const AppRouter: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* 公共路由 - 类比Go的公共路由 */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* 受保护路由 - 类比Go的认证中间件 */}
        <Route path="/" element={<ProtectedRoute />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="projects" element={<ProjectPage />} />
          <Route path="projects/:projectId" element={<ProjectDetailPage />} />
        </Route>
        
        {/* 404路由 - 类比Go的404处理 */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
};
