/**
 * 认证Hook - 表现层
 * 
 * 类比Go后端的认证中间件:
 * ```go
 * func AuthMiddleware(next http.Handler) http.Handler {
 *   return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
 *     // 认证逻辑
 *   })
 * }
 * ```
 */

import { useState, useEffect, useCallback } from 'react';
import Taro from '@tarojs/taro';
import { authService } from '../../application/authService';
import { User } from '../../domain/user';
import { logger } from '../../infrastructure/logger/logger';
import { eventBus } from '../../infrastructure/events/eventBus';

// 认证状态接口
interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// 认证Hook返回接口
interface UseAuthReturn extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  wechatLogin: () => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<User | null>;
}

// 认证Hook - 类比Go的认证中间件
export function useAuth(): UseAuthReturn {
  // 状态管理 - 类比Go的上下文状态
  const [state, setState] = useState<AuthState>({
    currentUser: null,
    isAuthenticated: false,
    isLoading: true,
    error: null
  });

  // 加载用户信息 - 类比Go的初始化认证
  const loadUser = useCallback(async () => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const user = await authService.getCurrentUser();
      
      setState({
        currentUser: user,
        isAuthenticated: !!user,
        isLoading: false,
        error: null
      });
      
      return user;
    } catch (error) {
      logger.error('Failed to load user', error);
      
      setState({
        currentUser: null,
        isAuthenticated: false,
        isLoading: false,
        error: '加载用户信息失败'
      });
      
      return null;
    }
  }, []);

  // 登录方法 - 类比Go的登录处理器
  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const user = await authService.login({ email, password });
      
      setState({
        currentUser: user,
        isAuthenticated: true,
        isLoading: false,
        error: null
      });
      
      return true;
    } catch (error) {
      logger.error('Login failed', error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '登录失败，请检查邮箱和密码'
      }));
      
      return false;
    }
  }, []);

  // 微信登录方法 - 小程序特有
  const wechatLogin = useCallback(async (): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const user = await authService.wechatLogin();
      
      setState({
        currentUser: user,
        isAuthenticated: true,
        isLoading: false,
        error: null
      });
      
      return true;
    } catch (error) {
      logger.error('Wechat login failed', error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '微信登录失败，请稍后重试'
      }));
      
      return false;
    }
  }, []);

  // 注册方法 - 类比Go的注册处理器
  const register = useCallback(async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const user = await authService.register({ name, email, password });
      
      setState({
        currentUser: user,
        isAuthenticated: true,
        isLoading: false,
        error: null
      });
      
      return true;
    } catch (error) {
      logger.error('Registration failed', error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '注册失败，请稍后重试'
      }));
      
      return false;
    }
  }, []);

  // 登出方法 - 类比Go的登出处理器
  const logout = useCallback(async (): Promise<void> => {
    try {
      setState(prev => ({ ...prev, isLoading: true }));
      
      await authService.logout();
      
      setState({
        currentUser: null,
        isAuthenticated: false,
        isLoading: false,
        error: null
      });
      
      // 小程序特有：登出后跳转到登录页
      Taro.redirectTo({ url: '/pages/login/index' });
    } catch (error) {
      logger.error('Logout failed', error);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: '登出失败，请稍后重试'
      }));
    }
  }, []);

  // 刷新用户信息 - 类比Go的刷新令牌
  const refreshUser = useCallback(async (): Promise<User | null> => {
    return loadUser();
  }, [loadUser]);

  // 组件挂载时加载用户信息 - 类比Go的中间件初始化
  useEffect(() => {
    loadUser();
  }, [loadUser]);

  // 监听认证事件 - 类比Go的事件监听
  useEffect(() => {
    // 登录事件处理
    const loginUnsubscribe = eventBus.subscribe('auth:login', () => {
      loadUser();
    });
    
    // 登出事件处理
    const logoutUnsubscribe = eventBus.subscribe('auth:logout', () => {
      setState({
        currentUser: null,
        isAuthenticated: false,
        isLoading: false,
        error: null
      });
    });
    
    // 清理订阅
    return () => {
      loginUnsubscribe();
      logoutUnsubscribe();
    };
  }, [loadUser]);

  return {
    ...state,
    login,
    wechatLogin,
    register,
    logout,
    refreshUser
  };
}
