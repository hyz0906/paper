/**
 * 项目详情页面 - 表现层
 * 
 * 类比Go后端的项目详情处理器:
 * ```go
 * func ProjectDetailHandler(c *gin.Context) {
 *   projectID := c.Param("id")
 *   // 处理项目详情请求
 * }
 * ```
 */

import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useProject } from '../hooks/useProject';
import { useTask } from '../hooks/useTask';
import { TaskList, CreateTaskForm } from '../components/TaskComponents';
import { TaskStatus } from '../../domain/task';

// 项目详情页面组件 - 类比Go的项目详情处理器
export const ProjectDetailPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { currentUser } = useAuth();
  const { fetchProject, currentProject, isLoading: projectLoading, error: projectError } = useProject();
  const { 
    tasks, 
    fetchTasks, 
    createTask, 
    updateTaskStatus, 
    assignTask, 
    deleteTask,
    isLoading: tasksLoading, 
    error: tasksError 
  } = useTask();

  // 组件挂载时获取项目详情和任务列表 - 类比Go的初始化逻辑
  useEffect(() => {
    if (projectId) {
      fetchProject(projectId);
      fetchTasks(projectId);
    }
  }, [projectId, fetchProject, fetchTasks]);

  // 处理任务创建 - 类比Go的任务创建处理
  const handleCreateTask = async (title: string, description: string) => {
    if (!projectId) return;
    
    try {
      await createTask(title, description, projectId);
      // 刷新任务列表
      fetchTasks(projectId);
    } catch (error) {
      console.error('Failed to create task:', error);
    }
  };

  // 处理任务状态更新 - 类比Go的任务更新处理
  const handleStatusChange = async (taskId: string, newStatus: TaskStatus) => {
    try {
      await updateTaskStatus(taskId, newStatus);
    } catch (error) {
      console.error('Failed to update task status:', error);
    }
  };

  // 处理任务分配 - 类比Go的任务分配处理
  const handleAssignTask = async (taskId: string, userId: string) => {
    try {
      await assignTask(taskId, userId);
    } catch (error) {
      console.error('Failed to assign task:', error);
    }
  };

  // 处理任务删除 - 类比Go的任务删除处理
  const handleDeleteTask = async (taskId: string) => {
    try {
      await deleteTask(taskId);
    } catch (error) {
      console.error('Failed to delete task:', error);
    }
  };

  // 加载状态
  const isLoading = projectLoading || tasksLoading;
  
  // 错误状态
  const error = projectError || tasksError;

  return (
    <div>
      {isLoading && !currentProject ? (
        <div className="text-center py-8">
          <p>Loading project details...</p>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      ) : currentProject ? (
        <>
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">{currentProject.name}</h1>
            <p className="text-gray-600">{currentProject.description}</p>
            
            <div className="mt-4 flex items-center space-x-4">
              <span className={`px-2 py-1 rounded-full text-xs ${
                currentProject.status === 'ACTIVE' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {currentProject.status}
              </span>
              <span className="text-sm text-gray-600">
                Members: {currentProject.members.length}
              </span>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Tasks</h2>
            <CreateTaskForm 
              projectId={currentProject.id} 
              onTaskCreate={handleCreateTask} 
            />
          </div>

          {tasksLoading ? (
            <div className="text-center py-4">
              <p>Loading tasks...</p>
            </div>
          ) : (
            <TaskList
              tasks={tasks}
              currentUser={currentUser!}
              onStatusChange={handleStatusChange}
              onAssign={handleAssignTask}
              onDelete={handleDeleteTask}
            />
          )}
        </>
      ) : (
        <div className="text-center py-8">
          <p>Project not found</p>
        </div>
      )}
    </div>
  );
};
