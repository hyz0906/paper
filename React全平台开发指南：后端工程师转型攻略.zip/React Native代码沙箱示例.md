# React Native代码沙箱示例

本示例展示了一个基于React Native的移动应用，专为具备Go/Python后端经验的开发者设计。示例实现了与Web端相同的任务管理系统，但针对移动端进行了优化，并展示了如何将后端开发思维应用到React Native开发中。

## 技术栈

- **框架**: React Native + Expo (简化开发流程)
- **类型系统**: TypeScript (与Go/Python类型系统对照)
- **状态管理**: Redux Toolkit (类比Go的状态管理)
- **导航**: React Navigation (类比Go的HTTP路由)
- **API交互**: Axios + React Query (类比Go的HTTP客户端)
- **本地存储**: AsyncStorage (类比Go的持久化存储)
- **UI组件**: React Native Paper (Material Design)
- **测试**: Jest + React Native Testing Library

## 项目结构

项目结构采用与Web端相同的领域驱动设计(DDD)思想，保持领域模型的一致性，同时适应移动端特性。

```
src/
├── domain/           # 领域模型 (与Web端共享)
│   ├── task.ts       # 任务领域模型
│   ├── user.ts       # 用户领域模型
│   └── project.ts    # 项目领域模型
├── application/      # 应用服务
│   ├── taskService.ts    # 任务相关业务逻辑
│   ├── authService.ts    # 认证相关业务逻辑
│   └── projectService.ts # 项目相关业务逻辑
├── infrastructure/   # 基础设施
│   ├── api/          # API客户端
│   ├── storage/      # 本地存储 (AsyncStorage)
│   ├── native/       # 原生模块集成
│   └── logger/       # 日志服务
├── presentation/     # 表现层
│   ├── components/   # UI组件
│   ├── screens/      # 屏幕组件 (对应Web的pages)
│   ├── hooks/        # 自定义Hooks
│   ├── navigation/   # 导航配置 (对应Web的routes)
│   └── theme/        # 主题和样式
└── shared/           # 共享工具和类型
    ├── utils/        # 工具函数
    ├── constants/    # 常量定义
    └── types/        # 共享类型定义
```

## 后端对照关系

本示例特别关注以下后端到React Native的概念映射：

1. **路由处理**: Go的HTTP Handler → React Native Screen
2. **中间件**: Go的Middleware → React Navigation的导航守卫
3. **依赖注入**: Go的DI容器 → React Context
4. **数据持久化**: Go的数据库操作 → AsyncStorage + Redux
5. **错误处理**: Go的错误返回 → React Native的错误边界
6. **并发处理**: Go的goroutine → React Native的异步操作
7. **原生集成**: Go的C绑定 → React Native的原生模块

## 移动端特有功能

与Web端相比，React Native示例额外展示了以下移动端特有功能：

1. **离线支持**: 通过AsyncStorage实现数据持久化和离线操作
2. **推送通知**: 集成Firebase Cloud Messaging (FCM)
3. **设备API**: 访问相机、位置、通讯录等原生功能
4. **手势操作**: 实现滑动、拖拽等移动端特有交互
5. **原生性能优化**: 使用原生模块处理性能关键路径

## 与GoMobile的集成

示例展示了如何将Go编写的原生模块集成到React Native应用中：

1. 使用GoMobile生成.aar (Android)和.framework (iOS)文件
2. 创建React Native桥接模块连接Go代码
3. 在JavaScript层调用Go实现的功能

## 运行示例

```bash
# 安装依赖
npm install

# 启动Expo开发服务器
npm start

# 在iOS模拟器中运行
npm run ios

# 在Android模拟器中运行
npm run android
```

## 与Web端代码共享

示例展示了如何在Web和React Native之间共享代码：

1. 领域模型完全共享
2. 应用服务逻辑大部分共享，仅平台特定部分不同
3. 基础设施层根据平台能力提供不同实现
4. 表现层完全不同，但遵循相同的数据流模式

## 性能对比

包含了Go后端服务与React Native前端渲染的性能对比指标，帮助开发者理解两者的性能特点和优化方向。
