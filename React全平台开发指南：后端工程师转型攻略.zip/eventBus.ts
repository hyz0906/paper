/**
 * 事件总线 - 基础设施层
 * 
 * 类比Go后端的事件总线:
 * ```go
 * type EventBus struct {
 *   subscribers map[string][]func(interface{})
 *   mu sync.RWMutex
 * }
 * 
 * func NewEventBus() *EventBus {
 *   return &EventBus{
 *     subscribers: make(map[string][]func(interface{})),
 *   }
 * }
 * 
 * func (b *EventBus) Subscribe(eventType string, handler func(interface{})) {
 *   // 实现订阅逻辑
 * }
 * ```
 */

// 事件处理器类型
export type EventHandler<T = any> = (event: T) => void;

// 事件总线类 - 类比Go的EventBus结构体
export class EventBus {
  private subscribers: Map<string, EventHandler[]>;

  constructor() {
    this.subscribers = new Map();
  }

  // 订阅事件 - 类比Go的Subscribe方法
  subscribe<T>(eventType: string, handler: EventHandler<T>): () => void {
    if (!this.subscribers.has(eventType)) {
      this.subscribers.set(eventType, []);
    }
    
    const handlers = this.subscribers.get(eventType)!;
    handlers.push(handler as EventHandler);
    
    // 返回取消订阅函数 - 类比Go的返回取消函数
    return () => {
      const index = handlers.indexOf(handler as EventHandler);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
    };
  }

  // 发布事件 - 类比Go的Publish方法
  publish<T>(eventType: string, event: T): void {
    if (!this.subscribers.has(eventType)) {
      return;
    }
    
    const handlers = this.subscribers.get(eventType)!;
    handlers.forEach(handler => {
      try {
        handler(event);
      } catch (error) {
        console.error(`Error handling event ${eventType}:`, error);
      }
    });
  }

  // 清除特定事件的所有订阅 - 类比Go的Clear方法
  clear(eventType: string): void {
    this.subscribers.delete(eventType);
  }

  // 清除所有事件订阅 - 类比Go的ClearAll方法
  clearAll(): void {
    this.subscribers.clear();
  }
}

// 创建全局事件总线实例 - 类比Go的全局EventBus
export const eventBus = new EventBus();
