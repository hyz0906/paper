/**
 * 仪表盘页面 - 表现层
 * 
 * 类比Go后端的仪表盘处理器:
 * ```go
 * func DashboardHandler(c *gin.Context) {
 *   // 处理仪表盘请求
 * }
 * ```
 */

import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useProject } from '../hooks/useProject';

// 仪表盘页面组件 - 类比Go的仪表盘处理器
export const DashboardPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { projects, fetchProjects, isLoading, error } = useProject();

  // 组件挂载时获取项目列表 - 类比Go的初始化逻辑
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  // 最近活动项目 - 取最新的3个项目
  const recentProjects = projects.slice(0, 3);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome, {currentUser?.name}</h1>
        <p className="text-gray-600">Here's an overview of your projects and tasks</p>
      </div>

      {isLoading ? (
        <div className="text-center py-8">
          <p>Loading dashboard data...</p>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 最近项目卡片 */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">Recent Projects</h2>
            
            {recentProjects.length === 0 ? (
              <p className="text-gray-500">No projects yet</p>
            ) : (
              <div className="space-y-4">
                {recentProjects.map(project => (
                  <div key={project.id} className="border-b pb-3 last:border-b-0">
                    <Link 
                      to={`/projects/${project.id}`}
                      className="text-lg font-medium text-blue-600 hover:text-blue-800"
                    >
                      {project.name}
                    </Link>
                    <p className="text-gray-600 text-sm mt-1">{project.description}</p>
                  </div>
                ))}
              </div>
            )}
            
            <div className="mt-4">
              <Link 
                to="/projects" 
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                View all projects →
              </Link>
            </div>
          </div>
          
          {/* 统计卡片 */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">Statistics</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Total Projects</p>
                <p className="text-2xl font-bold">{projects.length}</p>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Active Projects</p>
                <p className="text-2xl font-bold">
                  {projects.filter(p => p.status === 'ACTIVE').length}
                </p>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Your Tasks</p>
                <p className="text-2xl font-bold">--</p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Completed Tasks</p>
                <p className="text-2xl font-bold">--</p>
              </div>
            </div>
          </div>
          
          {/* 快速操作卡片 */}
          <div className="bg-white p-6 rounded-lg shadow-md md:col-span-2">
            <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <Link 
                to="/projects"
                className="bg-blue-600 text-white p-4 rounded-lg text-center hover:bg-blue-700"
              >
                Create New Project
              </Link>
              
              {projects.length > 0 && (
                <Link 
                  to={`/projects/${projects[0].id}`}
                  className="bg-green-600 text-white p-4 rounded-lg text-center hover:bg-green-700"
                >
                  Add New Task
                </Link>
              )}
              
              <Link 
                to="/projects"
                className="bg-purple-600 text-white p-4 rounded-lg text-center hover:bg-purple-700"
              >
                View All Projects
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
