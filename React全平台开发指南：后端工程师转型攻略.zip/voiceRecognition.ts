/**
 * 原生模块集成 - 基础设施层
 * 
 * 类比Go后端的原生集成:
 * ```go
 * // 通过CGO集成C/C++代码
 * // #cgo CFLAGS: -I${SRCDIR}/include
 * // #cgo LDFLAGS: -L${SRCDIR}/lib -lsomelib
 * // #include <somelib.h>
 * import "C"
 * ```
 */

import { NativeModules, Platform } from 'react-native';

// 声明原生模块接口 - 类比Go的外部函数声明
interface VoiceRecognitionModule {
  initialize(apiKey: string): Promise<boolean>;
  startListening(options: { language: string }): Promise<void>;
  stopListening(): Promise<void>;
  isAvailable(): Promise<boolean>;
}

// 声明GoMobile生成的模块接口 - 类比Go的导出函数
interface GoVoiceModule {
  processAudio(audioData: string): Promise<string>;
  getVersion(): Promise<string>;
}

// 获取原生模块 - 类比Go的导入外部库
const NativeVoiceRecognition = NativeModules.VoiceRecognition as VoiceRecognitionModule | undefined;
const GoVoice = NativeModules.GoVoice as GoVoiceModule | undefined;

// 语音识别服务 - 类比Go的服务封装
export class VoiceRecognitionService {
  private initialized: boolean = false;
  private apiKey: string = '';

  // 初始化服务 - 类比Go的Init方法
  async initialize(apiKey: string): Promise<boolean> {
    if (!NativeVoiceRecognition) {
      console.error('Voice recognition module not available');
      return false;
    }

    try {
      this.initialized = await NativeVoiceRecognition.initialize(apiKey);
      this.apiKey = apiKey;
      return this.initialized;
    } catch (error) {
      console.error('Failed to initialize voice recognition:', error);
      return false;
    }
  }

  // 检查可用性 - 类比Go的IsAvailable方法
  async isAvailable(): Promise<boolean> {
    if (!NativeVoiceRecognition) {
      return false;
    }

    try {
      return await NativeVoiceRecognition.isAvailable();
    } catch (error) {
      console.error('Failed to check voice recognition availability:', error);
      return false;
    }
  }

  // 开始语音识别 - 类比Go的Start方法
  async startListening(language: string = 'en-US'): Promise<void> {
    if (!this.initialized || !NativeVoiceRecognition) {
      throw new Error('Voice recognition not initialized');
    }

    try {
      await NativeVoiceRecognition.startListening({ language });
    } catch (error) {
      console.error('Failed to start voice recognition:', error);
      throw error;
    }
  }

  // 停止语音识别 - 类比Go的Stop方法
  async stopListening(): Promise<void> {
    if (!this.initialized || !NativeVoiceRecognition) {
      throw new Error('Voice recognition not initialized');
    }

    try {
      await NativeVoiceRecognition.stopListening();
    } catch (error) {
      console.error('Failed to stop voice recognition:', error);
      throw error;
    }
  }

  // 使用Go模块处理音频 - 类比Go的互操作
  async processWithGoModule(audioData: string): Promise<string> {
    if (!GoVoice) {
      throw new Error('Go voice module not available');
    }

    try {
      return await GoVoice.processAudio(audioData);
    } catch (error) {
      console.error('Failed to process audio with Go module:', error);
      throw error;
    }
  }

  // 获取Go模块版本 - 类比Go的版本检查
  async getGoModuleVersion(): Promise<string> {
    if (!GoVoice) {
      throw new Error('Go voice module not available');
    }

    try {
      return await GoVoice.getVersion();
    } catch (error) {
      console.error('Failed to get Go module version:', error);
      throw error;
    }
  }
}

// 创建语音识别服务实例 - 类比Go的服务实例化
export const voiceRecognition = new VoiceRecognitionService();

// 平台特定实现说明 - 类比Go的条件编译
export const nativeImplementationDetails = Platform.select({
  ios: 'Uses AVSpeechRecognizer with GoMobile .framework integration',
  android: 'Uses Android SpeechRecognizer with GoMobile .aar integration',
  default: 'Platform not supported'
});
