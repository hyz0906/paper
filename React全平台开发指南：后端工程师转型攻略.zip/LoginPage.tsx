/**
 * 登录页面 - 表现层
 * 
 * 类比Go后端的登录处理器:
 * ```go
 * func LoginHandler(c *gin.Context) {
 *   // 处理登录请求
 * }
 * ```
 */

import React, { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { LoginForm, RegisterForm } from '../components/AuthComponents';
import { useAuth } from '../hooks/useAuth';

// 登录页面组件 - 类比Go的登录处理器
export const LoginPage: React.FC = () => {
  const [isLoginView, setIsLoginView] = useState(true);
  const { login, register, isAuthenticated, isLoading, error } = useAuth();
  const navigate = useNavigate();

  // 如果已认证，重定向到仪表盘 - 类比Go的认证检查
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  // 处理登录 - 类比Go的登录处理
  const handleLogin = async (email: string, password: string) => {
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  // 处理注册 - 类比Go的注册处理
  const handleRegister = async (name: string, email: string, password: string) => {
    try {
      await register(name, email, password);
      navigate('/dashboard');
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center">
      <div className="max-w-md w-full mx-auto">
        <div className="bg-white p-8 border border-gray-300 rounded-lg shadow-lg">
          {isLoginView ? (
            <LoginForm
              onLogin={handleLogin}
              onSwitchToRegister={() => setIsLoginView(false)}
              isLoading={isLoading}
              error={error}
            />
          ) : (
            <RegisterForm
              onRegister={handleRegister}
              onSwitchToLogin={() => setIsLoginView(true)}
              isLoading={isLoading}
              error={error}
            />
          )}
        </div>
      </div>
    </div>
  );
};
