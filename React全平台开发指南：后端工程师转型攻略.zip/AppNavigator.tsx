/**
 * 导航配置 - 表现层
 * 
 * 类比Go后端的路由配置:
 * ```go
 * func SetupRouter(r *gin.Engine) {
 *   auth := r.Group("/auth")
 *   {
 *     auth.POST("/login", authHandler.Login)
 *     auth.POST("/register", authHandler.Register)
 *   }
 *   
 *   api := r.Group("/api")
 *   api.Use(middleware.Auth())
 *   {
 *     // ...
 *   }
 * }
 * ```
 */

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

// 导入屏幕组件
import { LoginScreen } from '../screens/auth/LoginScreen';
import { RegisterScreen } from '../screens/auth/RegisterScreen';
import { DashboardScreen } from '../screens/main/DashboardScreen';
import { ProjectsScreen } from '../screens/main/ProjectsScreen';
import { ProjectDetailScreen } from '../screens/main/ProjectDetailScreen';
import { TaskDetailScreen } from '../screens/main/TaskDetailScreen';
import { ProfileScreen } from '../screens/main/ProfileScreen';
import { SettingsScreen } from '../screens/main/SettingsScreen';

// 导入认证上下文
import { useAuth } from '../hooks/useAuth';

// 定义导航参数类型
export type AuthStackParamList = {
  Login: undefined;
  Register: undefined;
};

export type MainTabParamList = {
  Dashboard: undefined;
  Projects: undefined;
  Profile: undefined;
};

export type ProjectStackParamList = {
  ProjectsList: undefined;
  ProjectDetail: { projectId: string };
  TaskDetail: { taskId: string };
  Settings: undefined;
};

// 创建导航器
const AuthStack = createStackNavigator<AuthStackParamList>();
const MainTab = createBottomTabNavigator<MainTabParamList>();
const ProjectStack = createStackNavigator<ProjectStackParamList>();

// 项目栈导航 - 类比Go的项目路由组
const ProjectStackNavigator = () => {
  return (
    <ProjectStack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#4a6da7',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <ProjectStack.Screen 
        name="ProjectsList" 
        component={ProjectsScreen} 
        options={{ title: 'Projects' }}
      />
      <ProjectStack.Screen 
        name="ProjectDetail" 
        component={ProjectDetailScreen} 
        options={({ route }) => ({ 
          title: `Project Details` 
        })}
      />
      <ProjectStack.Screen 
        name="TaskDetail" 
        component={TaskDetailScreen} 
        options={{ title: 'Task Details' }}
      />
      <ProjectStack.Screen 
        name="Settings" 
        component={SettingsScreen} 
        options={{ title: 'Settings' }}
      />
    </ProjectStack.Navigator>
  );
};

// 主标签导航 - 类比Go的认证后API路由组
const MainTabNavigator = () => {
  return (
    <MainTab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Dashboard') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Projects') {
            iconName = focused ? 'list' : 'list-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'person' : 'person-outline';
          }

          return <Ionicons name={iconName as any} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#4a6da7',
        tabBarInactiveTintColor: 'gray',
      })}
    >
      <MainTab.Screen 
        name="Dashboard" 
        component={DashboardScreen} 
        options={{ headerShown: false }}
      />
      <MainTab.Screen 
        name="Projects" 
        component={ProjectStackNavigator} 
        options={{ headerShown: false }}
      />
      <MainTab.Screen 
        name="Profile" 
        component={ProfileScreen} 
        options={{ headerShown: true }}
      />
    </MainTab.Navigator>
  );
};

// 认证栈导航 - 类比Go的公共路由组
const AuthStackNavigator = () => {
  return (
    <AuthStack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#4a6da7',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <AuthStack.Screen 
        name="Login" 
        component={LoginScreen} 
        options={{ title: 'Login' }}
      />
      <AuthStack.Screen 
        name="Register" 
        component={RegisterScreen} 
        options={{ title: 'Register' }}
      />
    </AuthStack.Navigator>
  );
};

// 根导航 - 类比Go的根路由
export const AppNavigator = () => {
  const { isAuthenticated, isLoading } = useAuth();

  // 加载状态
  if (isLoading) {
    return null; // 或者显示加载指示器
  }

  return (
    <NavigationContainer>
      {isAuthenticated ? <MainTabNavigator /> : <AuthStackNavigator />}
    </NavigationContainer>
  );
};
