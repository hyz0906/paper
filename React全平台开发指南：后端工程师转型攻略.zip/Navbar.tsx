/**
 * 导航栏组件 - 表现层
 * 
 * 类比Go后端的中间件:
 * ```go
 * func HeaderMiddleware() gin.HandlerFunc {
 *   return func(c *gin.Context) {
 *     // 添加通用头部信息
 *     c.Next()
 *   }
 * }
 * ```
 */

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

// 导航栏组件 - 类比Go的通用中间件
export const Navbar: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  // 处理登出 - 类比Go的登出处理
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <nav className="bg-blue-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link to="/dashboard" className="text-xl font-bold">
              TaskMaster
            </Link>
            
            <div className="hidden md:flex space-x-4">
              <Link to="/dashboard" className="hover:text-blue-200">
                Dashboard
              </Link>
              <Link to="/projects" className="hover:text-blue-200">
                Projects
              </Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {currentUser && (
              <>
                <span className="hidden md:inline">
                  {currentUser.name}
                </span>
                <button
                  onClick={handleLogout}
                  className="bg-blue-700 hover:bg-blue-800 px-3 py-1 rounded"
                >
                  Logout
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
