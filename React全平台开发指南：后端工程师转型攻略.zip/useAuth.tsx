/**
 * 认证Hook - 表现层
 * 
 * 类比Go后端的认证服务:
 * ```go
 * type AuthService struct {
 *   // ...
 * }
 * 
 * func (s *AuthService) VerifyToken(token string) (*User, error) {
 *   // 验证token逻辑
 * }
 * ```
 */

import { useState, useCallback, useContext, createContext } from 'react';
import { User } from '../../domain/user';
import { authService } from '../../application/authService';
import { logger } from '../../infrastructure/logger/logger';

// 认证上下文类型
interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  error: string | null;
}

// 创建认证上下文 - 类比Go的上下文
const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
  checkAuth: async () => {},
  error: null
});

// 认证提供者组件 - 类比Go的服务提供者
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 检查认证状态 - 类比Go的token验证
  const checkAuth = useCallback(async () => {
    try {
      setIsLoading(true);
      const user = await authService.getCurrentUser();
      setCurrentUser(user);
      setIsAuthenticated(!!user);
      setError(null);
    } catch (err) {
      logger.error('Authentication check failed', err as Error);
      setCurrentUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 登录 - 类比Go的登录处理
  const login = useCallback(async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      const user = await authService.login({ email, password });
      setCurrentUser(user);
      setIsAuthenticated(true);
    } catch (err) {
      logger.error('Login failed', err as Error);
      setError('Invalid email or password');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 注册 - 类比Go的注册处理
  const register = useCallback(async (name: string, email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      const user = await authService.register({ name, email, password });
      setCurrentUser(user);
      setIsAuthenticated(true);
    } catch (err) {
      logger.error('Registration failed', err as Error);
      setError('Registration failed. Email may already be in use.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 登出 - 类比Go的登出处理
  const logout = useCallback(async () => {
    try {
      setIsLoading(true);
      await authService.logout();
      setCurrentUser(null);
      setIsAuthenticated(false);
      setError(null);
    } catch (err) {
      logger.error('Logout failed', err as Error);
      // 即使登出API失败，也强制清除本地状态
      setCurrentUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // 提供认证上下文
  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        isLoading,
        login,
        register,
        logout,
        checkAuth,
        error
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// 使用认证Hook - 类比Go的服务注入
export const useAuth = () => useContext(AuthContext);
