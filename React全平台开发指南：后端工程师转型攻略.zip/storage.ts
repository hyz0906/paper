/**
 * 本地存储 - 基础设施层
 * 
 * 类比Go后端的存储服务:
 * ```go
 * type StorageService struct {
 *   db *sql.DB
 * }
 * 
 * func (s *StorageService) Save(key string, value []byte) error {
 *   // 实现保存逻辑
 * }
 * ```
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

// 存储键前缀 - 类比Go的命名空间
const STORAGE_PREFIX = '@TaskMaster:';

// 保存数据 - 类比Go的Save方法
export async function saveData<T>(key: string, data: T): Promise<void> {
  try {
    const jsonValue = JSON.stringify(data);
    await AsyncStorage.setItem(`${STORAGE_PREFIX}${key}`, jsonValue);
  } catch (error) {
    console.error(`Failed to save data for key ${key}:`, error);
    throw error;
  }
}

// 获取数据 - 类比Go的Get方法
export async function getData<T>(key: string): Promise<T | null> {
  try {
    const jsonValue = await AsyncStorage.getItem(`${STORAGE_PREFIX}${key}`);
    return jsonValue != null ? JSON.parse(jsonValue) as T : null;
  } catch (error) {
    console.error(`Failed to get data for key ${key}:`, error);
    throw error;
  }
}

// 删除数据 - 类比Go的Delete方法
export async function removeData(key: string): Promise<void> {
  try {
    await AsyncStorage.removeItem(`${STORAGE_PREFIX}${key}`);
  } catch (error) {
    console.error(`Failed to remove data for key ${key}:`, error);
    throw error;
  }
}

// 获取所有键 - 类比Go的GetAllKeys方法
export async function getAllKeys(): Promise<string[]> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    return keys.filter(key => key.startsWith(STORAGE_PREFIX))
               .map(key => key.replace(STORAGE_PREFIX, ''));
  } catch (error) {
    console.error('Failed to get all keys:', error);
    throw error;
  }
}

// 清除所有数据 - 类比Go的ClearAll方法
export async function clearAllData(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const appKeys = keys.filter(key => key.startsWith(STORAGE_PREFIX));
    await AsyncStorage.multiRemove(appKeys);
  } catch (error) {
    console.error('Failed to clear all data:', error);
    throw error;
  }
}

// 批量操作 - 类比Go的批量操作
export async function multiSave<T>(items: [string, T][]): Promise<void> {
  try {
    const pairs = items.map(([key, value]) => [
      `${STORAGE_PREFIX}${key}`,
      JSON.stringify(value)
    ]);
    await AsyncStorage.multiSet(pairs as [string, string][]);
  } catch (error) {
    console.error('Failed to save multiple items:', error);
    throw error;
  }
}

// 批量获取 - 类比Go的批量获取
export async function multiGet<T>(keys: string[]): Promise<[string, T | null][]> {
  try {
    const prefixedKeys = keys.map(key => `${STORAGE_PREFIX}${key}`);
    const pairs = await AsyncStorage.multiGet(prefixedKeys);
    
    return pairs.map(([key, value]) => [
      key.replace(STORAGE_PREFIX, ''),
      value ? JSON.parse(value) as T : null
    ]);
  } catch (error) {
    console.error('Failed to get multiple items:', error);
    throw error;
  }
}
