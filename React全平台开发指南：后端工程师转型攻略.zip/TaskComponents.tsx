/**
 * 任务组件 - 表现层
 * 
 * 类比Go后端的HTTP处理器:
 * ```go
 * func TaskHandler(c *gin.Context) {
 *   // 处理任务请求
 * }
 * ```
 */

import React, { useState } from 'react';
import { Task, TaskStatus } from '../../domain/task';
import { User } from '../../domain/user';

interface TaskItemProps {
  task: Task;
  currentUser: User;
  onStatusChange: (taskId: string, newStatus: TaskStatus) => void;
  onAssign: (taskId: string, userId: string) => void;
  onDelete: (taskId: string) => void;
}

// 任务项组件 - 类比Go的HTTP处理函数
export const TaskItem: React.FC<TaskItemProps> = ({
  task,
  currentUser,
  onStatusChange,
  onAssign,
  onDelete
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // 状态样式映射
  const statusStyles = {
    [TaskStatus.TODO]: 'bg-gray-100 text-gray-800',
    [TaskStatus.IN_PROGRESS]: 'bg-blue-100 text-blue-800',
    [TaskStatus.DONE]: 'bg-green-100 text-green-800',
  };

  // 格式化日期 - 类比Go的格式化函数
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  // 处理状态变更 - 类比Go的处理函数
  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value as TaskStatus;
    onStatusChange(task.id, newStatus);
  };

  // 处理分配给自己 - 类比Go的处理函数
  const handleAssignToMe = () => {
    onAssign(task.id, currentUser.id);
  };

  // 处理删除 - 类比Go的处理函数
  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      onDelete(task.id);
    }
  };

  return (
    <div className="border rounded-lg p-4 mb-4 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold">{task.title}</h3>
          <div className="flex items-center mt-1 space-x-2">
            <span className={`px-2 py-1 rounded-full text-xs ${statusStyles[task.status]}`}>
              {task.status}
            </span>
            {task.dueDate && (
              <span className="text-sm text-gray-600">
                Due: {formatDate(task.dueDate)}
              </span>
            )}
          </div>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-gray-500 hover:text-gray-700"
          >
            {isExpanded ? 'Collapse' : 'Expand'}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="mt-4">
          <p className="text-gray-700 mb-4">{task.description}</p>
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0 sm:space-x-2">
            <div className="flex items-center space-x-2">
              <label htmlFor={`status-${task.id}`} className="text-sm font-medium">
                Status:
              </label>
              <select
                id={`status-${task.id}`}
                value={task.status}
                onChange={handleStatusChange}
                className="border rounded p-1 text-sm"
              >
                <option value={TaskStatus.TODO}>To Do</option>
                <option value={TaskStatus.IN_PROGRESS}>In Progress</option>
                <option value={TaskStatus.DONE}>Done</option>
              </select>
            </div>
            
            <div className="flex space-x-2">
              {!task.assigneeId && (
                <button
                  onClick={handleAssignToMe}
                  className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                >
                  Assign to me
                </button>
              )}
              <button
                onClick={handleDelete}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
              >
                Delete
              </button>
            </div>
          </div>
          
          <div className="mt-4 text-sm text-gray-500">
            <p>Created: {formatDate(task.createdAt)}</p>
            <p>Last Updated: {formatDate(task.updatedAt)}</p>
          </div>
        </div>
      )}
    </div>
  );
};

interface TaskListProps {
  tasks: Task[];
  currentUser: User;
  onStatusChange: (taskId: string, newStatus: TaskStatus) => void;
  onAssign: (taskId: string, userId: string) => void;
  onDelete: (taskId: string) => void;
}

// 任务列表组件 - 类比Go的列表处理函数
export const TaskList: React.FC<TaskListProps> = ({
  tasks,
  currentUser,
  onStatusChange,
  onAssign,
  onDelete
}) => {
  // 按状态分组 - 类比Go的数据处理函数
  const groupedTasks = tasks.reduce(
    (acc, task) => {
      acc[task.status].push(task);
      return acc;
    },
    {
      [TaskStatus.TODO]: [] as Task[],
      [TaskStatus.IN_PROGRESS]: [] as Task[],
      [TaskStatus.DONE]: [] as Task[],
    }
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* 待办任务列 */}
      <div>
        <h2 className="text-xl font-bold mb-4 pb-2 border-b">To Do</h2>
        {groupedTasks[TaskStatus.TODO].length === 0 ? (
          <p className="text-gray-500">No tasks to do</p>
        ) : (
          groupedTasks[TaskStatus.TODO].map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              currentUser={currentUser}
              onStatusChange={onStatusChange}
              onAssign={onAssign}
              onDelete={onDelete}
            />
          ))
        )}
      </div>

      {/* 进行中任务列 */}
      <div>
        <h2 className="text-xl font-bold mb-4 pb-2 border-b">In Progress</h2>
        {groupedTasks[TaskStatus.IN_PROGRESS].length === 0 ? (
          <p className="text-gray-500">No tasks in progress</p>
        ) : (
          groupedTasks[TaskStatus.IN_PROGRESS].map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              currentUser={currentUser}
              onStatusChange={onStatusChange}
              onAssign={onAssign}
              onDelete={onDelete}
            />
          ))
        )}
      </div>

      {/* 已完成任务列 */}
      <div>
        <h2 className="text-xl font-bold mb-4 pb-2 border-b">Done</h2>
        {groupedTasks[TaskStatus.DONE].length === 0 ? (
          <p className="text-gray-500">No completed tasks</p>
        ) : (
          groupedTasks[TaskStatus.DONE].map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              currentUser={currentUser}
              onStatusChange={onStatusChange}
              onAssign={onAssign}
              onDelete={onDelete}
            />
          ))
        )}
      </div>
    </div>
  );
};

interface CreateTaskFormProps {
  projectId: string;
  onTaskCreate: (title: string, description: string) => void;
}

// 创建任务表单组件 - 类比Go的表单处理函数
export const CreateTaskForm: React.FC<CreateTaskFormProps> = ({
  projectId,
  onTaskCreate,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isFormVisible, setIsFormVisible] = useState(false);

  // 处理表单提交 - 类比Go的表单处理函数
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim() && description.trim()) {
      onTaskCreate(title, description);
      setTitle('');
      setDescription('');
      setIsFormVisible(false);
    }
  };

  return (
    <div className="mb-8">
      {!isFormVisible ? (
        <button
          onClick={() => setIsFormVisible(true)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Create New Task
        </button>
      ) : (
        <form onSubmit={handleSubmit} className="border rounded-lg p-4 shadow-sm">
          <h2 className="text-xl font-bold mb-4">Create New Task</h2>
          
          <div className="mb-4">
            <label htmlFor="title" className="block text-sm font-medium mb-1">
              Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border rounded p-2"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="description" className="block text-sm font-medium mb-1">
              Description
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border rounded p-2 h-24"
              required
            />
          </div>
          
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsFormVisible(false)}
              className="border px-4 py-2 rounded hover:bg-gray-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
              Create Task
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
