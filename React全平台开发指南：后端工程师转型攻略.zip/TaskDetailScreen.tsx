/**
 * 任务详情屏幕 - 表现层
 * 
 * 类比Go后端的任务详情处理器:
 * ```go
 * func TaskDetailHandler(c *gin.Context) {
 *   taskID := c.Param("id")
 *   // 处理任务详情请求
 * }
 * ```
 */

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, Chip, Dialog, Portal, TextInput } from 'react-native-paper';
import { useAuth } from '../../hooks/useAuth';
import { useTask } from '../../hooks/useTask';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { ProjectStackParamList } from '../../navigation/AppNavigator';
import { Ionicons } from '@expo/vector-icons';
import { TaskStatus } from '../../../domain/task';

// 导航属性类型
type TaskDetailScreenNavigationProp = StackNavigationProp<ProjectStackParamList, 'TaskDetail'>;
type TaskDetailScreenRouteProp = RouteProp<ProjectStackParamList, 'TaskDetail'>;

// 组件属性类型
type Props = {
  navigation: TaskDetailScreenNavigationProp;
  route: TaskDetailScreenRouteProp;
};

// 任务详情屏幕组件 - 类比Go的任务详情处理器
export const TaskDetailScreen: React.FC<Props> = ({ navigation, route }) => {
  const { taskId } = route.params;
  const { currentUser } = useAuth();
  const { 
    fetchTask, 
    currentTask, 
    updateTaskStatus, 
    assignTask, 
    deleteTask,
    isLoading, 
    error 
  } = useTask();

  // 编辑任务对话框状态
  const [dialogVisible, setDialogVisible] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [dialogLoading, setDialogLoading] = useState(false);

  // 组件挂载时获取任务详情 - 类比Go的初始化逻辑
  useEffect(() => {
    if (taskId) {
      fetchTask(taskId);
    }
  }, [taskId, fetchTask]);

  // 初始化编辑对话框数据
  useEffect(() => {
    if (currentTask) {
      setTaskTitle(currentTask.title);
      setTaskDescription(currentTask.description || '');
    }
  }, [currentTask]);

  // 处理任务状态更新 - 类比Go的任务更新处理
  const handleStatusChange = (newStatus: TaskStatus) => {
    if (!currentTask) return;
    
    Alert.alert(
      'Update Task Status',
      `Change task status to ${newStatus}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Update', 
          onPress: async () => {
            try {
              await updateTaskStatus(currentTask.id, newStatus);
              // 刷新任务详情
              fetchTask(taskId);
            } catch (error) {
              Alert.alert('Error', 'Failed to update task status');
            }
          }
        }
      ]
    );
  };

  // 处理任务分配 - 类比Go的任务分配处理
  const handleAssignTask = () => {
    if (!currentUser || !currentTask) return;
    
    Alert.alert(
      'Assign Task',
      'Assign this task to yourself?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Assign', 
          onPress: async () => {
            try {
              await assignTask(currentTask.id, currentUser.id);
              // 刷新任务详情
              fetchTask(taskId);
            } catch (error) {
              Alert.alert('Error', 'Failed to assign task');
            }
          }
        }
      ]
    );
  };

  // 处理任务删除 - 类比Go的任务删除处理
  const handleDeleteTask = () => {
    if (!currentTask) return;
    
    Alert.alert(
      'Delete Task',
      'Are you sure you want to delete this task? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteTask(currentTask.id);
              // 返回到项目详情页
              navigation.goBack();
            } catch (error) {
              Alert.alert('Error', 'Failed to delete task');
            }
          }
        }
      ]
    );
  };

  // 获取状态芯片样式
  const getStatusChipStyle = (status: TaskStatus) => {
    switch (status) {
      case TaskStatus.TODO:
        return styles.todoChip;
      case TaskStatus.IN_PROGRESS:
        return styles.inProgressChip;
      case TaskStatus.DONE:
        return styles.doneChip;
      default:
        return {};
    }
  };

  // 设置导航标题
  useEffect(() => {
    if (currentTask) {
      navigation.setOptions({ title: currentTask.title });
    }
  }, [currentTask, navigation]);

  return (
    <View style={styles.container}>
      {isLoading && !currentTask ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a6da7" />
          <Text style={styles.loadingText}>Loading task details...</Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <Button 
            mode="contained" 
            onPress={() => fetchTask(taskId)}
            style={styles.retryButton}
          >
            Retry
          </Button>
        </View>
      ) : currentTask ? (
        <ScrollView style={styles.content}>
          <Card style={styles.taskCard}>
            <Card.Content>
              <View style={styles.taskHeader}>
                <Title style={styles.taskTitle}>{currentTask.title}</Title>
                <Chip 
                  mode="outlined" 
                  style={getStatusChipStyle(currentTask.status)}
                >
                  {currentTask.status}
                </Chip>
              </View>
              
              <Paragraph style={styles.taskDescription}>
                {currentTask.description || 'No description provided.'}
              </Paragraph>
              
              <View style={styles.taskMeta}>
                {currentTask.assigneeId ? (
                  <Text style={styles.metaText}>
                    <Ionicons name="person-outline" size={16} /> Assigned to: {currentTask.assigneeId === currentUser?.id ? 'You' : currentTask.assigneeId}
                  </Text>
                ) : (
                  <Text style={styles.metaText}>
                    <Ionicons name="person-outline" size={16} /> Not assigned
                  </Text>
                )}
                
                <Text style={styles.metaText}>
                  <Ionicons name="calendar-outline" size={16} /> Created: {new Date(currentTask.createdAt).toLocaleDateString()}
                </Text>
              </View>
            </Card.Content>
          </Card>

          <View style={styles.actionsContainer}>
            <Title style={styles.actionsTitle}>Actions</Title>
            
            <View style={styles.actionButtons}>
              {currentTask.status === TaskStatus.TODO && (
                <Button 
                  mode="contained"
                  onPress={() => handleStatusChange(TaskStatus.IN_PROGRESS)}
                  style={[styles.actionButton, { backgroundColor: '#ff9800' }]}
                  icon="play"
                >
                  Start Task
                </Button>
              )}
              
              {currentTask.status === TaskStatus.IN_PROGRESS && (
                <Button 
                  mode="contained"
                  onPress={() => handleStatusChange(TaskStatus.DONE)}
                  style={[styles.actionButton, { backgroundColor: '#4caf50' }]}
                  icon="check"
                >
                  Complete Task
                </Button>
              )}
              
              {currentTask.status === TaskStatus.DONE && (
                <Button 
                  mode="contained"
                  onPress={() => handleStatusChange(TaskStatus.IN_PROGRESS)}
                  style={[styles.actionButton, { backgroundColor: '#ff9800' }]}
                  icon="refresh"
                >
                  Reopen Task
                </Button>
              )}
              
              {!currentTask.assigneeId && (
                <Button 
                  mode="contained"
                  onPress={handleAssignTask}
                  style={[styles.actionButton, { backgroundColor: '#9c27b0' }]}
                  icon="account-check"
                >
                  Assign to Me
                </Button>
              )}
              
              <Button 
                mode="contained"
                onPress={() => setDialogVisible(true)}
                style={[styles.actionButton, { backgroundColor: '#4a6da7' }]}
                icon="pencil"
              >
                Edit Task
              </Button>
              
              <Button 
                mode="contained"
                onPress={handleDeleteTask}
                style={[styles.actionButton, { backgroundColor: '#f44336' }]}
                icon="delete"
              >
                Delete Task
              </Button>
            </View>
          </View>
        </ScrollView>
      ) : (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Task not found</Text>
        </View>
      )}

      <Portal>
        <Dialog visible={dialogVisible} onDismiss={() => setDialogVisible(false)}>
          <Dialog.Title>Edit Task</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label="Task Title"
              value={taskTitle}
              onChangeText={setTaskTitle}
              style={styles.input}
              disabled={dialogLoading}
            />
            <TextInput
              label="Description"
              value={taskDescription}
              onChangeText={setTaskDescription}
              style={styles.input}
              multiline
              numberOfLines={3}
              disabled={dialogLoading}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDialogVisible(false)} disabled={dialogLoading}>Cancel</Button>
            <Button 
              onPress={async () => {
                if (!currentTask) return;
                
                try {
                  setDialogLoading(true);
                  // 这里应该调用更新任务的API
                  // 由于我们没有实现完整的updateTask，这里只是模拟
                  await new Promise(resolve => setTimeout(resolve, 1000));
                  setDialogVisible(false);
                  
                  // 刷新任务详情
                  fetchTask(taskId);
                } catch (error) {
                  Alert.alert('Error', 'Failed to update task');
                } finally {
                  setDialogLoading(false);
                }
              }} 
              loading={dialogLoading} 
              disabled={dialogLoading}
            >
              Save
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};

// 样式
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  taskCard: {
    marginBottom: 20,
    elevation: 2,
  },
  taskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  taskTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 10,
  },
  taskDescription: {
    color: '#757575',
    fontSize: 16,
    lineHeight: 24,
  },
  taskMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  metaText: {
    fontSize: 14,
    color: '#757575',
  },
  todoChip: {
    backgroundColor: '#e3f2fd',
  },
  inProgressChip: {
    backgroundColor: '#fff8e1',
  },
  doneChip: {
    backgroundColor: '#e8f5e9',
  },
  actionsContainer: {
    marginBottom: 20,
  },
  actionsTitle: {
    fontSize: 18,
    marginBottom: 12,
  },
  actionButtons: {
    flexDirection: 'column',
  },
  actionButton: {
    marginBottom: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: '#d32f2f',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4a6da7',
  },
  input: {
    marginBottom: 16,
    backgroundColor: '#fff',
  },
});
